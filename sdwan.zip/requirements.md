# Requirements

## All requirements
```shell
pip freeze > requirements-all.txt
```

## Requirements without building from sources
```shell
pip freeze | grep -v @ > requirements-wo-git.txt
```

## Conda
```shell
conda env export > requirements.yaml
```