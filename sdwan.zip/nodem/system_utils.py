import signal
import os

def exit():
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)