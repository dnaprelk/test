import copy
import json
import logging
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional

import inject
from from_dict import from_dict
from tabulate import tabulate

import config
import exceptions
import log_utils
from abstract import Abstract
import http_utils

log = logging.getLogger("HUBS")
log.setLevel(config.getLogLevel("hubs"))



class Hubs(Abstract):

   @dataclass(frozen=True)
   class Hub:
      name: str
      id: int
      key: str
      address: str
      longitude: float
      latitude: float
      port: int

      class State(str, Enum):
         ENABLED = "enabled"
         DISABLED = "disabled"
      state: State

      uuid: str

      easguid: Optional[str] = None
      qcgeo: Optional[int] = None
      description: Optional[str] = None

      class Status(str, Enum):
         OFFLINE = "offline"
         REGISTERED = "registered"
         ONLINE = "online"
      status:Optional[Status] = Status.OFFLINE

      ip: Optional[str] = None
      pubkey: Optional[str] = None
      src: Optional[str] = None
      uptime: Optional[int] = None



   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, Hubs.Hub] = {}
      self.dictID:  Dict[int, Hubs.Hub] = {}

      self.dictLastSeen = {}





   async def init(self):
      RID = "initHubs"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/hubs', 2)

      dictHubs = json.loads(sResponse)

      for sHubName in dictHubs.keys():
         dictHubs[sHubName]["name"] = sHubName
         hub = from_dict(Hubs.Hub, dictHubs[sHubName])

         await self.addDB(RID, hub)

      log.info("\n" + self.printList(list(self.dictName.values())))









   # async def add(self,
   #               RID:int,
   #               name:str,
   #               id:int,
   #               description:str,
   #               address:str,
   #               key:str,
   #               longitude:float,
   #               latitude:float,
   #               port:int,
   #               state:Hub.State,
   #               easguid: str,
   #               qcgeo: int) -> Hub:
   #    log.info(f"[{RID}] add() name='{name}' id={id} description='{description}'")
   #    async with self.lock:
   #       if id == 0:
   #          id = self.getFreeId(id, 253)
   #
   #       hub = Hubs.Hub(name=name,
   #                      id=id,
   #                      uuid=str(uuid.uuid4()),
   #                      description=description,
   #                      address=address,
   #                      key=key,
   #                      longitude=longitude,
   #                      latitude=latitude,
   #                      port=port,
   #                      state=state,
   #                      status=Hubs.Hub.Status.OFFLINE,
   #                      easguid=easguid,
   #                      qcgeo=qcgeo)
   #
   #       self.addDB(RID, hub)
   #
   #    return hub





   # async def update(self,
   #                  RID:int,
   #                  uuid:str,
   #                  name:str,
   #                  description:str,
   #                  address:str,
   #                  key:str,
   #                  longitude:float,
   #                  latitude:float,
   #                  port:int,
   #                  state:Hub.State,
   #                  easguid: str,
   #                  qcgeo: int) -> Hub:
   #    log.info(f"[{RID}] add() name='{name}' description='{description}'")
   #    async with self.lock:
   #       current_hub:Hubs.Hub = await self.getByUUID(RID, uuid)
   #
   #       hub = Hubs.Hub(name=name,
   #                      id=current_hub.id,
   #                      uuid=current_hub.uuid,
   #                      description=description,
   #                      address=address,
   #                      key=key,
   #                      longitude=longitude,
   #                      latitude=latitude,
   #                      port=port,
   #                      state=state,
   #                      status=Hubs.Hub.Status.OFFLINE,
   #                      easguid=easguid,
   #                      qcgeo=qcgeo)
   #
   #       self.updateDB(RID, hub)
   #
   #    return hub






   def printOne(self, hub:Hub):
      tree = log_utils.Tree(f"HUB {hub.name}")
      root = tree.getRoot()
      root.addNode(f"id={hub.id}")
      root.addNode(f"uuid={hub.uuid}")
      root.addNode(f"description={hub.description}")
      root.addNode(f"state={hub.state}")
      root.addNode(f"status={hub.status}")
      root.addNode(f"ip:port={hub.ip}:{hub.port}")
      root.addNode(f"pubkey={hub.pubkey}")
      return tree.print()



   def printList(self, listHubs:List[Hub]) -> str:
      logTable = []

      for hub in listHubs:
         logTable.append([hub.name,
                          hub.id,
                          hub.description,
                          hub.key,
                          hub.longitude,
                          hub.latitude,
                          hub.port,
                          hub.state,
                          hub.ip,
                          hub.pubkey,
                          hub.status,
                          hub.uuid,
                          hub.src])

      return tabulate(logTable, headers=["Name", "ID", "Description", "Key", "Longitude", "Latitude", "Port", "State", "IP", "Pubkey", "Status", "UUID", "src"], tablefmt="grid")



   def getLastSeen(self, name):
      if name in self.dictLastSeen:
         return self.dictLastSeen[name]
      else:
         return None
   def setLastSeen(self, rid:str, name:str, time:int):
      log.debug(f"[{rid}] setLastSeen() time={log_utils.print_date(time)}")
      self.dictLastSeen[name] = time



