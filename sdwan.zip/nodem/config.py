import asyncio
import json
import subprocess
import os
from enum import Enum
from typing import Tuple, List, Dict

import yaml
import logging
import log_utils



from dataclasses import dataclass



import dict_utils


CONFIG_PATH="../etc/config.yaml"
CONFIG_HISTORY = 10

log = logging.getLogger("CONFIG")
log.setLevel(logging.NOTSET)


lock = asyncio.Lock()

def check_nested_dict_path(nested_dict, path) -> bool:
   try:
      return all(path_part in nested_dict for path_part in path.split('.'))
   except AttributeError:
      return False



log.info("I am reading the config file at path: " + CONFIG_PATH)
with open(CONFIG_PATH, "r") as file:
   configFile = yaml.safe_load(file)

log.info("Done. The config:\n" + log_utils.print_tree(configFile))






def __convertLog(sLevel):
   if sLevel == None:
      return logging.NOTSET
   # Yaml converts OFF to False
   # By spec
   elif sLevel == False or sLevel.lower() == "off":
      return logging.CRITICAL + 1
   elif sLevel.lower() == "error":
      return logging.ERROR
   elif sLevel.lower() == "warn":
      return logging.WARN
   elif sLevel.lower() == "info":
      return logging.INFO
   elif sLevel.lower() == "debug":
      return logging.DEBUG

   return logging.NOTSET


def getLogLevel(sLogger):
   try:
      return __convertLog(configFile["logs"][sLogger.lower()])
   except Exception:
      #if there is no log section - TRACE level
      pass
   return logging.NOTSET
def getMQTTLogLevel(interfaceName):
   try:
      return __convertLog(configFile["logs"]["mqtt"][interfaceName.lower()])
   except Exception:
      pass
   return logging.NOTSET





def enum_to_string(enum_value):
   if isinstance(enum_value, Enum):
      return enum_value.value
   return enum_value


def convert_enums_to_strings(data):
   if isinstance(data, dict):
      return {key: convert_enums_to_strings(value) for key, value in data.items()}
   elif isinstance(data, list):
      return [convert_enums_to_strings(item) for item in data]
   else:
      return enum_to_string(data)

