import asyncio
from typing import TypeVar, Dict, List, Generic
import logging
from enum import Enum


import config
import exceptions
import log_utils

T = TypeVar('T')





class Abstract(Generic [T]):
   def __init__(self):
      self.class_type = type(self).__name__
      self.log = logging.getLogger(self.class_type.upper())
      self.log.setLevel(config.getLogLevel(self.class_type.lower()))

      self.lock = asyncio.Lock()

   async def getAllDict(self, RID:str) -> Dict[str, T]:
      self.log.info(f"[{RID}] getAll()")

      self.log.debug(f"[{RID}]\n" + self.printList(self.dictName.values()))

      return self.dictName

   async def getAllList(self, RID:str) -> List[T]:
      self.log.info(f"[{RID}] getAll()")

      #self.log.debug(f"[{RID}]\n" + self.printList(self.dictName.values()))

      return self.dictName.values()




   async def getByName(self, RID:str, name:str) -> T:
      self.log.info(f"[{RID}] getByName() name='{name}'")

      if name in self.dictName:
         entity = self.dictName[name]
         self.log.info(f"[{RID}]\n" + self.printOne(entity))
         return entity
      else:
         self.log.error(f"[{RID}] name='{name}' is NOT found.")
         raise exceptions.NotFoundException(self.class_type, "name", name)


   async def deleteByName(self, RID:str, name:str):
      self.log.info(f"[{RID}] delete() uuid='{name}'")

      async with self.lock:
         entity = await self.getByName(RID, name)

         if hasattr(entity, "name"):
            self.dictName.pop(entity.name)

         if hasattr(entity, "id"):
            self.dictID.pop(entity.id)



   async def addDB(self, RID:str, obj):
      self.log.info(f"[{RID}] add()\n" + self.printOne(obj))

      async with self.lock:
         if hasattr(obj, "name") and obj.name in self.dictName:
            raise exceptions.DuplicateNameException(self.class_type, obj.name)
         if hasattr(obj, "id") and obj.id in self.dictID:
            raise exceptions.DuplicateIdException(self.class_type, obj.id)

         if hasattr(obj, "name"):
            self.dictName[obj.name] = obj
         if hasattr(obj, "id"):
            self.dictID[obj.id] = obj

      self.log.info(f"[{RID}] ok, added.")

   async def updateDB(self, RID:str, obj):
      self.log.info(f"[{RID}] update()\n" + self.printOne(obj))

      async with self.lock:
         if hasattr(obj, "name"):
            self.dictName[obj.name] = obj
         if hasattr(obj, "id"):
            self.dictID[obj.id] = obj

      self.log.info(f"[{RID}] ok, updated.")
