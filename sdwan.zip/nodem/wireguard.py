import os
import os_command_utils
from os_command_utils import os_command_ignore

#SSH = "ssh -p 5022 root@91.185.88.125"
SSH=os.environ.get("SSH")

async def cleanAll():
   sPeers = await os_command_ignore(SSH + " wg show wg0 allowed-ips")
   for line in sPeers.split("\n"):
      arg = line.split('\t')
      os.system(SSH + f' wg set wg0 peer {arg[0]} remove')


async def add(key:str, hub_id:int, hub_external_ip:str, hub_external_port:int):
   await os_command_ignore(SSH + f" wg set wg0 peer {key} allowed-ips 169.254.{hub_id}.0/24 endpoint {hub_external_ip}:{hub_external_port} persistent-keepalive 10")



async def removeByKey(key:str):
   await os_command_ignore(SSH + f' wg set wg0 peer {key} remove')
