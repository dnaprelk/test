import asyncio
import json
import logging
from typing import Dict
from hbmqtt.client import MQTTClient
from hbmqtt.mqtt.constants import QOS_0, QOS_1, QOS_2
from dataclasses import dataclass
import random

import config
import log_utils

log = logging.getLogger("MQTT")
log.setLevel(config.getMQTTLogLevel("base"))

logging.getLogger("amqtt").setLevel(config.getMQTTLogLevel("internal"))
logging.getLogger("transitions.core").setLevel(config.getMQTTLogLevel("internal"))



@dataclass(frozen=True)
class IncomingMessage:
   topic: str
   body: Dict


class MQTT:


   def __init__(self, sClientID):
      self.client = MQTTClient(client_id=sClientID + str(random.randint(1000, 65000)))


   async def connect(self, sBroker):
      log.info("Let's connect to " + sBroker)
      await self.client.connect("mqtt://" + sBroker)
      log.info("ok, connected.")


   async def subscribe(self, listTopics):
      log.info("We want subscribe on: " + str(listTopics))
      listSubscriptions = []
      for sTopic in listTopics:
         listSubscriptions.append((sTopic, QOS_0))
         await self.client.subscribe(listSubscriptions)
      log.info("ok, we've subscribed.")


   async def get(self):
      log.info("getMessage()")
      while True:
         try:
            message = await self.client.deliver_message(timeout=1)
            packet = message.publish_packet
            sTopic = packet.variable_header.topic_name
            sPayload = packet.payload.data.decode('utf-8')

            jsonMessage = json.loads(sPayload)
            incomingMessage = IncomingMessage(sTopic, jsonMessage)
            log.info(f"topic={sTopic} <=\n{log_utils.print_tree(jsonMessage)}")

            return incomingMessage
         except asyncio.TimeoutError:
            continue


   async def publish(self, sTopic, obj:Dict):
      log.info(sTopic + " ->\n" + log_utils.print_tree(obj))
      await self.client.publish(sTopic, json.dumps(obj).encode("utf8"))


   async def disconnect(self):
      log.info("Disconnecting...")
      await self.client.disconnect()
      log.info("ok, connection closed")


