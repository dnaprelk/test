import dataclasses
import logging
from dataclasses import dataclass
from typing import List, Optional
import os
import signal
from fastapi import FastAPI, Request
import asyncio
import inject
from tabulate import tabulate


import log_utils
from hubs import Hubs
from cpes import Cpes
from platforms import Platforms
from rest import Rest
from mqtt import MQTT_Dispatcher
import request_counter
import date_utils
import wireguard
import system_utils

VERSION = "0.003"
VERSION_DESCRIPTION = "if we lost CPE (offline) and it tries to ping us -> we send it reboot() command."


loop = asyncio.get_event_loop()


logging.basicConfig(
   level=logging.DEBUG,
   format='%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s - Line %(lineno)d'
   #format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s - Line %(lineno)d'
   #format = '\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)



log = logging.getLogger("MAIN")
logMonitor = logging.getLogger("MONITOR")


CONFM_URL   = os.environ.get("CONFM_URL")
MQTT_SERVER = os.environ.get("MQTT_SERVER")
SSH         = os.environ.get("SSH")

if CONFM_URL == None or MQTT_SERVER == None or SSH == None:
   log.critical(f"ERROR: You have to set CONFM_URL='{CONFM_URL}' & MQTT_SERVER='{MQTT_SERVER}' & SSH='{SSH}' env variables")
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)



app = FastAPI()







hubs = Hubs(CONFM_URL)
cpes = Cpes(CONFM_URL)
platforms = Platforms(CONFM_URL)

mqtt = MQTT_Dispatcher()



def configure(binder):
   binder.bind(Hubs, hubs)
   binder.bind(Cpes, cpes)
   binder.bind(Platforms, platforms)
   binder.bind(FastAPI, app)
   binder.bind(MQTT_Dispatcher, mqtt)
inject.configure(configure)

rest = Rest(CONFM_URL)





async def main():
   try:
      await rest.init()
      await wireguard.cleanAll()
      await hubs.init()
      await cpes.init()
      await platforms.init()
      await rest.init()
      await mqtt.start()
   except Exception as e:
      log.critical(log_utils.print_exception(e))
      system_utils.exit()

loop.create_task(main())


def markCpeOffline(cpe:Cpes.Cpe):
   dictWan = {}
   for interfaceNumber,interface in cpe.wan.items():
      dictWan[interfaceNumber] = Cpes.Cpe.Interface(status=Cpes.Cpe.Interface.Status.DOWN,
                                                    connection=interface.connection,
                                                    speed=interface.speed,
                                                    qos=interface.qos)
   return dataclasses.replace(cpe, ip=None, pubkey=None, wan=dictWan, currwan=None, status=Cpes.Cpe.Status.OFFLINE)


async def monitor():

   while True:
      rid: str = "monitor:" + str(await request_counter.increment())

      try:
         logTable = []

         for hub in await hubs.getAllList(rid):
            logTableRow = []
            logTable.append(logTableRow)

            logTableRow.append(hub.name)
            logTableRow.append(hub.id)
            logTableRow.append(hub.key)
            logTableRow.append(hub.state)
            logTableRow.append(hub.status)
            logTableRow.append(log_utils.print_date(hubs.getLastSeen(hub.name)))
            logTableRow.append(hub.ip)

            if hub.status == Hubs.Hub.Status.REGISTERED and (hubs.getLastSeen(hub.name) == None or hubs.getLastSeen(hub.name) + 30000 < date_utils.getTime()):
               await wireguard.removeByKey(hub.pubkey)
               await mqtt.updateHub(rid, dataclasses.replace(hub, ip=None, pubkey=None, status=Hubs.Hub.Status.OFFLINE))
               logTableRow.append("Registration TIMEOUT")

            if hub.status == Hubs.Hub.Status.ONLINE and (hubs.getLastSeen(hub.name) == None or hubs.getLastSeen(hub.name) + 10000 < date_utils.getTime()):
               await wireguard.removeByKey(hub.pubkey)
               await mqtt.updateHub(rid, dataclasses.replace(hub, ip=None, pubkey=None, status=Hubs.Hub.Status.OFFLINE))
               logTableRow.append("Online TIMEOUT")


         logMonitor.info("\n\nHUBs:\n" + tabulate(logTable, headers=["Name",
                                                                     "ID",
                                                                     "Key",
                                                                     "State",
                                                                     "Status",
                                                                     "Last seen",
                                                                     "IP",
                                                                     "Action"], tablefmt="grid"))

         logTable = []


         for cpe in await cpes.getAllList(rid):
            logTableRow = []
            logTable.append(logTableRow)

            logTableRow.append(cpe.name)
            logTableRow.append(cpe.id)
            logTableRow.append(cpe.key)
            logTableRow.append(cpe.hub)
            logTableRow.append(cpe.state)
            logTableRow.append(cpe.status)
            logTableRow.append(log_utils.print_date(cpes.getLastSeen(cpe.name)))
            logTableRow.append(cpe.ip)
            logTableRow.append(cpe.currwan)
            logTableRow.append(cpes.getVersion(cpe.name))

            if cpe.status == Cpes.Cpe.Status.REGISTERED and (cpes.getLastSeen(cpe.name) == None or cpes.getLastSeen(cpe.name) + 30000 < date_utils.getTime()):
               await mqtt.updateCpe(rid, markCpeOffline(cpe))
               logTableRow.append("Registration TIMEOUT")

            if cpe.status == Cpes.Cpe.Status.ONLINE and (cpes.getLastSeen(cpe.name) == None or cpes.getLastSeen(cpe.name) + 10000 < date_utils.getTime()):
               await mqtt.updateCpe(rid, markCpeOffline(cpe))
               logTableRow.append("Online TIMEOUT")


         logMonitor.info("\n\nCPEs:\n" + tabulate(logTable, headers=["Name",
                                                                     "ID",
                                                                     "Key",
                                                                     "Hub",
                                                                     "State",
                                                                     "Status",
                                                                     "Last seen",
                                                                     "IP",
                                                                     "WAN",
                                                                     "Version",
                                                                     "Action"], tablefmt="grid"))
      except Exception as e:
         log.critical(f"[{rid}] {log_utils.print_exception(e)}")

      await asyncio.sleep(1)
loop.create_task(monitor())
