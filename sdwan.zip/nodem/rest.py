import dataclasses
import json
import logging
from dataclasses import dataclass
from typing import List, Optional, Dict
import os
import signal
from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import JSONResponse, Response
import inject
from from_dict import from_dict



import config
import log_utils
import request_counter
import http_utils

from hubs import Hubs
from cpes import Cpes
from platforms import Platforms
from mqtt import MQTT_Dispatcher


log = logging.getLogger("REST")
log.setLevel(config.getLogLevel("rest"))



async def set_body(request: Request, body: bytes):
   async def receive():
      return {"type": "http.request", "body": body}

   request._receive = receive


async def get_body(request: Request) -> bytes:
   body = await request.body()
   await set_body(request, body)
   return body


class Rest:

   @dataclass(frozen=True)
   class RequestRegisterHub:
      key:str
      pubkey:str
   @dataclass(frozen=True)
   class ResponseHubConfig:
      id: int
      master_pubkey: str
      master_wg_port: int
      local_wg_port: int

   @dataclass(frozen=True)
   class RequestRegisterNode:
      key: str
      pubkey: str
      currwan: int
      version: float

   @dataclass(frozen=True)
   class ResponseNodeConfig:
      id: int
      domain: str
      hub_pubkey: str
      hub_ip: str
      hub_id: int
      hub_port: int
      uplinks: Dict
      platform: str

      @dataclass(frozen=True)
      class Agent:
         min_version: float
         distrib: str
         sha: str
      agent: Agent



   @inject.autoparams()
   def __init__(self, CONFM_URL:str, app:FastAPI=None):
      self.CONFM_URL = CONFM_URL

      @app.middleware("http")
      async def custom_middleware(request: Request, call_next):
         request.state.rid = "rest:" + str(await request_counter.increment())

         await set_body(request, await request.body())

         log.info(f"\n\n\n\n\n[{request.state.rid}]-----------------Incoming Request (begin)---------------------\n"
                  f"Method: {request.method}\n"
                  f"URL: {request.url}\n"
                  f"Headers: {request.headers}\n"
                  f"Query Parameters: {request.query_params}\n"
                  f"Path Parameters: {request.path_params}\n"
                  f"Client Host: {request.client.host}\n"
                  f"Received Data: {await request.body()}\n"
                  f"[{request.state.rid}]------------------Incoming Request (end)----------------------\n\n\n\n\n")

         response = await call_next(request)


         response_body = b""
         async for chunk in response.body_iterator:
            response_body += chunk

         log.info(f"[{request.state.rid}] Response:\n{response_body.decode()}")

         response.headers["RID"] = "rest:" + str(request.state.rid)

         return Response(content=response_body,
                         status_code=response.status_code,
                         headers=dict(response.headers),
                         media_type=response.media_type)


   @inject.autoparams()
   async def init(self,
                  app:FastAPI=None,
                  hubs:Hubs=None,
                  cpes:Cpes=None,
                  platforms:Platforms=None,
                  mqtt:MQTT_Dispatcher=None):

      RID = "InitRest:" + str(await(request_counter.increment()))
      sResponse: str = await http_utils.get_request(RID, self.CONFM_URL + "/api/v1.0/admin/agents", 2)

      jsonAgents = json.loads(sResponse)

      agent:Rest.ResponseNodeConfig.Agent = from_dict(Rest.ResponseNodeConfig.Agent, jsonAgents["cpe"])




      @app.post('/api/v1.0/nodem/hub/register')
      async def registerHub(request: Request, registerHub: Rest.RequestRegisterHub) -> Dict[str, Rest.ResponseHubConfig]:
         log.info("registerHub()\n" + log_utils.print_object_tree(registerHub))

         ip = request.headers.get("X-Forwarded-For")
         if ip == None:
            ip = request.client.host

         hub:Hubs.Hub = next(filter(lambda hub: hub.key == registerHub.key, await hubs.getAllList(request.state.rid)), None)

         if hub is None:
            log.error(f"[{request.state.rid}] Hub with key='{registerHub.key}' not found.")
            raise HTTPException(status_code=404)

         log.debug(f"[{request.state.rid}] Hub with key='{registerHub.key}' found. Name='{hub.name}' ID={hub.id}")

         if hub.state == Hubs.Hub.State.DISABLED:
            log.error(f"[{request.state.rid}] Hub name='{hub.name}' is DISABLED.")
            raise HTTPException(status_code=500)

         if hub.status == Hubs.Hub.Status.ONLINE:
            log.error(f"[{request.state.rid}] Hub name='{hub.name}' is already online. Rejected!")
            raise HTTPException(status_code=500)

         if hub.status == Hubs.Hub.Status.REGISTERED:
            log.error(f"[{request.state.rid}] Hub name='{hub.name}' is already registered. Rejected!")
            raise HTTPException(status_code=500)

         log.info(f"[{request.state.rid}] ok, Hub name='{hub.name}' is offline is ready for registration.")

         updatedHub = dataclasses.replace(hub, ip=ip, pubkey=registerHub.pubkey,  status=Hubs.Hub.Status.REGISTERED)
         await mqtt.updateHub(request.state.rid, updatedHub)

         return {hub.name:Rest.ResponseHubConfig(hub.id,
                                                 jsonAgents["nodem"]["publicKey"],
                                                 jsonAgents["nodem"]["wireguardPort"],
                                                 hub.port)}








      @app.post("/api/v1.0/nodem/node/register")
      async def registerNode(request: Request, registerNode: Rest.RequestRegisterNode) -> Dict[str, Rest.ResponseNodeConfig]:
         log.info("registerNode()\n" + log_utils.print_object_tree(registerNode))

         ip = request.headers.get("X-Forwarded-For")
         if ip == None:
            ip = request.client.host


         cpe:Cpes.Cpe = next(filter(lambda cpe: cpe.key == registerNode.key, await cpes.getAllList(request.state.rid)), None)

         if cpe is None:
            log.error(f"[{request.state.rid}] Cpe with key='{registerNode.key}' not found.")
            raise HTTPException(status_code=404)
         log.debug(f"[{request.state.rid}] Cpe with key='{registerNode.key}' found. Name='{cpe.name}' ID={cpe.id}")

         if cpe.state == Cpes.Cpe.State.DISABLED:
            log.error(f"[{request.state.rid}] Cpe name='{cpe.name}' is DISABLED.")
            raise HTTPException(status_code=500)

         if cpe.status != Cpes.Cpe.status.OFFLINE:
            log.error(f"[{request.state.rid}] Cpe name='{cpe.name}' status should be OFFLINE. Now it is {cpe.status}. Rejected!")
            raise HTTPException(status_code=500)

         log.info(f"[{request.state.rid}] Cpe name='{cpe.name}' is offline. Your registration is welcome.")

         hub:Hubs.Hub = await hubs.getByName(request.state.rid, cpe.hub)
         if hub == None:
            log.error(f"[{request.state.rid}] A Hub for Cpe='{cpe.name}' is NOT FOUND. Rejected.")
            raise HTTPException(status_code=404)
         log.debug(f"[{request.state.rid}] Hub for Cpe name='{cpe.name}' found. It is '{hub.name}' HubId={hub.id}")

         if hub.status != Hubs.Hub.Status.ONLINE:
            log.error(f"[{request.state.rid}] Hub name='{hub.name}' for Cpe='{cpe.name}' status should be ONLINE. Now it is {hub.status}. Rejected!")
            raise HTTPException(status_code=500)
         log.info(f"[{request.state.rid}] Hub for Cpe name='{cpe.name}' found and online. Let's register the Cpe.")

         cpes.setVersion(request.state.rid, cpe.name, registerNode.version)

         updatedCpe = dataclasses.replace(cpe,
                                          ip=ip,
                                          pubkey=registerNode.pubkey,
                                          currwan=registerNode.currwan,
                                          status=Hubs.Hub.Status.REGISTERED)
         await mqtt.updateCpe(request.state.rid, updatedCpe)


         return {cpe.name:Rest.ResponseNodeConfig(id=cpe.id,
                                                  domain=cpe.domain,
                                                  hub_pubkey=hub.pubkey,
                                                  hub_id=hub.id,
                                                  hub_ip=hub.ip,
                                                  hub_port=hub.port,
                                                  uplinks=cpe.wan,
                                                  platform=cpe.platform,
                                                  agent=agent)}






      @app.get("/admin/logs/set/mqtt-internal/{level}")
      async def setLogInternalMQTT(level:str):
         logging.getLogger("amqtt").setLevel(level)
         logging.getLogger("transitions.core").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/mqtt/{level}")
      async def setLogMQTT(level:str):
         logging.getLogger("MQTT").setLevel(level)
         logging.getLogger("MQTT_DISPATCHER").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/rest/{level}")
      async def setLogRest(level:str):
         logging.getLogger("REST").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/model/{level}")
      async def setLogModel(level:str):
         logging.getLogger("CPES").setLevel(level)
         logging.getLogger("HUBS").setLevel(level)
         logging.getLogger("PLATFORMS").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/monitoring/{level}")
      async def setLogModel(level:str):
         logging.getLogger("MONITOR").setLevel(level)
         return "ok"

      @app.get("/admin/mqtt/outgoing_events")
      async def adminOutgoingEvents(request: Request) -> List:
         return await mqtt.getOutgoingEvents()
      @app.get("/admin/mqtt/outgoing_events_length")
      async def adminOutgoingEventLength(request: Request) -> int:
         return len(await mqtt.getOutgoingEvents())
