import time


def getTime():
   return int(time.time() * 1000)