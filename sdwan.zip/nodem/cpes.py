import json
import logging
import sys
import traceback
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional
from from_dict import from_dict


import config
import http_utils
import log_utils
from abstract import Abstract

log = logging.getLogger("CPES")
log.setLevel(config.getLogLevel("cpes"))


class Cpes(Abstract):

   @dataclass(frozen=True)
   class Cpe:
      name: str
      id: int
      uuid: str
      domain: str
      key: str
      hub: str

      class State(str, Enum):
         ENABLED = "enabled"
         DISABLED = "disabled"
      state: State

      platform: str

      @dataclass(frozen=True)
      class Interface:
         connection: Dict

         class Status(str, Enum):
            UP = "up"
            DOWN = "down"
         status: Optional[Status] = None
         speed: Optional[int] = None

         @dataclass(frozen=True)
         class QOS:
            priority: int
            min: float
            max: float
            className: str

         qos: Optional[List[QOS]] = None

      wan: Dict[int, Interface]
      description: Optional[str] = None

      class Status(str, Enum):
         OFFLINE = "offline"
         REGISTERED = "registered"
         ONLINE = "online"
      status: Optional[Status] = Status.OFFLINE

      currwan: Optional[int] = None
      ip: Optional[str] = None
      pubkey: Optional[str] = None
      online_at: Optional[int] = None


   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, Cpes.Cpe] = {}
      self.dictID:  Dict[int, Cpes.Cpe] = {}

      self.dictLastSeen = {}
      self.versions = {}



   async def init(self):
      RID = "initCPEs"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/nodes', 2)

      dictNodes = json.loads(sResponse)


      for sCpeName in dictNodes.keys():
         dictNodes[sCpeName]["name"] = sCpeName
         try:
            cpe = from_dict(Cpes.Cpe, dictNodes[sCpeName])
            await self.addDB(RID, cpe)
         except Exception as e:
            log.critical(f"\n{log_utils.print_tree(dictNodes[sCpeName])}\n{str(e)}\n" + "\n".join(traceback.format_tb(e.__traceback__)))

            sys.exit(-1)

      log.info(f"\n{self.printList(list(self.dictName.values()))}\n")



   def printOne(self, cpe:Cpe):
      tree = log_utils.Tree("CPE")
      root = tree.getRoot()
      root.addNode(f"id={cpe.id}")
      root.addNode(f"uuid={cpe.uuid}")
      root.addNode(f"description={cpe.description}")
      root.addNode(f"domain={cpe.domain}")
      root.addNode(f"key={cpe.key}")
      root.addNode(f"hub={cpe.hub}")
      root.addNode(f"ip={cpe.ip}")
      root.addNode(f"pubkey={cpe.pubkey}")
      root.addNode(f"state={cpe.state}")
      root.addNode(f"status={cpe.status}")
      root.addNode(f"platform={cpe.platform}")
      root.addNode(f"currwan={cpe.currwan}")
      root.addNode(f"online_at={log_utils.print_date(cpe.online_at)}")
      nodeWANs = root.addNode("WAN")
      for sWanName, wan in cpe.wan.items():
         wan = cpe.wan[sWanName]
         nodeWAN = nodeWANs.addNode(str(sWanName))
         nodeWAN.addNode(f"speed={wan.speed}")
         nodeWAN.addNode(f"status={wan.status}")
         nodeWANConnection = nodeWAN.addNode("connection")
         nodeWANConnection.addNode(f"{wan.connection}")
         nodeWANQos = nodeWAN.addNode("qos")
         if wan.qos is not None:
            for qos in wan.qos:
               nodeWANQosPriority = nodeWANQos.addNode(f"priority={qos.priority}")
               nodeWANQosPriority.addNode(f"min={qos.min}")
               nodeWANQosPriority.addNode(f"max={qos.max}")
               nodeWANQosPriority.addNode(f"className={qos.className}")
         else:
            nodeWANQos.addNode("---")

      return tree.print()



   def printList(self, listCpes: List[Cpe]) -> str:
      tree = log_utils.Tree("CPEs")
      root = tree.getRoot()

      for cpe in listCpes:
         try:
            nodeNode = root.addNode(cpe.name)
            nodeNode.addNode(f"id={cpe.id}")
            nodeNode.addNode(f"uuid={cpe.uuid}")
            nodeNode.addNode(f"description={cpe.description}")
            nodeNode.addNode(f"domain={cpe.domain}")
            nodeNode.addNode(f"key={cpe.key}")
            nodeNode.addNode(f"hub={cpe.hub}")
            nodeNode.addNode(f"ip={cpe.ip}")
            nodeNode.addNode(f"pubkey={cpe.pubkey}")
            nodeNode.addNode(f"state={cpe.state}")
            nodeNode.addNode(f"status={cpe.status}")
            nodeNode.addNode(f"platform={cpe.platform}")
            nodeNode.addNode(f"currwan={cpe.currwan}")
            nodeNode.addNode(f"online_at={log_utils.print_date(cpe.online_at)}")
            nodeWANs = nodeNode.addNode("WAN")
            for sWanName, wan in cpe.wan.items():
               wan = cpe.wan[sWanName]
               nodeWAN = nodeWANs.addNode(str(sWanName))
               nodeWAN.addNode(f"speed={wan.speed}")
               nodeWAN.addNode(f"status={wan.status}")
               nodeWANConnection = nodeWAN.addNode("connection")
               nodeWANConnection.addNode(f"{wan.connection}")
               nodeWANQos = nodeWAN.addNode("qos")
               if wan.qos is not None:
                  for qos in wan.qos:
                     nodeWANQosPriority = nodeWANQos.addNode(f"priority={qos.priority}")
                     nodeWANQosPriority.addNode(f"min={qos.min}")
                     nodeWANQosPriority.addNode(f"max={qos.max}")
                     nodeWANQosPriority.addNode(f"className={qos.className}")
               else:
                  nodeWANQos.addNode("---")
         except Exception as e:
            log.error(e)
            log.error(cpe)

      return tree.print()


   def getLastSeen(self, name):
      if name in self.dictLastSeen:
         return self.dictLastSeen[name]
      else:
         return None
   def setLastSeen(self, rid:str, name:str, time:int):
      log.debug(f"[{rid}] setLastSeen() time={log_utils.print_date(time)}")
      self.dictLastSeen[name] = time


   def getVersion(self, name):
      if name in self.versions:
         return self.versions[name]
      else:
         return None
   def setVersion(self, rid:str, name:str, version:float):
      log.debug(f"[{rid}] setVersion() version={version}")
      self.versions[name] = version
