import aiohttp
import asyncio
import logging

import config

log = logging.getLogger("HTTP")
log.setLevel(config.getLogLevel("http"))


class HttpServerException(Exception):
   def __init__(self, code:int, message:str):
      super().__init__(f"code={code} message='{message}'")
class HttpTimeoutException(Exception):
   pass
class HttpClientException(Exception):
   pass
class HttpUnknownException(Exception):
   pass

async def get_request(rid:str, url, timeout:int) -> str:
   log.info(f"[{rid}] GET-> {url}")
   async with aiohttp.ClientSession() as session:
      try:
         async with session.get(url, allow_redirects=True, timeout=timeout) as response:
            if response.status == 200:
               sResponse:str = await response.text(encoding="utf8")

               log.info(f"[{rid}] <= {sResponse}")

               return sResponse
            else:
               raise HttpServerException(response.status, await response.text("utf8"))
      except asyncio.TimeoutError:
         raise HttpTimeoutException()
      except aiohttp.ClientError as e:
         raise HttpClientException(f"{str(e)}")
      except Exception as e:
         raise HttpUnknownException(f"{str(e)}")




async def post_request(rid:str, url, data, timeout:int):
   log.info(f"[{rid}] POST-> {url}")
   async with aiohttp.ClientSession() as session:
      try:
         async with session.post(url, json=data, timeout=timeout) as response:
            if response.status == 200:
               return await response.text(encoding="utf8")
            else:
               raise HttpServerException(response.status, await response.text("utf8"))
      except asyncio.TimeoutError:
         raise HttpTimeoutException()
      except aiohttp.ClientError as e:
         raise HttpClientException(f"{str(e)}")
      except Exception as e:
         raise HttpUnknownException(f"{str(e)}")
