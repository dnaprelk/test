#!/usr/bin/env python
#
# Copyright (c) 2022, Alexey I. Kolyaskin
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
# * Redistributions in binary form must reproduce the above copyright notice, this
#   list of conditions and the following disclaimer in the documentation and/or
#   other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import subprocess
import configparser
import requests
import json
import time
import paho.mqtt.client as mqtt
import os, signal
import socket
import signal
import psutil
import sys
import threading
import logging
import traceback
from datetime import datetime
from tabulate import tabulate

logging.basicConfig(
    level=logging.DEBUG,
    # format='%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s - Line %(lineno)d'
    format='%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s'
    # format = '\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)
log = logging.getLogger("MAIN")
logWatcher = logging.getLogger("WATCHER")
logMQTT = logging.getLogger("MQTT")
logMQTT.setLevel(logging.ERROR)

dictPeer2Cpe = {}
dictCpe2Peer = {}


def get_wireguard_peers(interface_name):
    try:
        result = subprocess.run(['wg', 'show', interface_name], capture_output=True, text=True, check=True)
        listTextPeers = result.stdout.split("\n\n")
        # peer_info = [line for line in peer_info if line.startswith('peer')]

        # print(peer_info)
        listPeers = []
        for sPeerText in listTextPeers:
            lines = sPeerText.split("\n")
            peer = None
            endpoint = None
            allowed_ips = None

            for line in lines:
                if line.startswith("peer: "):
                    peer = line.split("peer: ")[1].strip()
                elif line.startswith("  endpoint: "):
                    endpoint = line.split("  endpoint: ")[1].strip()
                elif line.startswith("  allowed ips: "):
                    allowed_ips = line.split("  allowed ips: ")[1].strip()
                    if allowed_ips == "(none)":
                        allowed_ips = None

                        # print("Peer:", peer)
            # print("Endpoint:", endpoint)
            # print("Allowed IPs:", allowed_ips)
            if peer is not None:
                listPeers.append({"peer": peer, "endpoint": endpoint, "ip": allowed_ips})

        return listPeers

    except subprocess.CalledProcessError as e:
        # Handle any errors, such as if the WireGuard interface doesn't exist
        print(f"Error: {e}")
        return []


interface_name = 'wg0'


def watcher():
    listPeers = get_wireguard_peers(interface_name)

    arrRows = []
    for peer in listPeers:
        arrRow = []
        arrRows.append(arrRow);
        arrRow.append(peer["peer"])
        arrRow.append(peer["endpoint"])
        arrRow.append(peer["ip"])
        arrRow.append(dictPeer2Cpe[peer["peer"]] if peer["peer"] in dictPeer2Cpe else "---")

        if peer["ip"] == None:
            arrRow.append("*REMOVE*")
            os.system(f"wg set {interface_name} peer {peer['peer']} remove")
        else:
            arrRow.append("KEEP")

    logWatcher.info("\n\nPEERs:\n" + tabulate(arrRows, headers=["Key",
                                                                "Endpoint",
                                                                "IP",
                                                                "CPE",
                                                                "Action"], tablefmt="grid"))

    threading.Timer(1, watcher).start()


threading.Timer(1, watcher).start()


#
# SIGTERM handler
#

def signal_handler(signum, frame):
    print('\nTerminating...')
    client.disconnect()
    os.system('wg-quick down /root/wg0.conf')
    os.system('firewall-cmd --zone=public --remove-port 51820/udp')
    os.system('firewall-cmd --zone=trusted --remove-interface=wg0')
    os.system('ip link del dev wg0')
    print('...done!')
    quit()


class Hub():
    prikey = ''
    pubkey = ''
    local_wg_port = ''
    machineid = ''
    master_pubkey = ''
    master_host = ''
    master_ip = ''
    master_wg_port = ''
    state = 'offline'
    fail_ping_count = 0
    tenant = ''

    def __init__(self):
        config = configparser.ConfigParser()
        config.read('../etc/master.conf')
        self.master_host = config['Master']['Host']
        self.tenant = config['Master']['Tenant']
        self.prikey = subprocess.check_output(["wg", "genkey"]).rstrip().decode("utf-8")
        cmd = 'echo %s | wg pubkey' % (self.prikey)
        self.pubkey = subprocess.check_output(cmd, shell=True).rstrip().decode("utf-8")
        self.machineid = subprocess.check_output(["cat", "/etc/machine-id"]).rstrip().decode("utf-8")
        os.system('ip link add dev wg0 type wireguard')
        os.system('firewall-cmd --zone=public --add-port 51820/udp')
        os.system('firewall-cmd --zone=trusted --add-interface=wg0')

    def register(self):
        msg = {
            'key': self.machineid,
            'pubkey': self.pubkey
        }

        url = 'https://%s/%s/register/hub' % (self.master_host, self.tenant)
        #        url = 'https://%s/register/hub' % (self.master_host)
        print(url)
        print(json.dumps(msg))

        try:
            response = requests.post(url, json=msg)
            data = response.json()
            print(data)
            h = list(data.keys())[0]

            self.id = data[h]['id']
            self.name = h
            self.master_pubkey = data[h]['master_pubkey']
            self.master_wg_port = data[h]['master_wg_port']
            self.local_wg_port = data[h]['local_wg_port']
            self.master_ip = socket.gethostbyname(self.master_host)
            print('IP: ', self.master_ip)

            cmd = 'hostnamectl set-hostname %s.local' % (self.name)
            os.system(cmd)

            result = '[Interface]\n'
            result += 'ListenPort = %s\n' % (self.local_wg_port)
            result += 'PrivateKey = %s\n' % (self.prikey)

            result += '[Peer]\n'
            result += 'PublicKey = %s\n' % (self.master_pubkey)
            result += 'AllowedIPs = 169.254.0.1\n'
            result += 'Endpoint = %s:%s\n' % (self.master_ip, self.master_wg_port)
            result += 'PersistentKeepalive = 10\n'

            wg_conf = open('wg0.conf', 'w')
            wg_conf.write('%s' % result)
            wg_conf.close()

            os.system('wg setconf wg0 wg0.conf')
            cmd = 'ip address replace 169.254.%d.254/16 dev wg0' % (self.id)
            os.system(cmd)
            os.system('ip link set up dev wg0')

            self.state = 'registered'
            return True
        except:
            self.state = 'offline'
            return False

    def update_peers(self):
        url = 'https://%s/api/v1.0/nodem/peers/%s' % (self.master_host, self.name)
        print('Update peers %s') % (self.name)

        result = '[Peer]\n'
        result += 'PublicKey = %s\n' % (self.master_pubkey)
        result += 'AllowedIPs = 169.254.0.1\n'
        result += 'Endpoint = %s:%s\n' % (self.master_ip, self.master_port)
        result += 'PersistentKeepalive = 10\n'
        result += '\n'

        try:
            response = requests.get(url)
            data = response.json()
            print(data)

            for d in data['peers']:
                result += '[Peer]\n'
                result += 'PublicKey = %s\n' % (d['pubkey'])
                result += 'AllowedIPs = 169.254.%d.254\n' % (d['id'])
                result += 'Endpoint = %s:51820\n' % (d['ip'])
                result += 'PersistentKeepalive = 10\n'
                result += '\n'

            wg_conf = open('wg0.conf', 'w')
            wg_conf.write('%s' % result)
            wg_conf.close()

            os.system('wg addconf wg0 wg0.conf')

            cmd = 'wg show wg0 allowed-ips\n'
            res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)

            for line in res.stdout:
                arg = line.split('\t')
                if arg[1].rstrip() == '(none)':
                    cmd = 'wg set wg0 peer %s remove' % (arg[0])
                    os.system(cmd)

        except:
            wg_conf = open('wg0.conf', 'w')
            wg_conf.write('%s' % result)
            wg_conf.close()

            os.system('wg addconf wg0 wg0.conf')

    def check_uplink(self):
        cmd = 'fping -C 1 -q 169.254.0.1 2>&1'
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        r = p.communicate()[0].decode("utf-8")
        data = r.rstrip().replace(' ', '').split(':')

        if data[1] == '-':
            hub.fail_ping_count = hub.fail_ping_count + 1

            if hub.fail_ping_count == 5:
                hub.state = 'offline'
        else:
            hub.fail_ping_count = 0
            net = psutil.net_io_counters(pernic=True)
            result = {
                hub.name: {
                    'status': 'online',
                    'delay': float(data[1]),
                    'cpu': psutil.cpu_percent(),
                    'mem': psutil.virtual_memory()[2],
                    'disk': psutil.disk_usage('/')[3],
                    'uplink_tx': net['wg0'][0],
                    'uplink_rx': net['wg0'][1]
                }
            }
            topic = 'hub/' + hub.name + '/ping'
            client.publish(topic, json.dumps(result), 0)


hub = Hub()


def on_connect(client, userdata, flags, rc):
    print('Connected with result code ' + str(rc))
    client.subscribe('confm/#')
    client.subscribe('nodem/#')
    client.subscribe('admin/#')
    client.subscribe(hub.name + '/#')
    hub.state = 'online'
    result = '{ \"' + hub.name + '\": { \"status\": \"online\" } }'
    client.publish('hub/update', result, 0)


def on_disconnect(client, userdata, rc):
    print('Broker failure')
    hub.state = 'offline'


def on_message(client, userdata, msg):
    try:
        topic = msg.topic.split('/')
        m = json.loads(msg.payload)
        print('MQTT: ' + msg.topic + ' ' + json.dumps(m, indent=4, sort_keys=True))

        #
        # Message from node manager
        #
        if topic[0] == 'confm':
            #
            # Update message
            #
            if topic[1] == 'update':
                #
                # Update node
                #
                if topic[2] == 'node':
                    uuid = m["uuid"]
                    dictData = m["message"]

                    n = list(dictData.keys())[0]
                    #
                    # Update node wg info for the just registered node
                    #
                    if dictData[n]['status'] == 'registered':
                        print('Update peer %s' % (dictData))

                        dictCpe2Peer[n] = dictData[n]['pubkey']
                        dictPeer2Cpe[dictData[n]['pubkey']] = n

                        result = '[Peer]\n'
                        result += 'PublicKey = %s\n' % (dictData[n]['pubkey'])
                        result += 'AllowedIPs = 169.254.%d.%d\n' % (hub.id, dictData[n]['id'])
                        result += 'PersistentKeepalive = 10\n'

                        print(result)

                        wg_conf = open('peer.conf', 'w')
                        wg_conf.write('%s' % result)
                        wg_conf.close()

                        os.system('wg addconf wg0 peer.conf')
                    #
                    # Remove offline node
                    #
        if topic[0] == 'confm':
            uuid = m["uuid"]
            message = m["message"]
            n = list(message.keys())[0]
            obj = message[n]

            #
            # Update message
            #
            if topic[1] == 'update':
                #
                # Update node
                #
                if topic[2] == 'node':
                    # if obj['status'] == 'offline':
                    #    if n in dictCpe2Peer[n]:
                    #        os.system(f"wg set {interface_name} peer {dictCpe2Peer[n]} remove")
                    #        del dictPeer2Cpe[dictCpe2Peer[n]]
                    #        del dictCpe2Peer[n]
                    #
                    # Remove disabled node
                    #
                    if obj['state'] == 'disabled':
                        if n in dictCpe2Peer[n]:
                            os.system(f"wg set {interface_name} peer {dictCpe2Peer[n]} remove")
                            del dictPeer2Cpe[dictCpe2Peer[n]]
                            del dictCpe2Peer[n]

        if topic[0] == 'admin':
            if topic[1] == 'reset':
                if topic[2] == 'system':
                    print("Let's stop process.")
                    sig = getattr(signal, "SIGKILL", signal.SIGTERM)
                    os.kill(os.getpid(), sig)
            if topic[1] == 'reboot':
                if topic[2] == 'hub':
                    if m["name"] == hub.name:
                        print("Let's reboot hub.")
                        os.system("reboot")
    except Exception as e:
        print(f"{e} {type(e)}\n" + "\n".join(traceback.format_tb(e.__traceback__)))


client = mqtt.Client(hub.machineid)

print('Master: ', hub.master_ip)

signal.signal(signal.SIGINT, signal_handler)

while True:
    #    try:
    #       result = {hub.name: {"status":  hub.state} }
    #       client.publish('hub/update', json.dumps(result), 0)
    #    except Exception:
    #       pass

    if hub.state == 'offline':
        if client:
            client.disconnect()
            del client
            client = mqtt.Client(hub.machineid)
            client.on_connect = on_connect
            client.on_disconnect = on_disconnect
            client.on_message = on_message

        print('Registering hub')
        if hub.register() == True:
            print('Hub registered successfully')
        else:
            print('Hub registration fail')
            time.sleep(1)

    if hub.state == 'registered':
        reg_time = time.time()

        while time.time() < (reg_time + 30):
            print('Setting up message broker connection')

            try:
                client.connect('169.254.0.1')
                client.loop_start()
                hub.state = 'connected'
                reg_time = 0
                print('Hub connected to the message broker')
                time.sleep(1)
            except:
                print('Unable to connect to the message broker')
                time.sleep(1)

    if hub.state == 'connected':
        print('Waiting for message from node manager')
        conn_time = time.time()

        while time.time() < (conn_time + 30):
            if hub.state != 'online':
                time.sleep(1)

    if hub.state == 'online':
        hub.check_uplink()
        time.sleep(1)

    print('Current hub state: ', hub.state)
