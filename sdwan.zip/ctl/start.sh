#!/bin/bash
PYTHONPATH=".:/usr/lib64/python2.7/:$PYTHONPATH" ryu-manager --verbose ctl
