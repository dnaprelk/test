#!/usr/bin/env python

import json
import logging
from webob import Response
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller import dpset
from ryu.controller.handler import HANDSHAKE_DISPATCHER
from ryu.controller.handler import CONFIG_DISPATCHER
from ryu.controller.handler import MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import ether_types
from ryu.app.wsgi import ControllerBase, WSGIApplication, route
from datetime import datetime

#for logger_name in logging.Logger.manager.loggerDict:
#   print(logger_name)
#   logging.getLogger(logger_name).setLevel(10)


class Forwarder(app_manager.RyuApp):
    _CONTEXTS = {'wsgi': WSGIApplication}
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(Forwarder, self).__init__(*args, **kwargs)
        self.switch = {}
        self.vid_to_dpid = {}
        self.service = {}

        wsgi = kwargs['wsgi']
        wsgi.register(ForwarderRestController, {'forwarder_app': self})

    #
    # FeatureResponse handler
    #
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        self.switch[datapath.id] = {
                'dp': datapath,
                'ports': { }
            }

    #
    # PortDesc reply handler
    #
    @set_ev_cls(ofp_event.EventOFPPortDescStatsReply, CONFIG_DISPATCHER)
    def switch_portdesc_handler(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # delete all flows
        self.delete_all_flows(datapath)

        # install default flows
        self.add_default_flows(datapath)

        for p in datapath.ports:
            name = datapath.ports[p].name
            port = datapath.ports[p].port_no

            # if not local OVS port
            if name != 'br0':
                match = parser.OFPMatch(in_port=port)

                # OVS tunnel port
                if name == 'tun0':
                    self.switch[datapath.id]['ports'][port] = {
                            'name': name,
                            'cookie': 0
                        }
                    actions = [parser.NXActionRegMove(src_field='tunnel_id', dst_field='metadata', n_bits=32, src_ofs=0, dst_ofs=0)]
                    inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions), parser.OFPInstructionGotoTable(2)]
                    mod = parser.OFPFlowMod(datapath=datapath, cookie=0, command=ofproto.OFPFC_ADD, table_id=0, priority=65535, match=match, instructions=inst)
                    # send FlowMod to the switch
                    datapath.send_msg(mod)

                # VNF port
                else:
                    if name[:2] != 've':
                        return

                    vid = int('00'+name[2:], 16)
                    self.vid_to_dpid[vid] = datapath.id
                    self.switch[datapath.id]['ports'][port] = {
                            'name': name,
                            'cookie': vid
                        }
                    inst = [parser.OFPInstructionWriteMetadata(vid, 0xffffffff),parser.OFPInstructionGotoTable(1)]
                    mod = parser.OFPFlowMod(datapath=datapath, cookie=vid, command=ofproto.OFPFC_ADD, table_id=0, priority=65535, match=match, instructions=inst)
                    # send FlowMod to the switch
                    datapath.send_msg(mod)

                    # for each service
                    for service_id in self.service:
                        # for each endpoint in service
                        for entry in self.service[service_id]:
                            # if VNF port is exists
                            if vid == entry['vid']:
                                self.delete_service(service_id)
                                self.update_service(service_id)

    #
    # PackeIn handler
    #
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        src = eth.src

        time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')
        print('%s: Packet_in from DPID %08X:%s src %0s dst %s' % (time, int(datapath.id), self.switch[datapath.id]['ports'][port]['name'], eth.src, eth.dst))

        try:
            vid = msg.match['metadata']
        except:
            print('%X' % (msg.data))

        # Packet from OVS tunnel port
        if self.switch[datapath.id]['ports'][port]['name'] == 'tun0':
            tun_src = msg.match['tun_ipv4_src']

#           match = parser.OFPMatch(eth_dst=src, metadata=vid)
            match = parser.OFPMatch(eth_dst=src)
            actions = [parser.NXActionRegMove(src_field='metadata', dst_field='tunnel_id', n_bits=32, src_ofs=0, dst_ofs=0), parser.OFPActionSetField(tun_ipv4_dst=tun_src), parser.OFPActionOutput(port=port)]
            inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
            mod = parser.OFPFlowMod(datapath=datapath, cookie=vid, idle_timeout=300, table_id=3, priority=65535, match=match, instructions=inst)
            datapath.send_msg(mod)

            match = parser.OFPMatch(in_port=port, eth_src=src)
            inst = [parser.OFPInstructionGotoTable(3)]
            mod = parser.OFPFlowMod(datapath=datapath, cookie=vid, idle_timeout=300, table_id=2, priority=65535, match=match, instructions=inst)
            datapath.send_msg(mod)

        # Packet from VNF port
        else:
#           match = parser.OFPMatch(eth_dst=src, metadata=vid)
            match = parser.OFPMatch(eth_dst=src)
            actions = [parser.OFPActionOutput(port=port)]
            inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
            mod = parser.OFPFlowMod(datapath=datapath, cookie=vid, idle_timeout=300, table_id=3, priority=65535, match=match, instructions=inst)
            datapath.send_msg(mod)

            match = parser.OFPMatch(in_port=port, eth_src=src)
            inst = [parser.OFPInstructionGotoTable(3)]
            mod = parser.OFPFlowMod(datapath=datapath, cookie=vid, idle_timeout=300, table_id=2, priority=65535, match=match, instructions=inst)
            datapath.send_msg(mod)

    #
    # PortAdd handler
    #
    @set_ev_cls(dpset.EventPortAdd)
    def switch_port_add_handler(self, ev):
        datapath = ev.dp
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        port = ev.port.port_no

        name = ev.port.name
        vid = int('00'+name[2:], 16)
        self.vid_to_dpid[vid] = datapath.id
        self.switch[datapath.id]['ports'][port] = { 'name': name, 'cookie': vid }

        time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')
        print('%s: Port_add from DPID %08X:%s' % (time, int(datapath.id), self.switch[datapath.id]['ports'][port]['name']))

        match = parser.OFPMatch(in_port=port)
        inst = [parser.OFPInstructionWriteMetadata(vid, 0xffffffff), parser.OFPInstructionGotoTable(1)]
        mod = parser.OFPFlowMod(datapath=datapath, cookie=vid, command=0, table_id=0, priority=65535, match=match, instructions=inst)
        datapath.send_msg(mod)

        # for each service
        for service_id in self.service:
            # for each endpoint in service
            for entry in self.service[service_id]:
                # if VNF port is exists
                if vid == entry['vid']:
                    self.delete_service(service_id)
                    self.update_service(service_id)
                    break

    #
    # PortMod handler
    #
    @set_ev_cls(dpset.EventPortModify)
    def switch_port_modify_handler(self, event):
        print('Port modify')

    #
    # PortDelete handler
    #
    @set_ev_cls(dpset.EventPortDelete)
    def switch_port_delete_handler(self, ev):
        datapath = ev.dp
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        port = ev.port.port_no

        time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')
        print('%s: Port_delete from DPID %08X:%s' % (time, int(datapath.id), self.switch[datapath.id]['ports'][port]['name']))

        cookie = self.switch[datapath.id]['ports'][port]['cookie']
        mod = parser.OFPFlowMod(datapath=datapath, table_id=0, cookie=cookie, cookie_mask=0xffffffff, command=ofproto.OFPFC_DELETE, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
        datapath.send_msg(mod)

        mod = parser.OFPFlowMod(datapath=datapath, table_id=2, cookie=cookie, cookie_mask=0xffffffff, command=ofproto.OFPFC_DELETE, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
        datapath.send_msg(mod)

        mod = parser.OFPFlowMod(datapath=datapath, table_id=3, cookie=cookie, cookie_mask=0xffffffff, command=ofproto.OFPFC_DELETE, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
        datapath.send_msg(mod)

        name = self.switch[datapath.id]['ports'][port]['name']
        vid = int('00'+name[2:], 16)

        # for each service
        for service_id in self.service:
            # for each endpoint in service
            for entry in self.service[service_id]:
                # if VNF port is exists
                if vid == entry['vid']:
                    # delete service flows from table 1
                    mod = parser.OFPFlowMod(datapath=datapath, table_id=1, cookie=int(service_id, 16), cookie_mask=0xffffffff, command=ofproto.OFPFC_DELETE, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
                    datapath.send_msg(mod)
                    self.update_service(service_id)

        del self.vid_to_dpid[vid]
        del self.switch[datapath.id]['ports'][port]

    #
    # Delete all flows
    #
    def delete_all_flows(self, datapath):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # delete all flows
        mod = parser.OFPFlowMod(datapath=datapath, table_id=datapath.ofproto.OFPTT_ALL, command=ofproto.OFPFC_DELETE, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
        datapath.send_msg(mod)

        # delete all flood groups
        mod = parser.OFPGroupMod(datapath=datapath, command=ofproto.OFPGC_DELETE,  group_id=0xfffffffc)
        datapath.send_msg(mod)

    #
    # Add default drop rules to the switch
    #
    def add_default_flows(self, datapath):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # cookie=0x0, table=0, priority=0 actions=drop
        mod = parser.OFPFlowMod(datapath=datapath, cookie=0x0, table_id=0, priority=0, match=None, instructions=None)
        datapath.send_msg(mod)

        # cookie=0x0, table=1, priority=0 actions=drop
        mod = parser.OFPFlowMod(datapath=datapath, cookie=0x0, table_id=1, priority=0, match=None, instructions=None)
        datapath.send_msg(mod)

        # cookie=0x0, table=2, priority=0 actions=CONTROLLER:256,goto_table:3
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, 256)]
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions), parser.OFPInstructionGotoTable(3)]
        mod = parser.OFPFlowMod(datapath=datapath, cookie=0x0, table_id=2, priority=0, match=None, instructions=inst)
        datapath.send_msg(mod)

        # cookie=0x0, table=3, priority=0 actions=drop
        mod = parser.OFPFlowMod(datapath=datapath, cookie=0x0, table_id=3, priority=0, match=None, instructions=None)
        datapath.send_msg(mod)

    #
    # Delete service
    #
    def delete_service(self, service_id):
        print('Delete service!')
        sid = int(service_id, 16)

        # for each endpoint in service
        for entry in self.service[service_id]:
            # if VNF port is exists
            if entry['vid'] in self.vid_to_dpid:
                # get datapath object by VNF port
                dpid = self.vid_to_dpid[entry['vid']]
                datapath = self.switch[dpid]['dp']
                vid = entry['vid']
                name = 've%06X' % vid
                for p in self.switch[dpid]['ports']:
                    if self.switch[dpid]['ports'][p]['name'] == name:
                        port = p

                ofproto = datapath.ofproto
                parser = datapath.ofproto_parser

                # delete flows in the table 1
                match = parser.OFPMatch(metadata=vid)
                mod = parser.OFPFlowMod(datapath=datapath, cookie=sid, cookie_mask=0xffffffff, table_id=1, command=ofproto.OFPFC_DELETE, match=match, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
                datapath.send_msg(mod)

                # delete flood group
                mod = parser.OFPGroupMod(datapath=datapath, command=ofproto.OFPGC_DELETE, type_=ofproto.OFPGT_ALL, group_id=sid, buckets='')
                datapath.send_msg(mod)

                # delete flows in the table 2
                mod = parser.OFPFlowMod(datapath=datapath, cookie=sid, cookie_mask=0xffffffff, table_id=2, command=ofproto.OFPFC_DELETE, out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY)
                datapath.send_msg(mod)

                # delete flows in the table 3
                match = parser.OFPMatch(metadata=sid)
                mod = parser.OFPFlowMod(datapath=datapath, cookie=sid, cookie_mask=0xffffffff, table_id=1, command=ofproto.OFPFC_DELETE, match=match, out_port=ofproto.OFPP_ANY, out_group=sid)
                datapath.send_msg(mod)

    #
    # Update service
    #
    def update_service(self, service_id):
        print('Update service!')
        sid = int(service_id, 16)
        # for each endpoint in service
        for entry in self.service[service_id]:
            # if VNF port is exists
            if entry['vid'] in self.vid_to_dpid:
                # get datapath object by VNF port
                dpid = self.vid_to_dpid[entry['vid']]
                datapath = self.switch[dpid]['dp']
                vid = entry['vid']
                name = 've%06X' % vid
                for p in self.switch[dpid]['ports']:
                    if self.switch[dpid]['ports'][p]['name'] == name:
                        port = p

                ofproto = datapath.ofproto
                parser = datapath.ofproto_parser

                # add flow to the table 1
                for m in entry['match']:
                    match_string = { 'metadata': vid }
                    for m1 in m:
                        ent = m1.split('=')

                        if ent[0] == 'eth_src':
                            match_string['eth_src'] = int(ent[1].replace(':', ''), 16)
                        if ent[0] == 'eth_dst':
                            match_string['eth_dst'] = int(ent[1].replace(':', ''), 16)
                        if ent[0] == 'eth_type':
                            match_string['eth_type'] = int(ent[1], 16)
                        if ent[0] == 'ip_proto':
                            match_string['ip_proto'] = int(ent[1])
                        if ent[0] == 'ipv4_src':
                            match_string['ipv4_src'] = int(ent[1], 16)
                        if ent[0] == 'ipv4_dst':
                            match_string['ipv4_dst'] = int(ent[1], 16)
                        if ent[0] == 'tcp_src':
                            match_string['tcp_src'] = int(ent[1])
                        if ent[0] == 'tcp_dst':
                            match_string['tcp_dst'] = int(ent[1])
                        if ent[0] == 'udp_src':
                            match_string['udp_src'] = int(ent[1])
                        if ent[0] == 'udp_dst':
                            match_string['udp_dst'] = int(ent[1])

                    print(match_string)
                    match = parser.OFPMatch(**match_string)
                    inst = [parser.OFPInstructionWriteMetadata(sid, 0xffffffff), parser.OFPInstructionGotoTable(2)]
                    mod = parser.OFPFlowMod(datapath=datapath, cookie=sid, table_id=1, priority=65535, match=match, instructions=inst)
                    datapath.send_msg(mod)

                # delete all flood groups
                mod = parser.OFPGroupMod(datapath=datapath, command=ofproto.OFPGC_DELETE,  group_id=sid)
                datapath.send_msg(mod)
                # add service flood group
                mod = parser.OFPGroupMod(datapath=datapath, command=ofproto.OFPGC_ADD, type_=ofproto.OFPGT_ALL, group_id=sid, buckets='')
                datapath.send_msg(mod)

                # add flow to the table 3
                match = parser.OFPMatch(metadata=sid)
                actions = [parser.OFPActionGroup(group_id=sid)]
                inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
                mod = parser.OFPFlowMod(datapath=datapath, cookie=sid, table_id=3, priority=32767, match=match, instructions=inst)
                datapath.send_msg(mod)

                actions = [parser.OFPActionOutput(port=port)]
                buckets = [parser.OFPBucket(actions=actions, len_=len(actions))]

                for e in self.service[service_id]:
                    if e['vid'] != vid:
                        if e['vid'] in self.vid_to_dpid:
                            g_dpid = self.vid_to_dpid[e['vid']]
                            # remote endpoint
                            if g_dpid != dpid:
                                actions = [parser.NXActionRegMove(src_field='metadata', dst_field='tunnel_id', n_bits=32, src_ofs=0, dst_ofs=0), parser.OFPActionSetField(tun_ipv4_dst=g_dpid), parser.OFPActionOutput(port=1)]
                                buckets.append(parser.OFPBucket(actions=actions, len_=len(actions)))
                            # local endpoint
                            else:
                                name = 've%06X' % e['vid']
                                for p in self.switch[dpid]['ports']:
                                    if self.switch[dpid]['ports'][p]['name'] == name:
                                        port = p
                                actions = [parser.OFPActionOutput(port=port)]
                                buckets.append(parser.OFPBucket(actions=actions, len_=len(actions)))
                mod = parser.OFPGroupMod(datapath=datapath, command=ofproto.OFPGC_MODIFY, type_=ofproto.OFPGT_ALL, group_id=sid, buckets=buckets)
                datapath.send_msg(mod)


#
# REST API controller
#
class ForwarderRestController(ControllerBase):
    def __init__(self, req, link, data, **config):
        super(ForwarderRestController, self).__init__(req, link, data, **config)
        self.forwarder_app = data['forwarder_app']

    # Get all services
    @route('forwarder', '/service', methods=['GET'])
    def get_services(self, req, **kwargs):
#        print('Get all services')
        return Response(content_type='application/json', body=json.dumps(self.forwarder_app.service, indent=4))

    # Get service
    @route('forwarder', '/service/{sid}', methods=['GET'], requirements={'sid': r'[0-9a-fA-F]{4}'})
    def get_service(self, req, **kwargs):
#        print('Get service %s' % kwargs['sid'])
        sid = kwargs['sid']
        if sid in self.forwarder_app.service:
            return Response(content_type='application/json', body=json.dumps(self.forwarder_app.service[sid], indent=4))
        else:
            return Response(status=404)

    # Create service
    @route('forwarder', '/service/{sid}', methods=['POST'], requirements={'sid': r'[0-9a-fA-F]{4}'})
    def create_service(self, req, **kwargs):
        print('Create service %s' % kwargs['sid'])
        sid = kwargs['sid']
        self.forwarder_app.service[sid] = req.json
        self.forwarder_app.update_service(sid)
        return Response(content_type='application/json', body=json.dumps(self.forwarder_app.service[sid], indent=4))

    # Modify service
    @route('forwarder', '/service/{sid}', methods=['PUT'], requirements={'sid': r'[0-9a-fA-F]{4}'})
    def modify_service(self, req, **kwargs):
        print('Modify service %s' % kwargs['sid'])
        sid = kwargs['sid']
        self.forwarder_app.service[sid] = req.json
        self.forwarder_app.update_service(sid)
        return Response(content_type='application/json', body=json.dumps(self.forwarder_app.service[sid], indent=4))

    # Delete service
    @route('forwarder', '/service/{sid}', methods=['DELETE'], requirements={'sid': r'[0-9a-fA-F]{4}'})
    def delete_service(self, req, **kwargs):
        print('Delete service %s' % kwargs['sid'])
        sid = kwargs['sid']
        self.forwarder_app.delete_service(sid)
        del self.forwarder_app.service[sid]
        return Response(status=200)
