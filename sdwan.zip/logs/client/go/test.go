package main

import (
	"bufio"
	"flag"
	"fmt"
	"github.com/fluent/fluent-logger-golang/fluent"
	"io"
	"log"
	"os"
	"strings"
	"time"
)

const (
	serverURL       = "https://reg.sdwan.mts.ru/log/test"
	retryInterval   = 5 * time.Second // Retry every 5 seconds
	tempStoragePath = "/tmp/tempdata.txt"
	BUFFER_LENGTH   = 500
)

var buffer []string

func main() {
	tenant := flag.String("tenant", "unknown", "Tenant name")
	cpe := flag.String("cpe", "unknown", "CPE name")

	flag.Parse()

	//	logger, err := fluent.New(fluent.Config{FluentPort: 53199, FluentHost: "91.185.88.123"})

	// Create Fluentd logger with TLS config
	logger, err := fluent.New(fluent.Config{
		FluentPort:            53199,
		FluentHost:            "logs.sdwan.mts.ru",
		FluentNetwork:         "tls",
		TlsInsecureSkipVerify: true,
	})

	if err != nil {
		log.Fatalf("Failed to create Fluentd logger: %v", err)
	}

	for {
		processInput(logger, tenant, cpe)
	}
}

func processInput(logger *fluent.Fluent, tenant *string, cpe *string) {
	scanner := bufio.NewScanner(os.Stdin)

	for scanner.Scan() {
		if len(buffer) > BUFFER_LENGTH {
			var sText = strings.Join(buffer, "\n")
			for !retrySendingData(logger, tenant, cpe) {
				time.Sleep(retryInterval)
			}

			if sendDataToServer(logger, tenant, cpe, []byte(sText)) {
				buffer = []string{}
			} else {
				saveDataToFile([]byte(sText))
			}
		}
		buffer = append(buffer, scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		fmt.Fprintln(os.Stderr, "reading standard input:", err)
	}
}

func sendDataToServer(logger *fluent.Fluent, tenant *string, cpe *string, data []byte) bool {
	//resp, err := http.Post(serverURL, "application/octet-stream", bytes.NewReader(data))
	//if err != nil {
	//	fmt.Println("Error sending data to server:", err)
	//	return false
	//} else {
	//	fmt.Println("Data sent ok")
	//}
	//defer resp.Body.Close()
	//
	//if resp.StatusCode != http.StatusOK {
	//	return false
	//}
	//return true

	//defer logger.Close()

	message := map[string]interface{}{
		"message": data,
		"tenant":  *tenant,
		"msgid":   *cpe,
	}

	tag := "sdwan.cpe"

	if err := logger.Post(tag, message); err != nil {
		//		log.Fatalf("Failed to post message with tag %s: %v", tag, err)
		return false
	}

	return true
}

func saveDataToFile(data []byte) {
	file, err := os.OpenFile(tempStoragePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		//		fmt.Println("Error opening file:", err)
		return
	}

	if _, err := file.Write(append(data, '\n')); err != nil {
		//		fmt.Println("Error writing to file:", err)
	} else {
		//		fmt.Println("File saved")
	}

	defer file.Close()
}

func retrySendingData(logger *fluent.Fluent, tenant *string, cpe *string) bool {
	file, err := os.Open(tempStoragePath)
	if err != nil {
		//		fmt.Println("Error opening file:", err)
		return true
	}

	//	fmt.Println("File exists")

	// Check if the file is empty
	fileInfo, err := file.Stat()
	if err != nil || fileInfo.Size() == 0 {
		file.Close()
		return true
	}

	data := make([]byte, fileInfo.Size())
	_, err = file.Read(data)
	defer file.Close()

	if err != nil && err != io.EOF {
		//		fmt.Println("Error reading file:", err)
		return false
	}

	fmt.Println("Data read")

	if sendDataToServer(logger, tenant, cpe, data) {
		//		fmt.Println("Let's remove the file")
		os.Remove(tempStoragePath)
		return true
	}

	return true
}
