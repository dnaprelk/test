import logging
from typing import List
import inject
from fastapi import FastAPI, Request

import config
from mqtt import MQTT_Dispatcher

log = logging.getLogger("REST")
log.setLevel(config.getLogLevel("rest"))


class Rest:
   @inject.autoparams()
   async def init(self,
                  app:FastAPI=None,
                  mqtt:MQTT_Dispatcher=None):


      @app.get("/admin/logs/set/mqtt-internal/{level}")
      async def setLogInternalMQTT(level:str):
         logging.getLogger("amqtt").setLevel(level)
         logging.getLogger("transitions.core").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/mqtt/{level}")
      async def setLogMQTT(level:str):
         logging.getLogger("MQTT").setLevel(level)
         logging.getLogger("MQTT_DISPATCHER").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/rest/{level}")
      async def setLogRest(level:str):
         logging.getLogger("REST").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/model/{level}")
      async def setLogModel(level:str):
         logging.getLogger("CPES").setLevel(level)
         logging.getLogger("VNFS").setLevel(level)
         logging.getLogger("VNFTEMPLATES").setLevel(level)
         logging.getLogger("PLATFORMS").setLevel(level)
         logging.getLogger("SERVICES").setLevel(level)
         logging.getLogger("SERVICETEMPLATES").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/monitoring/{level}")
      async def setLogModel(level:str):
         logging.getLogger("MONITOR").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/http/{level}")
      async def setLogModel(level:str):
         logging.getLogger("HTTP").setLevel(level)
         return "ok"


      @app.get("/admin/logs/set/service_monitoring/{level}")
      async def setLogServiceMonitoring(level:str):
         logging.getLogger("SERVICE_MONITOR").setLevel(level)
         return "ok"



      @app.get("/admin/mqtt/outgoing_events")
      async def adminOutgoingEvents(request: Request) -> List:
         return await mqtt.getOutgoingEvents()
      @app.get("/admin/mqtt/outgoing_events_length")
      async def adminOutgoingEventLength(request: Request) -> int:
         return len(await mqtt.getOutgoingEvents())
