import copy
import json
import logging
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional

import inject
from from_dict import from_dict
from tabulate import tabulate

import config
import exceptions
import log_utils
from abstract import Abstract
import http_utils

log = logging.getLogger("VNFS")
log.setLevel(config.getLogLevel("vnfs"))



class Vnfs(Abstract):

   @dataclass(frozen=True)
   class Vnf:
      id: int
      uuid: str
      name: str
      domain: str
      template: str

      class State(str, Enum):
         ENABLED = "enabled"
         DISABLED = "disabled"

      state: State

      config: Dict
      ports: Dict

      class Status(str, Enum):
         STOPPED = "stopped"
         STOPPING = "stopping"
         STOP_EXPIRED = "stop_expired"
         RUNNING = "running"
         EXPIRED = "expired"
         TIMEOUT = "timeout"
         STARTING = "starting"
         START_EXPIRED = "start_expired"
         REBOOT_STOPPING = "reboot_stopping"
         REBOOT_STARTING = "reboot_starting"
      status:Optional[Status] = Status.STOPPED

      node:Optional[str] = None
      description: Optional[str] = None
      uptime: Optional[int] = None



   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, Vnfs.Vnf] = {}
      self.dictID:  Dict[int, Vnfs.Vnf] = {}

      self.dictLastSeen = {}
      self.dictLastError = {}





   async def init(self):
      RID = "initVnfs"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/vnfs', 2)

      dictVnfs = json.loads(sResponse)

      for sVnfName in dictVnfs.keys():
         dictVnfs[sVnfName]["name"] = sVnfName
         vnf = from_dict(Vnfs.Vnf, dictVnfs[sVnfName])

         await self.addDB(RID, vnf)

      log.info("\n" + self.printList(list(self.dictName.values())))









   def printOne(self, vnf:Vnf):
      tree = log_utils.Tree(f"VNF {vnf.name}")
      root = tree.getRoot()
      root.addNode(f"id={vnf.id}")
      root.addNode(f"uuid={vnf.uuid}")
      root.addNode(f"description={vnf.description}")
      root.addNode(f"state={vnf.state}")
      root.addNode(f"status={vnf.status}")
      root.addNode(f"node={vnf.node}")
      root.addNode(f"domain={vnf.domain}")
      root.addNode(f"template={vnf.template}")
      return tree.print()




   def printList(self, listPlatforms:List[Vnf]) -> str:
      logTable = []

      for vnf in listPlatforms:
         logTable.append([vnf.name,
                          f"id={vnf.id}\nuuid={vnf.uuid}",
                          vnf.description,
                          vnf.template,
                          vnf.status,
                          vnf.state,
                          vnf.domain,
                          vnf.node,
                          log_utils.print_tree(vnf.config),
                          log_utils.print_tree(vnf.ports)])

      return tabulate(logTable, headers=["Name",
                                         "ID/UUID",
                                         "Description",
                                         "Template",
                                         "Status",
                                         "State",
                                         "Domain",
                                         "Node",
                                         "Config",
                                         "Ports"], tablefmt="grid")



   def getLastSeen(self, name):
      if name in self.dictLastSeen:
         return self.dictLastSeen[name]
      else:
         return None
   def setLastSeen(self, rid:str, name:str, time:int):
      log.debug(f"[{rid}] setLastSeen() time={log_utils.print_date(time)}")
      self.dictLastSeen[name] = time



   def getLastError(self, name):
      if name in self.dictLastError:
         return self.dictLastError[name]
      else:
         return None
   def setLastError(self, rid:str, name:str, time:int):
      log.debug(f"[{rid}] setLastError() time={log_utils.print_date(time)}")
      self.dictLastError[name] = time


