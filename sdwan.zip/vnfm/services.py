import copy
import json
import logging
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional

import inject
from from_dict import from_dict
from tabulate import tabulate

import config
import exceptions
import log_utils
from abstract import Abstract
import http_utils

log = logging.getLogger("SERVICES")
log.setLevel(config.getLogLevel("services"))


class Services(Abstract):

   @dataclass(frozen=True)
   class Service:
      name: str
      id: int
      uuid: str
      priority: int

      class State(str, Enum):
         ENABLED = "enabled"
         DISABLED = "disabled"
      state: State

      template: str

      @dataclass(frozen=True)
      class Endpoint:
         vnf: str

         class Type(str, Enum):
            SERVER = "server"
            CLIENT = "client"
            ALL = "all"
         type: Type

         uuid: str
         port: int
      endpoints: List[Endpoint]

      class Status(Enum):
         DOWN   = "down"
         NORMAL = "normal"
      status:Optional[Status] = Status.DOWN

      description: Optional[str] = None



   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, Services.Service] = {}
      self.dictID:  Dict[int, Services.Service] = {}




   async def init(self):
      RID = "initVnfs"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/services', 2)

      dictServices = json.loads(sResponse)

      for sServiceName in dictServices.keys():
         dictServices[sServiceName]["name"] = sServiceName
         vnf = from_dict(Services.Service, dictServices[sServiceName])

         await self.addDB(RID, vnf)

      log.info("\n" + self.printList(list(self.dictName.values())))




   def printOne(self, service:Service):
      tree = log_utils.Tree(f"SERVICE {service.name}")
      root = tree.getRoot()
      root.addNode(f"id={service.id}")
      root.addNode(f"uuid={service.uuid}")
      root.addNode(f"description={service.description}")
      root.addNode(f"template={service.template}")
      root.addNode(f"endpoints={service.endpoints}")
      root.addNode(f"state={service.state}")
      root.addNode(f"status={service.status}")

      return tree.print()


   def printList(self, listServices:List[Service]) -> str:
      logTable = []

      for service in listServices:

         logTable.append([service.name,
                          service.id,
                          service.uuid,
                          service.priority,
                          service.template,
                          service.description,
                          service.state,
                          service.status,
                          "\n".join(str(endpoint) for endpoint in service.endpoints)
                         ])

      return tabulate(logTable, headers=["Name",
                                         "ID",
                                         "UUID",
                                         "Priority",
                                         "Template",
                                         "Description",
                                         "State",
                                         "Status",
                                         "Endpoints"], tablefmt="grid")
