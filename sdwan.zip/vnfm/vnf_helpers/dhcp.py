#!/usr/bin/python

import sys
import json

data = json.load(sys.stdin)

script = '#!/bin/ash\n\n'

if 'dhcp' in data:
	if ('dhcpIp' in data['dhcp']) and ('dhcpMask' in data['dhcp']) and ('dhcpGateway' in data['dhcp']):
		script += 'ifconfig eth0 %s %s up\n' % (data['dhcp']['dhcpIp'], data['dhcp']['dhcpMask'])
		script += 'route add default gw %s\n\n' % (data['dhcp']['dhcpGateway'])

		if 'dhcpPool' in data['dhcp']:
			if ('mask' in data['dhcp']['dhcpPool']) and ('poolStart' in data['dhcp']['dhcpPool']) and ('poolEnd' in data['dhcp']['dhcpPool']) and ('gateway' in data['dhcp']['dhcpPool']) and ('dns1' in data['dhcp']['dhcpPool']) and ('dns2' in data['dhcp']['dhcpPool']) and ('leaseTime' in data['dhcp']['dhcpPool']):
				script += 'cat > /etc/dhcp/dhcpd.conf << EOF\n'
				script += 'default-lease-time %d;\n' % (data['dhcp']['dhcpPool']['leaseTime'])
				script += 'max-lease-time 7200;\n'
				script += 'subnet %s netmask %s {\n' % (data['dhcp']['dhcpPool']['subnet'], data['dhcp']['dhcpPool']['mask'])
				script += '  range %s %s;\n' % (data['dhcp']['dhcpPool']['poolStart'], data['dhcp']['dhcpPool']['poolEnd'])
				script += '  option routers %s;\n' % (data['dhcp']['dhcpPool']['gateway'])
				script += '  option domain-name-servers %s' % (data['dhcp']['dhcpPool']['dns1'])
				if data['dhcp']['dhcpPool']['dns2'] != '':
					script += ', %s;\n' % (data['dhcp']['dhcpPool']['dns2'])
				else:
					script += ';\n'
				script += '}\n'
				script += 'EOF\n\n'
				script += 'systemctl start dhcpd\n'
print(script, end=' ')

