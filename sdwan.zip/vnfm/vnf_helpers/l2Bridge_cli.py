#!/usr/bin/python

import sys
import json

config = sys.stdin.read()
config = config.replace('""', '"______"')
data = json.loads(config)
output = ''

if 'l2Bridge' in data:
	if 'vlans' in data['l2Bridge']:
		for i in data['l2Bridge']['vlans']:
			output += '      eth%d - ' % (i['interface'])

			if i['vlanId'] == 0:
				output += 'untagged\n'
			else:
				output += 'VLAN %d\n' % (i['vlanId'])

print(output[:-1], end=' ')
