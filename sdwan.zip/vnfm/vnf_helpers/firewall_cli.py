#!/usr/bin/python

import sys
import json

config = sys.stdin.read()
config = config.replace('""', '"______"')
data = json.loads(config)
output = ''

if 'firewall' in data:
	if 'firewallConfig' in data['firewall']:
		for i in data['firewall']['firewallConfig']:
			if ('interface' in i) and ('ip' in i) and ('mask' in i) and ('gateway' in i):
				output += '      '

				if i['gateway'] != None:
					output += 'Outside: %s/%s gw %s\n' % (i['ip'], i['mask'], i['gateway'])
				else:
					output += 'Inside:  %s/%s\n' % (i['ip'], i['mask'])

		output += '\n      '
		output += 'Rules:\n      '
		output += '  Source            Port  Protocol Destination       Port  Action\n'

	if 'securityRules' in data['firewall']:
		for i in data['firewall']['securityRules']:
			if ('protocol' in i) and ('sourceAddress' in i) and ('destinationAddress' in i) and ('sourcePort' in i) and ('destinationPort' in i) and ('ruleAction' in i):
				proto  = 'any'
				s_addr = '0.0.0.0/0'
				s_port = 'any'
				d_addr = '0.0.0.0/0'
				d_port = 'any'
				action = ''

				if i['protocol'] != None:
					if i['protocol'] == 'tcp':
						proto = 'TCP'
					elif i['protocol'] == 'ucp':
						proto= 'UDP'
					elif i['protocol'] == 'icmp':
						 proto = 'ICMP'
					else:
						proto = ''

				if i['sourceAddress'] != None:
					s_addr = '%s' % (i['sourceAddress'])

				if i['sourcePort'] not in [None, 0]:
					s_port = '%s' % (i['sourcePort'])

				if i['destinationAddress'] != None:
					d_addr = '%s' % (i['destinationAddress'])

				if i['destinationPort'] not in [None, 0]:
					d_port = '%s' % (i['destinationPort'])

				if i['ruleAction'] != None:
					if i['ruleAction'] == 'accept':
						action = 'ACCEPT'
					elif i['ruleAction'] == 'reject':
						action = 'REJECT'
					else:
						action = 'DROP'

				output += '      '
				output += '  %-17s %-5s %-8s %-17s %-5s %s\n' % (s_addr, s_port, proto, d_addr, d_port, action)

print(output, end=' ')
