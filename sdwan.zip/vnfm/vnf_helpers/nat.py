#!/usr/bin/python

import sys
import json

data = json.load(sys.stdin)

script = '#!/bin/ash\n\n'

if 'nat' in data:
   if 'natConfig' in data['nat']:
      for i in data['nat']['natConfig']:
         if ('interface' in i) and ('ip' in i) and ('mask' in i):
            script += 'ifconfig eth%d %s netmask %s up\n' % (i['interface'], i['ip'], i['mask'])
            if ('gateway' in i) and ('defaultGateway' in i) and (i['defaultGateway'] == True):
               script += 'route add default gw %s\n' % (i['gateway'])
               script += 'iptables-nft -t nat -A POSTROUTING -o eth%d -j MASQUERADE\n' % (i['interface'])
            script += '\n'
      script += 'echo 1 > /proc/sys/net/ipv4/ip_forward\n'

print(script, end=' ')
