#!/usr/bin/python

import sys
import json

config = sys.stdin.read()
config = config.replace('""', '"______"')
data = json.loads(config)
output = ''

if 'nat' in data:
	if 'natConfig' in data['nat']:
		for i in data['nat']['natConfig']:
			if ('interface' in i) and ('ip' in i) and ('mask' in i) and ('gateway' in i) and ('defaultGateway' in i):
				output += '      '

				if i['defaultGateway'] == True:
					output += 'eth%d (outside) %s/%s gw %s\n' % (i['interface'], i['ip'], i['mask'], i['gateway'])
				else:
					output += 'eth%d (inside)  %s/%s\n' % (i['interface'], i['ip'], i['mask'])

print(output, end=' ')
