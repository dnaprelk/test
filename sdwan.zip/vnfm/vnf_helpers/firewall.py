#!/usr/bin/python

import sys
import json

data = json.load(sys.stdin)

script = '#!/bin/ash\n\n'

if 'firewall' in data:
	if 'firewallConfig' in data['firewall']:
		for i in data['firewall']['firewallConfig']:
			if ('interface' in i) and ('ip' in i) and ('mask' in i) and ('gateway' in i):
				script += 'ifconfig eth%d %s/%s up\n' % (i['interface'], i['ip'], i['mask'])

				if i['gateway'] != None:
					script += 'route add default gw %s\n' % (i['gateway'])

				script += '\n'

	if 'securityRules' in data['firewall']:
		for i in data['firewall']['securityRules']:
			if ('protocol' in i) and ('sourceAddress' in i) and ('destinationAddress' in i) and ('sourcePort' in i) and ('destinationPort' in i) and ('ruleAction' in i):
				proto = ''
				s_addr = ''
				s_port = ''
				d_addr = ''
				d_port = ''
				action = ''

				if i['protocol'] != None:
					if i['protocol'] == 'tcp':
						proto = ' -p tcp'
					elif i['protocol'] == 'ucp':
						proto= ' -p udp'
					elif i['protocol'] == 'icmp':
						 proto = ' -p icmp'
					else:
						proto = ''

				if i['sourceAddress'] != None:
					s_addr = ' -s %s' % (i['sourceAddress'])

				if i['sourcePort'] not in [None, 0]:
					s_port = ' --sport %s' % (i['sourcePort'])

				if i['destinationAddress'] != None:
					d_addr = ' -d %s' % (i['destinationAddress'])

				if i['destinationPort'] not in [None, 0]:
					d_port = ' --dport %s' % (i['destinationPort'])

				if i['ruleAction'] != None:
					if i['ruleAction'] == 'accept':
						action = ' -J ACCEPT'
					elif i['ruleAction'] == 'reject':
						action = ' -J REJECT'
					else:
						action = ' -J DROP'

				script += 'iptables -I INPUT%s%s%s%s\n' % (proto, s_addr, s_port, action)
				script += 'iptables -I OUTPUT%s%s%s%s\n\n' % (proto, d_addr, d_port, action)

print(script, end=' ')
