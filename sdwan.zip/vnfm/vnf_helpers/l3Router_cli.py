#!/usr/bin/python

import sys
import json

config = sys.stdin.read()
config = config.replace('""', '"______"')
data = json.loads(config)
output = ''

if 'l3Router' in data:
	if 'l3EthConfig' in data['l3Router']:
		output += 'Interfaces:\n'

		for i in data['l3Router']['l3EthConfig']:
			if ('interface' in i) and ('ip' in i) and ('mask' in i):
				output += '  eth%d %s / %s\n' % (i['interface'], i['ip'], i['mask'])

				if 'alias' in i:
					if i['alias'] != None:
						for j in i['alias']:
							if ('aliasName' in j) and ('aliasIp' in j) and ('aliasMask' in j):
								script += 'ifconfig eth%d:%d %s %s up\n' % (i['interface'], j['aliasName'], j['aliasIp'], j['aliasMask'])

	if 'staticRoutes' in data['l3Router']:
		if data['l3Router']['staticRoutes'] != None:
			output += 'Routing table:\n'

			for i in data['l3Router']['staticRoutes']:
				if ('ip' in i) and ('mask' in i) and ('gateway' in i) and ('metric' in i):
					output += '  %s %s via %s metric %d\n' % (i['ip'], i['mask'], i['gateway'], i['metric'])

print(output, end=' ')
