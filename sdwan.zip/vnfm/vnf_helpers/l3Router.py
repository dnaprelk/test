#!/usr/bin/python

import sys
import json

data = json.load(sys.stdin)

script = '#!/bin/ash\n\n'

if 'l3Router' in data:
	if 'l3EthConfig' in data['l3Router']:
		for i in data['l3Router']['l3EthConfig']:
			if ('interface' in i) and ('ip' in i) and ('mask' in i):
				script += 'ifconfig eth%d %s %s up\n' % (i['interface'], i['ip'], i['mask'])

				if 'alias' in i:
					if i['alias'] != None:
						for j in i['alias']:
							if ('aliasName' in j) and ('aliasIp' in j) and ('aliasMask' in j):
								script += 'ifconfig eth%d:%d %s %s up\n' % (i['interface'], j['aliasName'], j['aliasIp'], j['aliasMask'])

	if 'staticRoutes' in data['l3Router']:
		if data['l3Router']['staticRoutes'] != None:
			for i in data['l3Router']['staticRoutes']:
				if ('ip' in i) and ('mask' in i) and ('gateway' in i) and ('metric' in i):
					script += 'route add %s/%s gw %s metric %d\n' % (i['ip'], i['mask'], i['gateway'], i['metric'])

print(script, end=' ')

