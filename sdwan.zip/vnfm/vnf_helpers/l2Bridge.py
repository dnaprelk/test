#!/usr/bin/python

import sys
import json

data = json.load(sys.stdin)

script = '#!/bin/ash\n\n'

if 'l2Bridge' in data:
	if 'vlans' in data['l2Bridge']:
		for i in data['l2Bridge']['vlans']:
			script += 'ip link add name br%d type bridge\n' % (i['vlanId'])

			if i['vlanId'] == 0:
				script += 'ip link set lan0 master br0\n'
			else:
				script += 'ip link add link lan0 name lan0.%d type vlan id %d\n' % (i['vlanId'], i['vlanId'])
				script += 'ip link set dev lan0.%d up\n' % (i['vlanId'])
				script += 'ip link set lan0.%d master br%d\n' % (i['vlanId'], i['vlanId'])

			script += 'ip link set eth%d master br%d\n' % (i['interface'], i['vlanId'])
			script += 'ip link set dev br%d up\n\n' % (i['vlanId'])

print(script, end=' ')

