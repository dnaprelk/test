#!/usr/bin/python

import sys
import json

config = sys.stdin.read()
config = config.replace('""', '"______"')
data = json.loads(config)
output = ''

if 'dhcp' in data:
	if ('dhcpIp' in data['dhcp']) and ('dhcpMask' in data['dhcp']) and ('dhcpGateway' in data['dhcp']):
		output += '      Interface: %s/%s gateway %s\n' % (data['dhcp']['dhcpIp'], data['dhcp']['dhcpMask'], data['dhcp']['dhcpGateway'])
		if 'dhcpPool' in data['dhcp']:
			if ('mask' in data['dhcp']['dhcpPool']) and ('poolStart' in data['dhcp']['dhcpPool']) and ('poolEnd' in data['dhcp']['dhcpPool']) and ('gateway' in data['dhcp']['dhcpPool']) and ('dns1' in data['dhcp']['dhcpPool']) and ('dns2' in data['dhcp']['dhcpPool']) and ('leaseTime' in data['dhcp']['dhcpPool']):
				output += '      Pool: %s/%s\n' % (data['dhcp']['dhcpPool']['subnet'], data['dhcp']['dhcpPool']['mask'])
				output += '        range: %s - %s\n' % (data['dhcp']['dhcpPool']['poolStart'], data['dhcp']['dhcpPool']['poolEnd'])
				output += '        lease time: %d\n' % (data['dhcp']['dhcpPool']['leaseTime'])
				output += '        options:\n'
				output += '          routers %s\n' % (data['dhcp']['dhcpPool']['gateway'])
				output += '          domain-name-servers %s' % (data['dhcp']['dhcpPool']['dns1'])

				if data['dhcp']['dhcpPool']['dns2'] != '':
					output += ', %s\n' % (data['dhcp']['dhcpPool']['dns2'])
				else:
					output += '\n'

				for i in data['dhcp']['dhcpPool']['dchpOptions']:
					output += '          %s %s\n' % (i['optionNumber'], i['optionValue'])

print(output, end=' ')
