from dataclasses import dataclass, field
from typing import Dict, List, Optional
import logging
import asyncio
from tabulate import tabulate
import json
from pydantic import BaseModel
from from_dict import from_dict
from enum import Enum


import config
import log_utils
from abstract import Abstract
import http_utils

log = logging.getLogger("PLATFORMS")
log.setLevel(config.getLogLevel("platforms"))


class Platforms(Abstract):

   @dataclass(frozen=True)
   class Platform:
      name: str

      @dataclass(frozen=True)
      class Interface:
         ifname:str

         class Type(Enum):
            ETH = "ETH"
            WIFI = "WIFI"
         type:Type

         x:int
         y:int
         speed:Optional[int] = None

         def __str__(self):
            return f"{self.ifname}\n{self.type}\n{self.speed}"

      wan: Dict[int, Interface]
      lan: Dict[int, Interface]


   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, Platforms.Platform] = {}


   async def init(self):
      RID = "initPlatforms"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/platforms', 2)

      dictPlatforms = json.loads(sResponse)


      for sPlatformName in dictPlatforms.keys():
         dictPlatforms[sPlatformName]["name"] = sPlatformName
         platform = from_dict(Platforms.Platform, dictPlatforms[sPlatformName])
         self.dictName[sPlatformName] = platform

      log.info("\n" + self.printList(list(self.dictName.values())))


   def printOne(self, platform:Platform):
      logTable = []
      logTable.append([platform.name,
                       '\n'.join(f"\n{key}:{value}" for key, value in platform.wan.items()),
                       '\n'.join(f"\n{key}:{value}" for key, value in platform.lan.items())])

      return tabulate(logTable, headers=["Name", "WAN", "LAN", "Config file"], tablefmt="grid")


   def printList(self, listPlatforms:List[Platform]) -> str:
      logTable = []
      for platform in listPlatforms:
         logTable.append([platform.name,
                          '\n'.join(f"\n{key}:{value}" for key, value in platform.wan.items()),
                          '\n'.join(f"\n{key}:{value}" for key, value in platform.lan.items())])


      return tabulate(logTable, headers=["Name", "WAN", "LAN", "Config file"], tablefmt="grid")

