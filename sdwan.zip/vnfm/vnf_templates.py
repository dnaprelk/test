import copy
import json
import logging
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional

import inject
from from_dict import from_dict
from tabulate import tabulate

import config
import exceptions
import log_utils
from abstract import Abstract
import http_utils

log = logging.getLogger("VNF_TEMPLATES")
log.setLevel(config.getLogLevel("vnf_templates"))



class VnfTemplates(Abstract):

   @dataclass(frozen=True)
   class VnfTemplate:

      name:str

      @dataclass(frozen=True)
      class Type(str,Enum):
         dhcp = "dhcp"
         l2Bridge = "l2Bridge"
         firewall = "firewall"
         l3Router = "l3Router"
         port8_switch = "8 port switch"
         nat = "nat"
      type: Type

      config:Dict
      ports:Dict

      @dataclass(frozen=True)
      class Image:
         name:str
         size:int
         sha:str
      image:Image



   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, VnfTemplates.VnfTemplate] = {}





   async def init(self):
      RID = "initVnfTemplates"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/vnf_templates', 2)

      dictVnfs = json.loads(sResponse)

      for sVnfName in dictVnfs.keys():
         dictVnfs[sVnfName]["name"] = sVnfName
         vnf_template = from_dict(VnfTemplates.VnfTemplate, dictVnfs[sVnfName])
         await self.addDB(RID, vnf_template)

      log.info("\n" + self.printList(list(self.dictName.values())))






   def printOne(self, vnfTemplate:VnfTemplate):
      tree = log_utils.Tree(f"VNF TEMPLATE: '{vnfTemplate.name}'")
      root = tree.getRoot()
      root.addNode(f"type={vnfTemplate.type}")
      root.addNode(f"config={vnfTemplate.config}")
      root.addNode(f"ports={vnfTemplate.ports}")
      return tree.print()

   def printList(self, listVnfTemplates:List[VnfTemplate]) -> str:
      logTable = []

      for vnfTemplate in listVnfTemplates:
         logTable.append([vnfTemplate.name,
                          vnfTemplate.type,
                          log_utils.print_tree(vnfTemplate.config),
                          log_utils.print_tree(vnfTemplate.ports)])

      return tabulate(logTable, headers=["Name", "Type", "Config", "Ports"], tablefmt="grid")


