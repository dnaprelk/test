import asyncio
import uuid

from injector import inject
import logging
import dataclasses
import json
import inject
import os
from from_dict import from_dict
from dataclasses import dataclass
from typing import Dict, List, Set, Optional



from platforms import Platforms
from vnfs import Vnfs
from cpes import Cpes
from services import Services
from service_templates import ServiceTemplates



import config
from mqtt_utils import MQTT
import request_counter
import log_utils
import date_utils
import dict_utils
import system_utils
import exceptions

loop = asyncio.get_event_loop()


log = logging.getLogger("MQTT_DISPATCHER")
log.setLevel(config.getLogLevel("mqtt"))


SERVICE_ID_NODE_MANAGER = "node_manager"
SERVICE_ID_VNF_MANAGER = "vnf_manager"
SERVICE_ID_COMMAND_LINE_INTERFACE = "cli"
SERVICE_ID_CONFIGURATION_MANAGER = "conf_manager"




@dataclass
class PingNode:
   status: str
   delay: float
   cpu: float
   mem: float
   disk: float
   uplink_tx: int
   uplink_rx: int

   @dataclass
   class Interfaces:
      @dataclass
      class Interface:
         status: Cpes.Cpe.Interface.Status
         data_tx: Optional[int] = None
         data_rx: Optional[int] = None

      wan: Dict[int, Interface]
      lan: Dict[int, Interface]
      currwan: int

   interfaces: Interfaces
   temperature: Optional[float] = None




class MQTT_Dispatcher:


   @dataclass()
   class Event:
      uuid: str
      time: int
      time_human: str
      topic: str
      body: dict


      @dataclass(frozen=True)
      class Acknowldge:
         service:str
         time:int
         time_human:str

         def __hash__(self):
            return hash(self.service)
      ack:Set[Acknowldge]



      @dataclass(frozen=True)
      class Error:
         service:str
         time:int
         time_human:str
         description:str

         def __hash__(self):
            return hash(self.service)
      errors:Set[Error]





      pending:Set[str]

   def __init__(self):
      self.lock = asyncio.Lock()
      self.dictEvents = {}
      self.listEvents = []





   async def send(self, topic:str, body:dict):
      await self.mqtt.publish(topic, body)


   async def sendEvent(self, event:Event):
      async with self.lock:
         self.dictEvents[event.uuid] = event
         self.listEvents.append(event)
      await self.mqtt.publish(event.topic, {"uuid":event.uuid, "message":event.body})





   async def confirm(self, uuid:str, service:str):
      log.info(f"confirm() uuid='{uuid}' service='{service}'")
      async with self.lock:
         if uuid in self.dictEvents:
            event = self.dictEvents[uuid]

            if event is not None:
               for obj in event.pending.copy():  # Use copy to avoid modifying the set while iterating
                  if obj == service:
                     event.pending.remove(obj)

               event.ack.add(MQTT_Dispatcher.Event.Acknowldge(service=service,
                                                              time=date_utils.getTime(),
                                                              time_human=log_utils.print_date(date_utils.getTime())))

               if len(event.pending) == 0:
                  del self.dictEvents[uuid]
                  self.listEvents = list(filter(lambda event: event.uuid != uuid, self.listEvents))
         else:
            #wrong event
            pass


   async def sendConfirmation(self, uuid:str):
      await self.mqtt.publish('confirmations', {"uuid": uuid, "service": SERVICE_ID_VNF_MANAGER})



   async def error(self, uuid:str, service:str, error:str):
      log.info(f"error() uuid='{uuid}' service='{service}'")

      async with self.lock:
         event = self.dictEvents[uuid]

         if event is not None:
            event.errors.add(MQTT_Dispatcher.Event.Error(service=service,
                                                         time=date_utils.getTime(),
                                                         time_human=log_utils.print_date(date_utils.getTime()),
                                                         description=error))



   async def sendMonitor(self):
      log.info("Confirmation monitor started.")
      async with self.lock:
         for event in self.listEvents:
            if event.time + 30000 < date_utils.getTime():
               log.critical(f"We have a dead event:\n{log_utils.print_object_tree(event)}")
               #self.dictEvents.clear()
               #self.listEvents.clear()
               #await self.mqtt.publish("admin/reset/system", {})

         await asyncio.sleep(2)




   async def getOutgoingEvents(self) -> List[Event]:
      async with self.lock:
         return self.listEvents


   @inject.autoparams()
   async def start(self,
                   platforms: Platforms,
                   vnfs: Vnfs,
                   cpes: Cpes,
                   services: Services,
                   service_templates: ServiceTemplates):
      self.platforms = platforms
      self.hubs = vnfs
      self.cpes = cpes


      self.mqtt = MQTT("NODE")
      await self.mqtt.connect(os.environ.get("MQTT_SERVER"))
      await self.mqtt.subscribe(["confm/#",
                                 "admin/#",
                                 "vnf/#",
                                 "from_cpe/+/to_vnfm/#",
                                 "confirmations",
                                 "errors"])


      loop.create_task(self.sendMonitor(), name="MQTT MONITOR")


      while True:
         try:
            message = await self.mqtt.get()

            arrTopics = message.topic.split("/")

            if arrTopics[0] == 'admin':
               if arrTopics[1] == 'reset':
                  if arrTopics[2] == 'system':
                     log.info("Let's stop process.")
                     system_utils.exit()

            if arrTopics[0] == "confirmations":
                await self.confirm(message.body["uuid"], message.body["service"])

            elif arrTopics[0] == "errors":
               await self.error(message.body["uuid"], message.body["service"], message.body["error"])


            elif arrTopics[0] == "confm":
               uuid = message.body["uuid"]
               dictData = message.body["message"]


               try:
                  if arrTopics[1] == "new":
                     if arrTopics[2] == "vnf":
                        for sVnfName in dictData.keys():
                           await vnfs.addDB(uuid, from_dict(Vnfs.Vnf, dictData[sVnfName]))
                     if arrTopics[2] == "node":
                        for sCpeName in dictData.keys():
                           await cpes.addDB(uuid, from_dict(Cpes.Cpe, dictData[sCpeName]))
                     if arrTopics[2] == "service":
                        for sServiceName in dictData.keys():
                           await services.addDB(uuid, from_dict(Services.Service, dictData[sServiceName]))
                     if arrTopics[2] == "service_template":
                        for sServiceTemplateName in dictData.keys():
                           await service_templates.addDB(uuid, from_dict(ServiceTemplates.ServiceTemplate, dictData[sServiceTemplateName]))


                  if arrTopics[1] == "delete":
                     if arrTopics[2] == "vnf":
                        for sVnfName in dictData.keys():
                           await vnfs.deleteByName(uuid, sVnfName)
                     if arrTopics[2] == "node":
                        for sCpeName in dictData.keys():
                           await cpes.deleteByName(uuid, sCpeName)
                     if arrTopics[2] == "service":
                        for sServiceName in dictData.keys():
                           await services.deleteByName(uuid, sServiceName)
                     if arrTopics[2] == "service_templlate":
                        for sServiceTemplateName in dictData.keys():
                           await service_templates.deleteByName(uuid, sServiceTemplateName)


                  if arrTopics[1] == "update":
                     if arrTopics[2] == "vnf":
                        for sVnfName in dictData.keys():
                           vnf_old:Vnfs.Vnf = await vnfs.getByName(uuid, sVnfName)
                           vnf_new:Vnfs.Vnf = from_dict(Vnfs.Vnf, dictData[sVnfName])
                           if vnf_old.state == Vnfs.Vnf.State.DISABLED and vnf_new.state == Vnfs.Vnf.State.ENABLED:
                              await self.updateVnf(uuid, dataclasses.replace(vnf_new, status=Vnfs.Vnf.Status.STARTING))
                              vnfs.setLastSeen(uuid, sVnfName, date_utils.getTime())
                           if vnf_old.status == Vnfs.Vnf.Status.RUNNING:
                              await self.updateVnf(uuid, dataclasses.replace(vnf_new, status=Vnfs.Vnf.Status.REBOOT_STOPPING))
                           await vnfs.updateDB(uuid, vnf_new)
                     if arrTopics[2] == "node":
                        for sCpeName in dictData.keys():
                           await cpes.updateDB(uuid, from_dict(Cpes.Cpe, dictData[sCpeName]))
                     if arrTopics[2] == "service":
                        for sServiceName in dictData.keys():
                           await services.updateDB(uuid, from_dict(Services.Service, dictData[sServiceName]))
                     if arrTopics[2] == "service_template":
                        for sServiceTemplateName in dictData.keys():
                           await service_templates.updateDB(uuid, from_dict(ServiceTemplates.ServiceTemplate, dictData[sServiceTemplateName]))


                  await self.sendConfirmation(uuid)
               except Exception as e:
                  log.error(f"[{uuid}] {log_utils.print_exception(e)}")


            elif message.topic.endswith("/to_vnfm/vnf_states"):
               rid = message.topic + str(await request_counter.increment())

               for dictCpeVnfInfo in message.body:
                  try:
                     vnf:Vnfs.Vnf = await vnfs.getByName(rid, dictCpeVnfInfo["name"])

                     if "pid" in dictCpeVnfInfo:
                        if vnf.status == Vnfs.Vnf.Status.STARTING:
                           await self.updateVnf(rid, dataclasses.replace(vnf, status=Vnfs.Vnf.Status.RUNNING))

                        vnfs.setLastSeen(rid, vnf.name, date_utils.getTime())

                  except exceptions.NotFoundException:
                     sUnknownCPE = dictCpeVnfInfo['name']
                     log.error(f"No vnf='{sUnknownCPE}' in our system.")
                     if "pid" in dictCpeVnfInfo:
                        log.error(f"Let's stop vnf='{sUnknownCPE}' first.")
                        await self.stopVnf(rid, sUnknownCPE)
                     else:
                        log.error(f"Let's remove vnf='{sUnknownCPE}'.")
                        await self.removeVnfFromCPE(rid, sUnknownCPE)
            # elif arrTopics[0] == "node":
            #    if len(arrTopics) > 2 and arrTopics[2] == "ping":
            #       rid = message.topic + str(await request_counter.increment())
            #
            #       for sCpeName in message.body.keys():
            #          cpe: Cpes.Cpe = await cpes.getByName(rid, sCpeName)
            #          if cpe.status == Cpes.Cpe.Status.REGISTERED:
            #             await self.updateCpe(rid, dataclasses.replace(cpe, status=Cpes.Cpe.Status.ONLINE))
            #
            #          cpes.setLastSeen(rid, sCpeName, date_utils.getTime())
            #
            #
            #          if cpe.status == Cpes.Cpe.Status.ONLINE:
            #             ping = from_dict(PingNode, message.body[sCpeName])
            #             log.debug(f"[{rid}] Ping object:\n{log_utils.print_object_tree(ping)}")
            #
            #             if cpe.currwan != ping.interfaces.currwan:
            #                log.info(f"[{rid}] Cpe='{cpe.name}' has changed currwan.")
            #                await self.updateCpe(rid, dataclasses.replace(cpe, currwan=ping.interfaces.currwan))
            #
            #
            #
            #             isUpdateReqired:bool = False
            #             dictStatues = {}
            #             dictWan = dict(cpe.wan)
            #             for number, value in ping.interfaces.wan.items():
            #                dictStatues[number] = value.status
            #
            #             for number, value in cpe.wan.items():
            #                if dictStatues[number] != value.status:
            #                   dictWan[number] = dataclasses.replace(cpe.wan[number], status=dictStatues[number])
            #                   isUpdateReqired = True
            #
            #
            #             if isUpdateReqired:
            #                log.info(f"[{rid}] Cpe='{cpe.name}' has changed Network state.")
            #                await self.updateCpe(rid, dataclasses.replace(cpe, wan=dictWan))


         except Exception as e:
            log.critical(log_utils.print_exception(e))
            #await asyncio.sleep(1)

   async def transactionConf(self, rid:str, topic:str, body:dict):
      log.info(f"[{rid}] transaction() conf")
      await self.transaction(rid, topic, body, {SERVICE_ID_CONFIGURATION_MANAGER})

   async def transactionNodeVnfCli(self, rid:str, topic:str, body:dict):
      log.info(f"[{rid}] transaction() node,vnf,cli")
      await self.transaction(rid, topic, body, {SERVICE_ID_NODE_MANAGER, SERVICE_ID_VNF_MANAGER})

   async def transactionNodeCli(self, rid:str, topic:str, body:dict):
      log.info(f"[{rid}] transaction() node,cli")
      await self.transaction(rid, topic, body, {SERVICE_ID_NODE_MANAGER})

   async def transactionVnfCli(self, rid:str, topic:str, body:dict):
      log.info(f"[{rid}] transaction() node,cli")
      await self.transaction(rid, topic, body, {SERVICE_ID_VNF_MANAGER})


   async def transaction(self, rid:str, topic:str, body:dict, services:set[str]):
      event = MQTT_Dispatcher.Event(SERVICE_ID_NODE_MANAGER + ":" + rid,
                                    time=date_utils.getTime(),
                                    time_human=log_utils.print_date(date_utils.getTime()),
                                    topic=topic,
                                    body=dict_utils.clean_nones(body),
                                    ack=set(),
                                    errors=set(),
                                    pending=services)
      #log.info(f"[{rid}]transaction() {log_utils.print_tree(dataclasses.asdict(event))}")

      await self.sendEvent(event)


   async def stopVnf(self, rid:str, name_to_stop:str):
      result = {"name": name_to_stop}
      for cpe in await self.cpes.getAllList(rid):
         await self.send(f"from_vnfm/to_cpe/{cpe.name}/stop_vnf", result)

   async def updateVnf(self, rid:str, vnf:Vnfs.Vnf):
      log.info(f"[{rid}] updateVnf() name={vnf.name}")
      await self.transactionConf(rid, "vnfm/update/vnf", {vnf.name: dataclasses.asdict(vnf)})


   async def updateCpe(self, rid:str, cpe:Cpes.Cpe):
      log.info(f"[{rid}] updateCpe() name={cpe.name}")
      await self.transactionConf(rid, "nodem/update/node", {cpe.name: dataclasses.asdict(cpe)})


   async def removeVnfFromCPE(self, rid:str, name_to_remove:str):
      result = {"name": name_to_remove}
      for cpe in await self.cpes.getAllList(rid):
         await self.send(f"from_vnfm/to_cpe/{cpe.name}/remove_vnf", result)
