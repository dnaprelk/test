import copy
import json
import logging
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional

import inject
from from_dict import from_dict
from tabulate import tabulate

import config
import exceptions
import log_utils
from abstract import Abstract
import http_utils

log = logging.getLogger("SERVICE_TEMPLATES")
log.setLevel(config.getLogLevel("service_templates"))


class ServiceTemplates(Abstract):

   @dataclass(frozen=True)
   class ServiceTemplate:
      name: str
      uuid: str
      description: str

      port1: List
      port2: Optional[List] = None



   def __init__(self, CONFM_URL:str):
      super().__init__()
      self.CONFM_URL = CONFM_URL
      self.dictName:Dict[str, ServiceTemplates.ServiceTemplate] = {}



   async def init(self):
      RID = "initServiceTemplates"
      sResponse:str = await http_utils.get_request(RID, self.CONFM_URL + '/api/v1.0/service_templates', 2)

      dictServiceTemplates = json.loads(sResponse)

      for sServiceTemplateName in dictServiceTemplates.keys():
         dictServiceTemplates[sServiceTemplateName]["name"] = sServiceTemplateName
         vnf = from_dict(ServiceTemplates.ServiceTemplate, dictServiceTemplates[sServiceTemplateName])

         await self.addDB(RID, vnf)

      log.info("\n" + self.printList(list(self.dictName.values())))





   def printOne(self, service_template:ServiceTemplate):
      tree = log_utils.Tree(f"SERVICE {service_template.name}")
      root = tree.getRoot()
      root.addNode(f"uuid={service_template.uuid}")
      root.addNode(f"description={service_template.description}")
      root.addNode(f"port1={service_template.port1}")
      root.addNode(f"port2={service_template.port2}")

      return tree.print()



   def printList(self, listServices:List[ServiceTemplate]) -> str:
      logTable = []

      for service in listServices:
         logTable.append([service.name,
                          service.uuid,
                          service.description,
                          service.port1,
                          service.port2
                         ])

      return tabulate(logTable, headers=["Name",
                                         "UUID",
                                         "Description",
                                         "port1",
                                         "port2"], tablefmt="grid")

