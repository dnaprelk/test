import dataclasses
import logging
from dataclasses import dataclass
from typing import List, Optional
import os
import signal
from fastapi import FastAPI, Request
import asyncio
import inject
from tabulate import tabulate
import subprocess
import json
from deepdiff import DeepDiff


import log_utils
import http_utils
import exceptions
from vnfs import Vnfs
from cpes import Cpes
from vnf_templates import VnfTemplates
from services import Services
from service_templates import ServiceTemplates
from platforms import Platforms
from rest import Rest
from mqtt import MQTT_Dispatcher
import request_counter
import date_utils
import system_utils
import os_command_utils

VERSION = "0.002"
VERSION_DESCRIPTION = "We stop/remove abandoned vnf."

loop = asyncio.get_event_loop()


logging.basicConfig(
   level=logging.DEBUG,
   format='%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s - Line %(lineno)d'
   #format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s - Line %(lineno)d'
   #format = '\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)



log = logging.getLogger("MAIN")
logMonitor = logging.getLogger("MONITOR")
logServiceMonitor = logging.getLogger("SERVICE_MONITOR")


CONFM_URL   = os.environ.get("CONFM_URL")
MQTT_SERVER = os.environ.get("MQTT_SERVER")
CTL         = os.environ.get("CTL")

if CONFM_URL == None or MQTT_SERVER == None or CTL == None:
   log.critical(f"ERROR: You have to set CONFM_URL='{CONFM_URL}' & MQTT_SERVER='{MQTT_SERVER}' & CTL='{CTL}' env variables")
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)



app = FastAPI()







vnfs = Vnfs(CONFM_URL)
vnf_templates = VnfTemplates(CONFM_URL)
services = Services(CONFM_URL)
service_templates = ServiceTemplates(CONFM_URL)
cpes = Cpes(CONFM_URL)
platforms = Platforms(CONFM_URL)

mqtt = MQTT_Dispatcher()



def configure(binder):
   binder.bind(Vnfs, vnfs)
   binder.bind(VnfTemplates, vnf_templates)
   binder.bind(Services, services)
   binder.bind(ServiceTemplates, service_templates)
   binder.bind(Cpes, cpes)
   binder.bind(Platforms, platforms)
   binder.bind(FastAPI, app)
   binder.bind(MQTT_Dispatcher, mqtt)
inject.configure(configure)

rest = Rest()




async def getVnfConfig(rid:str, vnf:Vnfs.Vnf):
   vnfTemplate = await vnf_templates.getByName(rid, vnf.template)

   result = await os_command_utils.os_command_call(f"{os.getcwd()}/vnf_helpers/{vnfTemplate.type}.py", json.dumps(vnf.config))
   return result.out


async def getLxcConfig(rid:str, vnf:Vnfs.Vnf):
   config = ''

   cpe:Cpes.Cpe = await cpes.getByName(rid, vnf.node)

   if vnf.ports == None:
      return config

   config += '#\n'
   config += f"# VNF {vnf.name} container config\n"
   config += '#\n\n'

   config += '# Distribution configuration\n'
   config += 'lxc.include = /usr/share/lxc/config/common.conf\n'
   config += 'lxc.arch = linux64\n\n'

   config += '# Container specific configuration\n'
   config += f"lxc.rootfs.path = dir:/vnf/{vnf.name}/rootfs\n"
   config += f"lxc.uts.name = {vnf.name}\n"

   config += '# Network configuration\n'
   if 'lan' in vnf.ports:
      if cpe.platform != None:
         platform:Platforms.Platform = await platforms.getByName(rid, cpe.platform)
         iPort = int(vnf.ports['lan'])
         #log.info(platform.lan)
         port = platform.lan[iPort]
         config += 'lxc.net.0.type = phys\n'
         config += 'lxc.net.0.flags = up\n'
         config += f"lxc.net.0.link = {port.ifname}\n"
         config += 'lxc.net.0.name = lan0\n\n'

   if 'eth' in vnf.ports:
      for i in vnf.ports['eth']:
         config += f"lxc.net.{i}.type = veth\n"
         config += f"lxc.net.{i}.flags = up\n"
         config += f"lxc.net.{i}.script.up = /etc/lxc/lxc-ifup\n"
         config += f"lxc.net.{i}.script.down = /etc/lxc/lxc-ifdown\n"
         config += f"lxc.net.{i}.name = eth{i}\n"
         tmp = '%04X' % (vnf.id)
         config += 'lxc.net.%d.hwaddr = fe:42:06:%s:%s:%02X\n' % (i, tmp[:2], tmp[2:], i)
         config += 'lxc.net.%d.veth.pair = ve%04X%02X\n\n' % (i, vnf.id, i)

   return config






async def monitor():

   while True:
      rid: str = "monitor:" + str(await request_counter.increment())

      try:
         logTable = []

         for vnf in await vnfs.getAllList(rid):
            logTableRow = []
            logTable.append(logTableRow)

            logTableRow.append(vnf.name)
            logTableRow.append(vnf.id)
            logTableRow.append(vnf.domain)
            logTableRow.append(log_utils.print_date(vnfs.getLastSeen(vnf.name)))
            logTableRow.append(vnf.state)
            logTableRow.append(vnf.status)
            logTableRow.append(vnf.node if vnf.node is not None else "---")

            listDomainCPEs:List[Cpes.Cpe] = []
            for cpe in await cpes.getAllList(rid):
               if cpe.domain == vnf.domain and cpe.status == Cpes.Cpe.status.ONLINE:
                  listDomainCPEs.append(cpe)

            listDomainCPEs = sorted(listDomainCPEs, key=lambda cpe: cpe.id)


            if vnf.state == Vnfs.Vnf.State.ENABLED:
               if vnf.status == Vnfs.Vnf.Status.REBOOT_STOPPING:
                  if vnfs.getLastSeen(vnf.name) is None:
                     logTableRow.append("an abandoned stop")
                     vnfs.setLastSeen(rid, vnf.name, date_utils.getTime())
                     await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=None, status=Vnfs.Vnf.Status.STOPPED))
                  else:
                     if vnfs.getLastSeen(vnf.name) + 15000 < date_utils.getTime():
                        logTableRow.append("no more pings, seems stopped.")
                        await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=None, status=Vnfs.Vnf.Status.REBOOT_STARTING))
                     else:
                        logTableRow.append("waiting")
                        await mqtt.stopVnf(rid, vnf.name)

               elif vnf.status == Vnfs.Vnf.Status.STOPPED or vnf.status == Vnfs.Vnf.Status.EXPIRED:
                  if len(listDomainCPEs) == 0:
                     logTableRow.append("No CPE online")
                  else:
                     logTableRow.append("Let's start it now")
                     await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=listDomainCPEs[0].name, status=Vnfs.Vnf.Status.STARTING))
                     vnfs.setLastSeen(rid, vnf.name, date_utils.getTime())
               elif vnf.status == Vnfs.Vnf.Status.STARTING or vnf.status == Vnfs.Vnf.Status.REBOOT_STARTING:
                  iTimeLastSeen:int = vnfs.getLastSeen(vnf.name)
                  if iTimeLastSeen is None:
                     logTableRow.append("That was an abandoned start.")
                     await mqtt.updateVnf(rid, dataclasses.replace(vnf, status=Vnfs.Vnf.Status.STOPPED))
                  else:
                     if vnf.node is None:
                        if len(listDomainCPEs) == 0:
                           logTableRow.append("No CPE online")
                        else:
                           logTableRow.append("Let's choose cpe for start.")
                           await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=listDomainCPEs[0].name, status=Vnfs.Vnf.Status.STARTING))
                     else:
                        if iTimeLastSeen + 15000 > date_utils.getTime():

                           arrTableStart = []
                           arrTableStartRow = []
                           arrTableStart.append(arrTableStartRow)

                           sVnfConfig = await getVnfConfig(rid, vnf)
                           arrTableStartRow.append(sVnfConfig)

                           sLXCConfig = await getLxcConfig(rid, vnf)


                           if "l3Router" in vnf.config\
                                 and "hasInternet" in vnf.config["l3Router"]\
                                 and vnf.config["l3Router"]["hasInternet"] == True:
                              sLXCConfig += "\nlxc.net.0.type = veth"
                              sLXCConfig += "\nlxc.net.0.name = eth0"
                              sLXCConfig += "\nlxc.net.0.link = lxcbr0"
                              sLXCConfig += "\nlxc.net.0.flags = up"
                              sLXCConfig += "\nlxc.net.0.hwaddr = fe:42:00:00:00:00"

                              sVnfConfig += "\n/sbin/iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE"

                           arrTableStartRow.append(sLXCConfig)

                           logMonitor.info("\n\nConfig:\n" + tabulate(arrTableStart, headers=["VNF",
                                                                                              "LXC"], tablefmt="grid"))

                           template:VnfTemplates.VnfTemplate = await vnf_templates.getByName(rid, vnf.template)

                           result = {"name": vnf.name,
                                     "id": vnf.id,
                                     "description": vnf.description,
                                     "domain": vnf.domain,
                                     "template": vnf.template,
                                     "state": vnf.state,
                                     "status": "starting",
                                     "image": {"name": template.image.name, "size":template.image.size, "sha": template.image.sha},
                                     "vnf_config": sVnfConfig,
                                     "lxc_config": sLXCConfig
                                    }
                           await mqtt.send(f"from_vnfm/to_cpe/{vnf.node}/start_vnf", result)

                           logTableRow.append("waiting")
                        else:
                           logTableRow.append("start expired")
                           vnfs.setLastError(rid, vnf.name, date_utils.getTime())
                           await mqtt.updateVnf(rid, dataclasses.replace(vnf, status=Vnfs.Vnf.Status.START_EXPIRED))

               elif vnf.status == Vnfs.Vnf.Status.START_EXPIRED:
                  if vnfs.getLastError(vnf.name) is None:
                     logTableRow.append("an abandoned restart.")
                     vnfs.setLastError(rid, vnf.name, date_utils.getTime())
                  else:
                     if vnfs.getLastError(vnf.name) + 10000 < date_utils.getTime():
                        logTableRow.append("Let's try to start again")
                        vnfs.setLastSeen(rid, vnf.name, date_utils.getTime())
                        await mqtt.updateVnf(rid, dataclasses.replace(vnf, status=Vnfs.Vnf.Status.STARTING))
                     else:
                        logTableRow.append("Let's wait till next attempt")

               elif vnf.status == Vnfs.Vnf.Status.RUNNING:
                  if vnfs.getLastSeen(vnf.name) is None:
                     logTableRow.append("an abandoned run.")
                     await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=None, status=Vnfs.Vnf.Status.EXPIRED))
                  else:
                     if vnfs.getLastSeen(vnf.name) + 10000 < date_utils.getTime():
                        logTableRow.append("run expired")
                        await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=None, status=Vnfs.Vnf.Status.EXPIRED))
                     else:
                        logTableRow.append("ok")


            else:
               if vnf.status == Vnfs.Vnf.Status.RUNNING:
                  logTableRow.append("Let's stop it.")
                  await mqtt.updateVnf(rid, dataclasses.replace(vnf, status=Vnfs.Vnf.Status.STOPPING))

               if vnf.status == Vnfs.Vnf.Status.STOPPING:
                  if vnfs.getLastSeen(vnf.name) is None:
                     logTableRow.append("an abandoned stop")
                     vnfs.setLastSeen(rid, vnf.name, date_utils.getTime())
                     await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=None, status=Vnfs.Vnf.Status.STOPPED))
                  else:
                     if vnfs.getLastSeen(vnf.name) + 15000 < date_utils.getTime():
                        logTableRow.append("no more pings, seems stopped.")
                        await mqtt.updateVnf(rid, dataclasses.replace(vnf, node=None, status=Vnfs.Vnf.Status.STOPPED))
                     else:
                        logTableRow.append("waiting")
                        await mqtt.stopVnf(rid, vnf.name)

               if vnf.status == Vnfs.Vnf.Status.STOPPED:
                  logTableRow.append("ok")


            sLogNodes = ""
            for cpe in await cpes.getAllList(rid):
               if cpe.domain == vnf.domain:
                  if len(sLogNodes) > 0:
                     sLogNodes += "\n"
                  sLogNodes += f"'{cpe.name}'{'(*)' if cpe.name == vnf.node else ''} {cpe.status}."
            logTableRow.append(sLogNodes)

            sLogPlatforms = ""
            if vnf.node is not None:
               sLogPlatforms = (await cpes.getByName(rid, vnf.node)).platform
            logTableRow.append(sLogPlatforms)



         logMonitor.info("\n\nVNFs:\n" + tabulate(logTable, headers=["Name",
                                                                     "ID",
                                                                     "Domain",
                                                                     "Last seen",
                                                                     "State",
                                                                     "Status",
                                                                     "Cpe",
                                                                     "Action",
                                                                     "Avail CPE",
                                                                     "Platforms"], tablefmt="grid"))


      except Exception as e:
         log.critical(f"[{rid}] {log_utils.print_exception(e)}")

      await asyncio.sleep(1)




async def generateRules(rid:str, service:Services.Service):
   listRules = []

   for endpoint in service.endpoints:
      vnf: Vnfs.Vnf = await vnfs.getByName(rid, endpoint.vnf)

      vid = vnf.id * 256 + endpoint.port

      serviceTemplate: ServiceTemplates.ServiceTemplate = await service_templates.getByName(rid, service.template)
      if endpoint.type == Services.Service.Endpoint.Type.ALL or endpoint.type == Services.Service.Endpoint.Type.SERVER:
         match = serviceTemplate.port1
      else:
         match = serviceTemplate.port2

      listRules.append({"vid": vid, "match": match})
   return listRules



async def pushRules(rid: str, service:Services.Service, listRules):
   await http_utils.post_request(rid, url=CTL + "/service/%04X" % service.id, data=listRules, timeout=2)





async def service_monitor():
   while True:
      rid: str = "monitor:" + str(await request_counter.increment())

      try:
         sResponse:str = await http_utils.get_request(rid, CTL + '/service', 2)

         dictConfiguredServices:dict = json.loads(sResponse)

         arrLogTable = []
         mapExistingServices = {}
         for sServiceName,listMatches in dictConfiguredServices.items():
            arrRow = []
            arrLogTable.append(arrRow)
            arrRow.append(sServiceName)

            service: Services.Service = None
            try:
               service:Services.Service = await services.getById(rid, int(sServiceName, 16))

               mapExistingServices[service.id] = service
               arrRow.append(service.name)

               if service.state == Services.Service.State.DISABLED:
                  arrRow.append("DELETE")
                  await http_utils.delete_request(rid=rid, url=f"{CTL}/service/{sServiceName}", data={}, timeout=2)
               else:
                  diff = DeepDiff(listMatches, await generateRules(rid, service), ignore_order=True)
                  if len(diff) == 0:
                     arrRow.append("ok")
                  else:
                     arrRow.append("DIFFERENCE")
                     await http_utils.delete_request(rid=rid, url=f"{CTL}/service/{sServiceName}", data={}, timeout=2)
                     await pushRules(rid, service, await generateRules(rid, service))




            except exceptions.NotFoundException:
               arrRow.append("---")
               arrRow.append("DELETE")
               await http_utils.delete_request(rid=rid, url=f"{CTL}/service/{sServiceName}", data={}, timeout=2)


            for matches in listMatches:
               sCell = f"vid={matches['vid']} [veth{format(matches['vid'], '06X')}]\n\n"
               for tmp in matches["match"]:
                  sCell += "\n".join(tmp)
               arrRow.append(sCell)


         for service in await services.getAllList(rid):
            if service.id in mapExistingServices or service.state == Services.Service.State.DISABLED:
               #That's one exists
               continue
            arrRow = []
            arrLogTable.append(arrRow)
            arrRow.append("/service/%04X" % service.id)
            arrRow.append(service.name)
            arrRow.append("NEW")
            await pushRules(rid, service, await generateRules(rid, service))


         logServiceMonitor.info("\n\nServices:\n" + tabulate(arrLogTable, tablefmt="grid"))
      except Exception as e:
         log.critical(f"[{rid}] {log_utils.print_exception(e)}")

      await asyncio.sleep(1)


async def main():
   try:
      await rest.init()
      await vnfs.init()
      await vnf_templates.init()
      await services.init()
      await service_templates.init()
      await cpes.init()
      await platforms.init()
      await rest.init()

      loop.create_task(monitor())
      loop.create_task(service_monitor())


      await mqtt.start()


   except Exception as e:
      log.critical(log_utils.print_exception(e))
      system_utils.exit()

loop.create_task(main())

