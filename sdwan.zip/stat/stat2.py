#!/usr/bin/env python3

import logging
from fastapi import FastAPI, HTTPException
import fastapi
import asyncio
from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel





log = logging.getLogger("MAIN")


app = FastAPI()


loop = asyncio.get_event_loop()


class Stat(BaseModel):
   cpu: int
   ram: int
   disk: int
   temperature: int
   currentUplink: str

   class WanPort(BaseModel):
      uplinkCode: str

      class Status(Enum):
         UP = "up"
         DEGRADED = "degraded"
         FAIL = "fail"
         DOWN = "down"
      uplinkStatus: Status

      class Type(Enum):
         ETH  = "eth"
         LTE  = "lte"
      type: Type
   wanPorts:List[WanPort]



   class LanPort(BaseModel):
      portCode: str

      class Status(Enum):
         UP = "up"
         DOWN = "down"
      portStatus: Status


      class Type(Enum):
         ETH  = "eth"
         WIFI = "wifi"
      portType: Type
   lanPorts: List[LanPort]


   class VNF(BaseModel):
      vnfName: str
      vnfId: str

      class Status(Enum):
         RUNNING="running"
         STARTING="starting"
         STOPPED="stopped"
         STOPPING="stopping"
      vnfStatus: Status

      class Type(Enum):
         DHCP="dhcp"
         L2_BRIDGE="l2Bridge"
         L3_ROUTER="l3Router"
         FIREWALL="firewall"
         NAT="nat"
         DNS="dns"
      vnfType: Type

      vnfTemplateName: str
      vnfTemplateId: str
   vnfs:List[VNF]

   metrics: Dict[int, List] = {}





@app.get("/v1/cpe/{cpeId}/monitoring")
async def getStat(cpeId:str) -> Stat:

   data = {
      "cpu":10,
      "disk":15,
      "ram":24,
      "temperature": 40,
      "currentUplink": "LAN1",
      "wanPorts":[
                    {"uplinkCode":"WAN1", "uplinkStatus":"up", "type":"eth"},
                    {"uplinkCode":"WAN2", "uplinkStatus": "down", "type": "lte"},
                    {"uplinkCode":"WAN3", "uplinkStatus": "degraded", "type": "lte"},
                    {"uplinkCode":"WAN4", "uplinkStatus": "fail", "type": "lte"},

      ],
      "lanPorts": [
         {"portCode": "LAN1", "portStatus": "up",   "portType": "wifi"},
         {"portCode": "LAN2", "portStatus": "down", "portType": "eth"}
      ],
      "vnfs":[
         {"vnfName":"VNF1", "vnfId":"1", "vnfStatus":"starting", "vnfType":"dhcp",     "vnfTemplateName":"template1", "vnfTemplateId":"id1"},
         {"vnfName":"VNF2", "vnfId":"2", "vnfStatus":"running",  "vnfType":"l2Bridge", "vnfTemplateName":"template2", "vnfTemplateId":"id2"},
         {"vnfName":"VNF3", "vnfId":"3", "vnfStatus":"stopping", "vnfType":"l3Router", "vnfTemplateName":"template3", "vnfTemplateId":"id3"},
         {"vnfName":"VNF4", "vnfId":"4", "vnfStatus":"stopped",  "vnfType":"firewall", "vnfTemplateName":"template4", "vnfTemplateId":"id4"}
      ],

      "metrics":{
         1000000:[34,45],
         2000000:[34,45],
         3000000:[34,45],
         4000000:[34,45],
         5000000:[34,45],
         6000000:[34,45],
         7000000:[34,45]
      }

   }

   stat = Stat(**data)
   # stat.cpu = 10
   # stat.disk = 15
   # stat.ram = 24
   # stat.temperature = 34
   #
   # wanPort = Stat.WanPort()
   # wanPort.type = Stat.WanPort.Type.ETH
   # wanPort.uplinkCode = "WAN1"
   # wanPort.status = Stat.WanPort.Status.UP
   # stat.wanPorts.append(wanPort)
   #
   # wanPort = Stat.WanPort()
   # wanPort.type = Stat.WanPort.Type.LTE
   # wanPort.uplinkCode = "WAN2"
   # wanPort.status = Stat.WanPort.Status.DEGRADED
   # stat.wanPorts.append(wanPort)


   print(stat)

   return stat


