export MQTT_SERVER=127.0.0.1
export CONFM_URL=http://127.0.0.1:8000


while :
do
   python ./stat.py
   sleep 1
done
