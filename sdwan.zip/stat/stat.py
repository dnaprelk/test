#!/usr/bin/python

from flask import Flask
from flask import request
from flask import Response
import requests
import json
import paho.mqtt.client as mqtt
import time
import threading
import logging
import os
import random

log = logging.getLogger("MAIN")
logWatcher = logging.getLogger("WATCHER")
logMQTT = logging.getLogger("MQTT")
logMQTT.setLevel(logging.ERROR)


CONFM_URL   = os.environ.get("CONFM_URL")
MQTT_SERVER = os.environ.get("MQTT_SERVER")

if CONFM_URL == None or MQTT_SERVER == None:
   print(f"ERROR: You have to set both CONFM_URL='{CONFM_URL}' & MQTT_SERVER='{MQTT_SERVER}' env variables")
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)
else:
   log.info(f"Configuration manager URL={CONFM_URL}")
   log.info(f"MQTT server ip={MQTT_SERVER}")


#
# Thread for monitoring VNFs
#
def watcher():
    for node in nodes:
        exp_time = int(time.time()) - 60

        for m in list(nodes[node]['metrics']):
            if int(m) < exp_time:
                del nodes[node]['metrics'][m]

    threading.Timer(1, watcher).start()

#
# MQTT client callbacks
#
def on_connect(client, userdata, flags, rc):
    print('Connected with result code ' + str(rc))
    client.subscribe('node/#')
    client.subscribe('confm/#')
    client.subscribe('vnfm/#')

def on_disconnect(client, userdata, rc):
    print('Broker failure')

def on_message(client, userdata, msg):
    try:
       topic = msg.topic.split('/')
       m = json.loads(msg.payload)

       print('MQTT: ' + msg.topic + ' ' + json.dumps(m, indent=4, sort_keys=True))

       #
       # Message from node
       #
       if topic[0] == 'confm':
           #
           # Update node
           #
           if topic[1] == 'update' and topic[2] == 'node':
               uuid = m["uuid"]
               message = m["message"]
               node = list(message.keys())[0]
               result = { 'stats': { 'code': 1, 'msg': 'Node ' + node + ' update error' } }

               if node in nodes:
                   if nodes.update(node, m[node]['uuid'], m[node]['domain'], m[node]['currwan'], m[node]['wan'], m[node]['platform']) == True:
                       result = { node: nodes[node] }
                       client.publish('stats/update/node', json.dumps(result), 0)
                       result = { 'stats': { 'code': 0, 'msg': 'Node ' + node + ' updated' } }

               client.publish('stats/result', json.dumps(result), 0)


           #
           # Update vnf
           #
           if topic[1] == 'update' and topic[2] == 'vnf':
               uuid = m["uuid"]
               message = m["message"]

               vnf = list(message.keys())[0]
               result = { 'stats': { 'code': 1, 'msg': 'VNF ' + vnf + ' update error' } }

               if vnf in vnfs:
                   if vnfs.update(vnf, m[vnf]['node'], m[vnf]['uuid'], m[vnf]['status'], m[vnf]['template']) == True:
                       result = { vnf: vnfs[vnf] }
                       client.publish('stats/update/vnf', json.dumps(result), 0)
                       result = { 'stats': { 'code': 0, 'msg': 'VNF ' + vnf + ' updated' } }

               client.publish('stats/result', json.dumps(result), 0)

       #
       # Message from node
       #
       if topic[0] == 'node':
           #
           # Update node
           #
#           if topic[1] == 'update':
#               result = { 'stats': { 'code': 1, 'msg': 'Node ' + node + ' update error' } }
#
#               if node in nodes:
#                   if 'status' in m[node]:
#                       if nodes.update(node, m[node]['uuid'], m[node]['domain'], m[node]['currwan'], m[node]['wan'], m[node]['platform']) == True:
#                           result = { node: nodes[node] }
#                           client.publish('stats/update/node', json.dumps(result), 0)
#                           result = { 'stats': { 'code': 0, 'msg': 'Node ' + node + ' updated' } }
#
#               client.publish('stats/result', json.dumps(result), 0)
           #
           # Ping
           #
           if topic[1] != 'update':
               if topic[2] == 'ping':
                  node = list(m.keys())[0]
                  if node in nodes:
                       nodes.see(node, m[node])
           else:
               pass
    except Exception as e:
       print(e)

client = mqtt.Client('stats' + str(random.randint(1000, 65000)))
client.on_connect = on_connect
client.on_disconnect = on_disconnect
client.on_message = on_message
client.connect(MQTT_SERVER)
client.loop_start()

# Create flask app and configure it
app = Flask(__name__)
app.debug = False

#
# Platform class
#
class Platforms(dict):
    def __init__(self):
        response = requests.get(CONFM_URL + '/api/v1.0/platforms')

        data = json.loads(response.text)

        for d in data:
            self[d] = {
                'wan': data[d]['wan'],
                'lan': data[d]['lan']
            }

platforms = Platforms()

#
# Node class
#
class Nodes(dict):
    def __init__(self):
        response = requests.get(CONFM_URL + '/api/v1.0/nodes')

        data = json.loads(response.text)

        for d in data:
            if 'currwan' not in data[d]:
                currwan = '1'
            else:
                currwan = data[d]['currwan']

            self[d] = {
                'uuid': data[d]['uuid'],
                'domain': data[d]['domain'],
                'currwan': currwan,
                'wan': data[d]['wan'],
                'platform': data[d]['platform'],
                'metrics': { },
                'curr_tx': 0,
                'curr_rx': 0,
                'interfaces': { },
                'cpu': 0.0,
                'mem': 0.0,
                'disk': 0.0,
                'temperature': 0.0
            }

    def see(self, node, data):
        ifaces = {}

        if node in nodes:
            self[node]['cpu'] = data['cpu']
            self[node]['mem'] = data['mem']
            self[node]['disk'] = data['disk']
            if 'temperature' in data:
                self[node]['temperature'] = data['temperature']
            else:
                self[node]['temperature'] = 0

            for i in data['interfaces']['wan']:
                ifaces['wan' + str(i)] = { 'status': data['interfaces']['wan'][i]['status'] }
            for i in data['interfaces']['lan']:
#                ifaces['wan' + str(i)] = { 'status': data[node]['interfaces']['wan'][i]['status'] }
                ifaces['lan' + str(i)] = { 'status': data['interfaces']['lan'][i]['status'] }

            self[node]['interfaces'] = ifaces

            if self[node]['curr_tx'] == 0:
                self[node]['curr_tx'] = float(data['uplink_tx']) * 8 / 1000000

            if self[node]['curr_rx'] == 0:
                self[node]['curr_rx'] = float(data['uplink_rx']) * 8 / 1000000

            curr_time = int(time.time())

            self[node]['metrics'][curr_time] = [
                    (float(data['uplink_tx']) * 8 / 1000000) - self[node]['curr_tx'],
                    (float(data['uplink_rx']) * 8 / 1000000) - self[node]['curr_rx']
            ]

            self[node]['curr_tx'] = float(data['uplink_tx']) * 8 / 1000000
            self[node]['curr_rx'] = float(data['uplink_rx']) * 8 / 1000000

            return True
        else:
            return False

    def update(self, node, uuid, domain, currwan, wan, platform):
        if node in nodes:
            self[node] = {
                    'uuid': uuid,
                    'domain': domain,
                    'currwan': currwan,
                    'wan': wan,
                    'platform': platform,
                    'metrics': { },
                    'curr_tx': 0,
                    'curr_rx': 0,
                    'interfaces': { },
                    'cpu': 0.0,
                    'mem': 0.0,
                    'disk': 0.0,
                    'temperature': 0.0
            }

            return True
        else:
            return False

    def stats(self, uuid):
        node = None

        for n in self:
            if self[n]['uuid'] == uuid:
                node = n

        if node != None:
            print(self[node])
            result = {
                    'cpu': self[node]['cpu'],
                    'ram': self[node]['mem'],
                    'disk': self[node]['disk'],
                    'temperature': self[node]['temperature'],
                    'legend': {
                        'tx': 0,
                        'rx': 1
                    },
                    'currentUplink': 'WAN' + str(self[node]['currwan']),
                    'wanPorts': [ ],
                    'lanPorts': [ ],
                    'vnfs': [ ],
                    'metrics': self[node]['metrics']
            }

            for i in self[node]['wan']:
                result['wanPorts'].append({
                    'uplinkCode': 'WAN' + i,
                    'uplinkStatus': self[node]['wan'][i]['status'],
                    'uplinkType': 'eth'
                })

            for i in self[node]['interfaces']:
                if i[:3] == 'lan':
                    result['lanPorts'].append({
                        'portCode': i.upper(),
                        'portStatus': self[node]['interfaces'][i]['status'],
                        'portType': 'eth'
                    })

            for v in vnfs:
                if vnfs[v]['node'] == node:
                    result['vnfs'].append({
                        'vnfName': v,
                        'vnfId': vnfs[v]['uuid'],
                        'vnfStatus': vnfs[v]['status'],
                        'vnfType': 'l2Bridge',
                        'vnfTemplateName': 'l2Bridge',
                        'vnfTemplateId': '46607ba4-9c11-40d7-aa03-ef16029743bf'
                    })

            return result
        else:
            return None

nodes = Nodes()

#
# VNF class
#
class Vnfs(dict):
    def __init__(self):
        response = requests.get(CONFM_URL + '/api/v1.0/vnfs')

        data = json.loads(response.text)

        for d in data:

            if 'node' not in data[d]:
                node = None
            else:
                node = data[d]['node']

            self[d] = {
                'node': node,
                'uuid': data[d]['uuid'],
                'status': data[d]['status'],
                'template': data[d]['template']
            }

    def update(self, vnf, node, uuid, status, template):
        if vnf in vnfs:
            self[vnf] = {
                    'node': node,
                    'uuid': uuid,
                    'status': status,
                    'template': template
            }

            return True
        else:
            return False

vnfs = Vnfs()

#
# Get monitoring data for CPE
#
@app.route('/api/lk/v1.0/cpe/monitoring/<uuid>', methods=['GET'])
def monitor_cpe(uuid):
    result = nodes.stats(uuid)

    print('REST: ' + json.dumps(result, indent=4))

    if result != None:
        return Response(json.dumps(result), status=200, mimetype='application/json')
    else:
        return Response('Not found', status=404, mimetype='text/plain')

if __name__ == '__main__':
    watcher()
    app.run(host='0.0.0.0', port=8001)
