from fastapi import FastAPI, HTTPException, Depends, Request, Response
from fastapi.responses import JSONResponse
#from injector import inject, Injector, singleton
import fastapi
from fastapi.responses import JSONResponse as BaseJSONResponse

from pydantic import BaseModel
import logging
import asyncio
#import jsonpickle
from typing import Dict, List, Optional
from math import isnan
from functools import wraps
from dataclasses import dataclass, field
import uuid
import uvicorn
import inject


import config


import exceptions
from platforms import Platforms
from hubs import Hubs
from sites import Sites
from cpes import Cpes
from vnf_templates import VnfTemplates
from config_objects.config_vnf import Vnf
from services import Services
from service_templates import ServiceTemplates


from interfaces.keys import *
from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs
from interfaces.service_interface import IServices
from interfaces.vnf_template_interface import IVnfTemplates
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs
from interfaces.service_template_interface import IServiceTemplates
from mqtt import MQTT_Dispatcher


class ApiInternal_1_0:

   def __init__(self):
      pass

   @inject.autoparams()
   async def addRoutes(self,
                       app: FastAPI,
                       platforms: IPlatforms,
                       hubs: IHubs,
                       nodes: ICpes,
                       sites: ISites,
                       vnf_templates: IVnfTemplates,
                       vnfs: IVnfs,
                       services: IServices,
                       service_templates: IServiceTemplates,
                       mqtt:MQTT_Dispatcher):


      @app.get("/api/v1.0/platforms")
      async def listPlatforms(request: Request) -> Dict[str, Platforms.Platform]:
         return await platforms.getAllDict(request.state.rid)

      @app.get("/api/v1.0/platform/{name}")
      async def getPlatform(request: Request, name:str) -> Platforms.Platform:
         return await platforms.getByName(request.state.rid, name)


      @app.get("/api/v1.0/nodes")
      async def listNodes(request: Request) -> Dict[str, Cpes.Cpe]:
         return await nodes.getAllDict(request.state.rid)


      @app.get("/api/v1.0/vnf_templates")
      async def listVnfTemplates(request: Request) -> Dict[str, VnfTemplates.VnfTemplate]:
         return await vnf_templates.getAllDict(request.state.rid)


      @app.get("/api/v1.0/vnfs")
      async def listVnfs(request: Request) -> Dict[str, Vnf]:
         return await vnfs.getAllDict(request.state.rid)


      @app.get("/api/v1.0/service_templates")
      async def listServiceTemplates(request: Request) -> Dict[str, ServiceTemplates.ServiceTemplate]:
         return await service_templates.getAllDict(request.state.rid)


      @app.get("/api/v1.0/services")
      async def listServices(request: Request) -> Dict[str, Services.Service]:
         return await services.getAllDict(request.state.rid)


      @app.get("/api/v1.0/domains")
      async def listDomains(request: Request) -> Dict[str, Sites.Site]:
         return await sites.getAllDict(request.state.rid)


      @app.get("/api/v1.0/hubs")
      async def listHubs(request: Request) -> Dict[str, Hubs.Hub]:
         return await hubs.getAllDict(request.state.rid)


      @app.get("/api/v1.0/admin/reset")
      async def adminReset(request: Request) -> str:
         await mqtt.resetSystem(request.state.rid)
         return "ok"

      @app.get("/api/v1.0/admin/reboot/hub/{name}")
      async def adminRebootHub(request: Request, name:str) -> str:
         await mqtt.rebootHub(request.state.rid, name)
         return "ok"

      @app.get("/api/v1.0/admin/reboot/cpe/{name}")
      async def adminRebootCpe(request: Request, name:str) -> str:
         await mqtt.rebootCpe(request.state.rid, name)
         return "ok"

      @app.get("/api/v1.0/admin/agents")
      async def adminReset(request: Request) -> Dict:
         return config.getAgents()

      @app.get("/api/v1.0/admin/mqtt/outgoing_events")
      async def adminReset(request: Request) -> List:
         return await mqtt.getOutgoingEvents()
      @app.get("/api/v1.0/admin/mqtt/outgoing_events_length")
      async def adminReset(request: Request) -> int:
         return len(await mqtt.getOutgoingEvents())





      @app.get("/admin/logs/set/mqtt-internal/{level}")
      async def setLogInternalMQTT(level:str):
         logging.getLogger("amqtt").setLevel(level)
         logging.getLogger("transitions.core").setLevel(level)
         return "ok"

      @app.get("/admin/logs/set/mqtt/{level}")
      async def setLogMQTT(level:str):
         logging.getLogger("MQTT").setLevel(level)
         logging.getLogger("MQTT_DISPATCHER").setLevel(level)
         return "ok"
