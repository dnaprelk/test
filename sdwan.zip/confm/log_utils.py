import json
import traceback
from datetime import datetime
from enum import Enum, EnumMeta


def print_tree(data):
   return json.dumps(data, indent=3)




class Tree:
   class Node:
      def __init__(self, level:int, name:str):
         self.name = name
         self.level = level
         self.listNodes = []

      def addNode(self, name:str):
         node = Tree.Node(self.level + 1, name)
         self.listNodes.append(node)
         return node

      def print(self, padding:str):
         sResult = padding[:-1] + "|-" + self.name + "\n"

         for node in self.listNodes[:-1]:
            sResult += node.print(padding + "  |")

         if len(self.listNodes) > 0:
            sResult += self.listNodes[-1].print(padding + "   ")
         return sResult

   def __init__(self, root:str):
      self.nodeRoot = Tree.Node(0, root)

   def getRoot(self):
      return self.nodeRoot

   def print(self):
      return self.nodeRoot.print("")



def _getClassPath(value) -> str:
   try:
      return "<" + f"{value.__class__.mro()[0]}".split("class")[1].replace("'","").replace(">","").strip() + ">"
   except Exception:
      return f"{type(value)}"

def print_object_tree(obj):
   tree = Tree(_getClassPath(obj))
   node = tree.getRoot()
   _print_object_tree(obj, node)
   return tree.print()



def _print_object_tree(obj, node: Tree.Node = None):

   if isinstance(obj, Enum):
      node.addNode(f"{obj}")
   elif isinstance(obj, dict):
      for key, value in obj.items():
         nodeChild = node.addNode(f"{key} {_getClassPath(key)}")
         #print(key, type(key), value, type(value))
         _print_object_tree(value, nodeChild)
   elif isinstance(obj, (list, tuple)):
      for index, item in enumerate(obj):
         nodeChild = node.addNode(f"[{index}]")
         _print_object_tree(item, nodeChild)
   elif hasattr(obj, '__dict__'):
      for key, value in obj.__dict__.items():
         nodeChild = node.addNode(f"{key} {_getClassPath(value)}")
         _print_object_tree(value, nodeChild)
   else:
      node.addNode(f"{obj}")


def print_exception(e):
   return str(e) + "\n" + "\n".join(traceback.format_tb(e.__traceback__))


def print_date(date:int) -> str:
   if date is None:
      return "---"
   else:
      return str(datetime.fromtimestamp(int(date / 1000)))
