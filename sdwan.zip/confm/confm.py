#!/usr/bin/env python3

import asyncio
import logging
# import jsonpickle

import fastapi
from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse, Response
#from injector import Injector, singleton
import inject
import os, signal

import request_counter
from mqtt import MQTT_Dispatcher
from rabbit import RabbitEvents

VERSION = "0.007"
VERSION_DESCRIPTION = "Now we provide id numbers our front team."





# Set up logging configuration
logging.basicConfig(
   level=logging.DEBUG,
   format='%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s - Line %(lineno)d'
   #format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s - Line %(lineno)d'
   #format = '\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)

#loop = asyncio.new_event_loop()
#asyncio.set_event_loop(loop)



log = logging.getLogger("MAIN")


MQTT_SERVER = os.environ.get("MQTT_SERVER")

if MQTT_SERVER == None:
   print(f"ERROR: You have to set MQTT_SERVER=? env variable.")
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)



import exceptions




from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs
from interfaces.service_interface import IServices
from interfaces.vnf_template_interface import IVnfTemplates
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs
from interfaces.service_template_interface import IServiceTemplates



from platforms import Platforms
from hubs import Hubs
from sites import Sites
from cpes import Cpes
from vnf_templates import VnfTemplates
from vnfs import Vnfs
from services import Services
from service_templates import ServiceTemplates
from api_internal_v1_0 import ApiInternal_1_0
from api_lk_v1_0 import ApiLK_1_0


from interfaces.keys import *


# injector = Injector()
# injector.binder.bind(IPlatforms, to=Platforms, scope=singleton)
# injector.binder.bind(IHubs, to=Hubs, scope=singleton)
# injector.binder.bind(ISites, to=Sites, scope=singleton)
# injector.binder.bind(INodes, to=Nodes, scope=singleton)
# injector.binder.bind(IVnfTemplates, to=VnfTemplates, scope=singleton)
# injector.binder.bind(IVnfs, to=Vnfs, scope=singleton)
# injector.binder.bind(IServices, to=Services, scope=singleton)
# injector.binder.bind(IServiceTemplates, to=ServiceTemplates, scope=singleton)
# injector.binder.bind(ApiInternal_1_0, to=ApiInternal_1_0, scope=singleton)
# injector.binder.bind(ApiLK_1_0, to=ApiLK_1_0, scope=singleton)
# injector.binder.bind(FastAPI, to=FastAPI, scope=singleton)
# injector.binder.bind(MQTT_Dispatcher, to=MQTT_Dispatcher, scope=singleton)
#
#
# platforms = injector.get(IPlatforms)
# platforms.readFromFile()
#
# hubs = injector.get(Hubs)
# hubs.readFromFile()
#
# nodes = injector.get(Nodes)
# nodes.readFromFile()
#
# domains = injector.get(ISites)
# domains.readFromFile()
#
# vnf_templates = injector.get(VnfTemplates)
# vnf_templates.readFromFile()
#
# vnfs = injector.get(Vnfs)
# vnfs.readFromFile()
#
# services = injector.get(Services)
# services.readFromFile()
#
# service_templates = injector.get(ServiceTemplates)
# service_templates.readFromFile()


app = FastAPI()
mqtt = MQTT_Dispatcher()

def configure(binder):
   platforms = Platforms()
   platforms.readFromFile()
   binder.bind(IPlatforms, platforms)


   hubs = Hubs()
   hubs.readFromFile()
   binder.bind(IHubs, hubs)

   # async def main():
   #    for i in range(1, 65000):
   #       await hubs.add(RID=i,
   #                name=f"0000000000000000000000000000000000000000000000000000000000000000000000000000hub_{i}",
   #                description="jkhkjhkjhkjhkjkjhkjhkjhjihnfhgfhgbnfghhgfhgfhfnhgfnhgfhgfgfgfhfhfvhgvgvhvjh",
   #                longitude=0,
   #                latitude=0,
   #                state=Hubs.Hub.State.ENABLED,
   #                qcgeo=None,
   #                easguid=None,
   #                address="hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh",
   #                id=0,
   #                key=None,
   #                port=10000)
   #
   # loop = asyncio.get_event_loop()
   # loop.create_task(main())


   sites = Sites()
   sites.readFromFile()
   binder.bind(ISites, sites)


   cpes = Cpes()
   cpes.readFromFile()
   binder.bind(ICpes, cpes)


   vnfs = Vnfs()
   vnfs.readFromFile()
   binder.bind(IVnfs, vnfs)


   vnf_templates = VnfTemplates()
   vnf_templates.readFromFile()
   binder.bind(IVnfTemplates, vnf_templates)


   services = Services()
   services.readFromFile()
   binder.bind(IServices, services)


   service_templates = ServiceTemplates()
   service_templates.readFromFile()
   binder.bind(IServiceTemplates, service_templates)

   rabbitEvents = RabbitEvents()
   binder.bind(RabbitEvents, rabbitEvents)


   binder.bind(FastAPI, app)

   binder.bind(MQTT_Dispatcher, mqtt)

inject.configure(configure)







#app = FastAPI()

#loop = asyncio.new_event_loop()
loop = asyncio.get_event_loop()

#print(jsonpickle.encode(platforms.getAll()))


@app.exception_handler(HTTPException)
async def custom_http_exception_handler(request, exc):
   return fastapi.responses.JSONResponse(content=exc.detail, status_code=exc.status_code)



async def set_body(request: Request, body: bytes):
   async def receive():
      return {"type": "http.request", "body": body}

   request._receive = receive


async def get_body(request: Request) -> bytes:
   body = await request.body()
   await set_body(request, body)
   return body


@app.middleware("http")
async def custom_middleware(request: Request, call_next):
   request.state.rid = await request_counter.increment()

   await set_body(request, await request.body())

   log.info(f"\n\n\n\n\n[{request.state.rid}]-----------------Incoming Request (begin)---------------------\n"
            f"Method: {request.method}\n"
            f"URL: {request.url}\n"
            f"Headers: {request.headers}\n"
            f"Query Parameters: {request.query_params}\n"
            f"Path Parameters: {request.path_params}\n"
            f"Client Host: {request.client.host}\n"
            f"Received Data: {await request.body()}\n"
            f"[{request.state.rid}]------------------Incoming Request (end)----------------------\n\n\n\n\n")


   try:
      response = await call_next(request)

      #return response

      response_body = b""
      async for chunk in response.body_iterator:
         response_body += chunk

      log.info(f"[{request.state.rid}] Response:\n{response_body.decode()}")

      response.headers["RID"] = str(request.state.rid)

      return Response(content=response_body, status_code=response.status_code,
                      headers=dict(response.headers), media_type=response.media_type)
   except exceptions.AbstractException as e:
      log.info(f"[{request.state.rid}] Response:\n{e.getDictionary()}")

      return JSONResponse(status_code=e.getHttpErrorCode(),
                          content=e.getDictionary(),
                          headers={"RID": str(request.state.rid)})


# def wrap_exceptions(func):
#    @wraps(func)
#    async def wrapper(*args, **kwargs):
#       try:
#          return await func(*args, **kwargs)
#       except exceptions.AbstractException as e:
#          raise HTTPException(e.getHttpErrorCode(), e.getDictionary())
#
#    return wrapper





api_internal = inject.instance(ApiInternal_1_0)
api_lk = inject.instance(ApiLK_1_0)


@inject.autoparams()
async def main(rabbitEvents:RabbitEvents=None):
   await api_internal.addRoutes()
   await rabbitEvents.start()

   await api_lk.addRoutes()

loop.create_task(main())


#mqtt = inject.instance(MQTT_Dispatcher)
loop.create_task(mqtt.start())


