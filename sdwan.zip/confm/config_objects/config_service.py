from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional


@dataclass(frozen=True)
class ConfigService():
   name: str
   id: int
   uuid: str
   priority: int

   class State(str, Enum):
      ENABLED = "enabled"
      DISABLED = "disabled"
   state: State

   template: str

   @dataclass(frozen=True)
   class Endpoint():
      vnf: str

      class Type(str, Enum):
         SERVER = "server"
         CLIENT = "client"
         ALL = "all"
      type: Type

      uuid: str
      port: int
   endpoints: List[Endpoint]


   description: Optional[str] = None
