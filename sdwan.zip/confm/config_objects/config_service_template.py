from typing import List, Optional
from dataclasses import dataclass

@dataclass(frozen=True)
class ConfigServiceTemplate:
   name: str
   uuid: str
   description: str

   port1: List
   port2: Optional[List] = None
