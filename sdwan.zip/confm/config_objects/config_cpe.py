from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Union

@dataclass(frozen=True)
class ConfigCpe:
   name: str
   id: int
   uuid: str
   domain: str
   key: str
   hub: str

   class State(str, Enum):
      ENABLED  = "enabled"
      DISABLED = "disabled"
   state: State


   platform: str

   @dataclass(frozen=True)
   class Interface:
      @dataclass(frozen=True)
      class Connection:
         @dataclass(frozen=True)
         class Static:
            ip: str
            mask: str
            gateway: str
            dns: Optional[str] = None
         @dataclass(frozen=True)
         class DHCP:
            address: Optional[str] = None
         @dataclass(frozen=True)
         class WiFi:
            SSID: str
            password: str
         @dataclass(frozen=True)
         class GSM:
            apn: str
            user: str
            password: str
         static:Optional[Static] = None
         dhcp:Optional[DHCP] = None
         wifi:Optional[WiFi] = None
         gsm:Optional[GSM] = None
      connection: Connection

      class Status(str, Enum):
         UP   = "up"
         DOWN = "down"
      status: Optional[Status] = None
      speed:Optional[int] = None

      @dataclass(frozen=True)
      class QOS:
         priority: int
         min: float
         max: float
         className: str
      qos:Optional[List[QOS]] = None

   wan: Dict[int, Interface]
   description: Optional[str] = None

   class Status(str, Enum):
      OFFLINE = "offline"
      REGISTERED = "registered"
      ONLINE = "online"

