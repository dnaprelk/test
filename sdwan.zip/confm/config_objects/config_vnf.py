from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional


@dataclass(frozen=True)
class ConfigVnf:
   id: int
   uuid: str
   name: str
   domain: str
   template: str

   class State(str, Enum):
      ENABLED = "enabled"
      DISABLED = "disabled"
   state: State

   config: Dict
   ports: Dict

   description: Optional[str] = None

   class Status(str, Enum):
      STOPPED = "stopped"
      STOPPING = "stopping"
      STOP_EXPIRED = "stop_expired"
      RUNNING = "running"
      EXPIRED = "expired"
      TIMEOUT = "timeout"
      STARTING = "starting"
      START_EXPIRED = "start_expired"
      REBOOT_STOPPING = "reboot_stopping"
      REBOOT_STARTING = "reboot_starting"



@dataclass(frozen=True)
class Vnf(ConfigVnf):
   status:Optional[ConfigVnf.Status] = ConfigVnf.Status.STOPPED

   node:Optional[str] = None
