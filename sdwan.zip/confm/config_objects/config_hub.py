from dataclasses import dataclass
from enum import Enum
from typing import Optional



@dataclass(frozen=True)
class ConfigHub:
   name: str
   id: int
   key: str
   address: str
   longitude: float
   latitude: float
   port: int

   class State(str, Enum):
      ENABLED = "enabled"
      DISABLED = "disabled"
   state: State


   uuid: str

   easguid: Optional[str] = None
   qcgeo: Optional[int] = None
   description: Optional[str] = None


   class Status(str, Enum):
      OFFLINE = "offline"
      REGISTERED = "registered"
      ONLINE = "online"
