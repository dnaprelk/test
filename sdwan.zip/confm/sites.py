import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import logging
import asyncio
from tabulate import tabulate
import json
#import jsonpickle
from abstract import Abstract
from injector import inject, Injector, singleton, Inject
from from_dict import from_dict
import inject
import dataclasses


import config
import log_utils
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs
import exceptions


log = logging.getLogger("DOMAINS")
log.setLevel(config.getLogLevel("domains"))


class Sites(Abstract):

   @dataclass(frozen=True)
   class Site:
      name: str
      address: str
      longitude: float
      latitude: float
      uuid: str
      description: Optional[str] = None
      easguid: Optional[str] = None
      qcgeo: Optional[int] = None


   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, Sites.Site] = {}
      self.dictUUID:Dict[str, Sites.Site] = {}


   def readFromFile(self):
      dictSites = config.getSites()

      logTable=[]
      for sSiteName in dictSites.keys():
         dictSites[sSiteName]["name"] = sSiteName
         site = from_dict(Sites.Site, dictSites[sSiteName])

         self.dictName[sSiteName] = site
         self.dictUUID[site.uuid] = site

         logTable.append([site.name,
                          site.description,
                          site.longitude,
                          site.latitude,
                          site.uuid])

      log.info("\n" + tabulate(logTable, headers=["Name", "Description", "Longitude", "Latitude", "UUID"], tablefmt="grid"))




   def export(self):
      log.info("export()")

      dictConfig = {}
      for sVnfName in self.dictName.keys():
         dictConfig[sVnfName] = dataclasses.asdict(self.dictName[sVnfName])
      return dictConfig


   def save(self, dict):
      config.saveSites(dict)




   @inject.autoparams()
   async def isLocked(self, RID:int, site:Site, cpes:ICpes, vnfs:IVnfs):
      log.info(f"[{RID}] isLocked() name='{site.name}'")
      for cpe in await cpes.getAllList(RID):
         if cpe.domain == site.name:
            raise exceptions.ObjectInUseException("Domains", "uuid", site.uuid, "Cpes", "uuid", cpe.uuid)
      for vnf in await vnfs.getAllList(RID):
         if vnf.domain == site.name:
            raise exceptions.ObjectInUseException("Domains", "uuid", site.uuid, "Vnfs", "uuid", vnf.uuid)



   async def add(self, RID:int,
                 name:str,
                 description:str,
                 address:str,
                 latitude:float,
                 longitude:float,
                 easguid:str,
                 qcgeo:int
                 ) -> Site:
      async with self.lock:
         if name in self.dictName:
            raise exceptions.DuplicateNameException("Domains", name)

         site = Sites.Site(name=name,
                           uuid=str(uuid.uuid4()),
                           description=description,
                           address=address,
                           latitude=latitude,
                           longitude=longitude,
                           easguid=easguid,
                           qcgeo=qcgeo)

         log.info(f"[{RID}] add() name='{site.name}'\n" + self.printOne(site))

         self.dictName[site.name] = site
         self.dictUUID[site.uuid] = site

         log.info(f"[{RID}] ok, added.")

         return site




   async def update(self, RID:int,
                    uuid:str,
                    name:str,
                    description:str,
                    address:str,
                    latitude:float,
                    longitude:float,
                    easguid:str,
                    qcgeo:int
                    ) -> Site:
      async with self.lock:
         current_site:Sites.Site = await self.getByUUID(RID, uuid)

         site = Sites.Site(name=name,
                           uuid=current_site.uuid,
                           description=description,
                           address=address,
                           latitude=latitude,
                           longitude=longitude,
                           easguid=easguid,
                           qcgeo=qcgeo)

         log.info(f"[{RID}] update() name='{site.name}'\n" + self.printOne(site))

         self.dictName.pop(current_site.name)
         self.dictName[site.name] = site
         self.dictUUID[site.uuid] = site

         log.info(f"[{RID}] ok, updated.")

         return site




   def printOne(self, site:Site):
      tree = log_utils.Tree(f"DOMAIN: '{site.name}'")
      root = tree.getRoot()
      root.addNode(f"uuid={site.uuid}")
      root.addNode(f"description={site.description}")
      root.addNode(f"address={site.address}")
      root.addNode(f"latitude={site.latitude}")
      root.addNode(f"longitude={site.longitude}")
      return tree.print()



   def printList(self, listSites:List[Site]) -> str:
      logTable = []

      for site in listSites:
         logTable.append([site.name,
                          site.uuid,
                          site.description,
                          site.longitude,
                          site.latitude,
                          site.address,
                         ])

      return tabulate(logTable, headers=["Name", "UUID", "Description", "Longitude", "Latitude", "Address"], tablefmt="grid")
