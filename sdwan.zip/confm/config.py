import asyncio
import json
import subprocess
import os
from enum import Enum
from typing import Tuple, List, Dict, Optional
from dataclasses import dataclass
from from_dict import from_dict

import yaml
import logging
import log_utils



from dataclasses import dataclass



import dict_utils


CONFIG_PATH="../etc/config.yaml"
CONFIG_SYSTEM_PATH="../etc/system.yaml"
CONFIG_HISTORY = 10

log = logging.getLogger("CONFIG")
log.setLevel(logging.NOTSET)


lock = asyncio.Lock()

def check_nested_dict_path(nested_dict, path) -> bool:
   try:
      return all(path_part in nested_dict for path_part in path.split('.'))
   except Exception:
      return False


log.info("I am reading the system config file at path: " + CONFIG_SYSTEM_PATH)
with open(CONFIG_SYSTEM_PATH, "r") as file:
   systemFile = yaml.safe_load(file)

log.info("I am reading the config file at path: " + CONFIG_PATH)
with open(CONFIG_PATH, "r") as file:
   configFile = yaml.safe_load(file)

if configFile == None:
   configFile = {}

#Let's set default things and init sections if absent
if check_nested_dict_path(configFile, "platforms") is False:
   configFile["platforms"] = {}
if check_nested_dict_path(configFile, "hubs") is False:
   configFile["hubs"] = {}
if check_nested_dict_path(configFile, "domains") is False:
   configFile["domains"] = {}
if check_nested_dict_path(configFile, "nodes") is False:
   configFile["nodes"] = {}
if check_nested_dict_path(configFile, "vnfs") is False:
   configFile["vnfs"] = {}
if check_nested_dict_path(configFile, "vnf_templates") is False:
   configFile["vnf_templates"] = {}
if check_nested_dict_path(configFile, "services") is False:
   configFile["services"] = {}
if check_nested_dict_path(configFile, "service_templates") is False:
   configFile["service_templates"] = {}



log.info("Done. The config:\n" + log_utils.print_tree(configFile))






def __convertLog(sLevel):
   if sLevel == None:
      return logging.NOTSET
   # Yaml converts OFF to False
   # By spec
   elif sLevel == False or sLevel.lower() == "off":
      return logging.CRITICAL + 1
   elif sLevel.lower() == "error":
      return logging.ERROR
   elif sLevel.lower() == "warn":
      return logging.WARN
   elif sLevel.lower() == "info":
      return logging.INFO
   elif sLevel.lower() == "debug":
      return logging.DEBUG

   return logging.NOTSET


def getLogLevel(sLogger):
   try:
      return __convertLog(systemFile["logs"][sLogger.lower()])
   except Exception:
      #if there is no log section - TRACE level
      pass
   return logging.NOTSET
def getMQTTLogLevel(interfaceName):
   try:
      return __convertLog(systemFile["logs"]["mqtt"][interfaceName.lower()])
   except Exception:
      pass
   return logging.NOTSET



def getPlatforms() -> Dict:
   return configFile["platforms"]
def getHubs() -> Dict:
   return configFile["hubs"]
def getSites() -> Dict:
   return configFile["domains"]
def getNodes() -> Dict:
   return configFile["nodes"]
def getVnfTemplates() -> Dict:
   return configFile["vnf_templates"]
def getVnfs() -> Dict:
   return configFile["vnfs"]
def getServices() -> Dict:
   return configFile["services"]
def getServiceTemplates() -> Dict:
   return configFile["service_templates"]

def getAgents() -> Dict:
   return systemFile["agents"]


@dataclass(frozen=True)
class Events:
   @dataclass(frozen=True)
   class Rabbit:
      connection: str
      queue:str

      @dataclass(frozen=True)
      class SSL:
         cafile: str
         client_certificate: str
         client_key: str
      ssl: Optional[SSL] = None
   rabbit: Rabbit

def getEvents() -> Events:
   if "events" in systemFile:
      return from_dict(Events, systemFile["events"])
   return None



def enum_to_string(enum_value):
   if isinstance(enum_value, Enum):
      return enum_value.value
   return enum_value


def convert_enums_to_strings(data):
   if isinstance(data, dict):
      return {key: convert_enums_to_strings(value) for key, value in data.items()}
   elif isinstance(data, list):
      return [convert_enums_to_strings(item) for item in data]
   else:
      return enum_to_string(data)


def saveToFile(sFileName:str = CONFIG_PATH, data=None):

   if data is None:
      data = configFile

   log.info("saveFile()")
   with open(sFileName, 'w') as yaml_file:
      log.info(log_utils.print_tree(configFile))
      #yaml_file.write(json.dumps(configFile))
      #yaml.dump(configFile, yaml_file, default_flow_style=False, indent=3, sort_keys=False)
      #yaml.safe_dump(json.loads(json.dumps(configFile)), yaml_file, default_flow_style=False, indent=3, sort_keys=False)
      yaml.safe_dump(convert_enums_to_strings(dict_utils.clean_nones(data)),
                     yaml_file,
                     default_flow_style=False,
                     indent=3,
                     sort_keys=False)
   log.info("saveFile() done.")


def saveHubs(dictHubs:Dict):
   configFile["hubs"] = dictHubs

def saveCPEs(dictCPEs:Dict):
   configFile["nodes"] = dictCPEs

def saveVnfs(dictVNFs:Dict):
   configFile["vnfs"] = dictVNFs

def saveSites(dictSites:Dict):
   configFile["domains"] = dictSites

def saveServices(dictServices:Dict):
   configFile["services"] = dictServices

def saveServiceTemplates(dictServiceTemplates:Dict):
   configFile["service_templates"] = dictServiceTemplates

def saveVnfTemplates(dictVnfTemplates:Dict):
   configFile["vnf_templates"] = dictVnfTemplates

def savePlatforms(dictPlatforms:Dict):
   configFile["platforms"] = dictPlatforms


def getConfigTime() -> int:
   return int(1000 * os.path.getctime(CONFIG_PATH))