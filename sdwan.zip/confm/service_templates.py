import logging
import uuid
from dataclasses import dataclass
import dataclasses
from typing import Dict, List, Optional
import inject
from from_dict import from_dict
from tabulate import tabulate


import config
import log_utils
from abstract import Abstract
from mqtt import MQTT_Dispatcher

from config_objects.config_service_template import ConfigServiceTemplate

log = logging.getLogger("SERVICE TEMPLATES")
log.setLevel(config.getLogLevel("service_templates"))


class ServiceTemplates(Abstract):

   @dataclass(frozen=True)
   class ServiceTemplate(ConfigServiceTemplate):
      pass

   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, ServiceTemplates.ServiceTemplate] = {}
      self.dictUUID:Dict[str, ServiceTemplates.ServiceTemplate] = {}




   @inject.autoparams()
   async def add(self,
                 RID:int,
                 name:str,
                 description:str,
                 port1:List,
                 port2:List,
                 mqtt:MQTT_Dispatcher) -> ServiceTemplate:
      async with self.lock:
         serviceTemplate = ServiceTemplates.ServiceTemplate(name=name,
                                                            uuid=str(uuid.uuid4()),
                                                            description=description,
                                                            port1=port1,
                                                            port2=port2)
         self.addDB(RID, serviceTemplate)

      await mqtt.addServiceTemplate(RID, serviceTemplate)

      return serviceTemplate



   @inject.autoparams()
   async def update(self,
                    RID:int,
                    name:str,
                    description:str,
                    port1:List,
                    port2:List,
                    mqtt:MQTT_Dispatcher) -> ServiceTemplate:
      async with self.lock:
         current_service:ServiceTemplates.ServiceTemplate = await self.getByName(RID, name)

         serviceTemplate = ServiceTemplates.ServiceTemplate(name=name,
                                                            uuid=current_service.uuid,
                                                            description=description,
                                                            port1=port1,
                                                            port2=port2)
         self.updateDB(RID, serviceTemplate)

      await mqtt.updateServiceTemplate(RID, serviceTemplate)


      return serviceTemplate


   @inject.autoparams()
   async def beforeDelete(self, RID:int, serviceTemplate:ServiceTemplate, mqtt:MQTT_Dispatcher):
      log.info(f"[{RID}] beforeDelete() name='{serviceTemplate.name}'")
      await mqtt.deleteServiceTempate(RID, serviceTemplate)




   def readFromFile(self):
      dictServices = config.getServiceTemplates()

      for sServiceTemplateName in dictServices.keys():
         dictServices[sServiceTemplateName]["name"] = sServiceTemplateName
         serviceTemplate = from_dict(ServiceTemplates.ServiceTemplate, dictServices[sServiceTemplateName])

         self.addDB(-1, serviceTemplate)

      log.info("\n" + self.printList(list(self.dictName.values())))



   def export(self):
      log.info("export()")

      dictConfig = {}
      for sServiceTemplateName in self.dictName.keys():
         dictServiceTemplate = dataclasses.asdict(self.dictName[sServiceTemplateName])
         configServiceTemplate = from_dict(ConfigServiceTemplate, dictServiceTemplate)
         dictConfig[sServiceTemplateName] = dataclasses.asdict(configServiceTemplate)
      return dictConfig

   def save(self, dict):
      config.saveServiceTemplates(dict)



   def printOne(self, service_template:ServiceTemplate):
      tree = log_utils.Tree(f"SERVICE {service_template.name}")
      root = tree.getRoot()
      root.addNode(f"uuid={service_template.uuid}")
      root.addNode(f"description={service_template.description}")
      root.addNode(f"port1={service_template.port1}")
      root.addNode(f"port2={service_template.port2}")

      return tree.print()



   def printList(self, listServices:List[ServiceTemplate]) -> str:
      logTable = []

      for service in listServices:
         logTable.append([service.name,
                          service.uuid,
                          service.description,
                          service.port1,
                          service.port2
                         ])

      return tabulate(logTable, headers=["Name",
                                         "UUID",
                                         "Description",
                                         "port1",
                                         "port2"], tablefmt="grid")
