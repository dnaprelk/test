from abstract import Abstract

class IVnfTemplates(Abstract):
   pass