from abstract import Abstract

class IServiceTemplates(Abstract):
   pass