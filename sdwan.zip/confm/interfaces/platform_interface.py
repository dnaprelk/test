from abstract import Abstract

class IPlatforms(Abstract):
   pass