from abstract import Abstract

class ICpes(Abstract):
   pass