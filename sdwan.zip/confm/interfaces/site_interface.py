from abstract import Abstract

class ISites(Abstract):
   pass