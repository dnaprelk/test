from abstract import Abstract

class IHubs(Abstract):
   pass