from fastapi import FastAPI

class IFastAPI(FastAPI):
   pass


class IApiInternal_1_0:
   pass
class IApiLK_1_0:
   pass
