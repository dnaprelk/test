from abstract import Abstract

class IServices(Abstract):
   pass