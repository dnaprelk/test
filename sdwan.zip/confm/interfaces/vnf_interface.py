from abstract import Abstract

class IVnfs(Abstract):
   pass