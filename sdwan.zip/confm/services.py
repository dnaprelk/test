from dataclasses import dataclass, field
from typing import Dict, List, Optional
import logging
from tabulate import tabulate
from enum import Enum
from pydantic import BaseModel
from from_dict import from_dict
import traceback
import uuid
import inject
import dataclasses


import config
import log_utils
from abstract import Abstract
import exceptions
from mqtt import MQTT_Dispatcher

from interfaces.service_template_interface import IServiceTemplates
from config_objects.config_service import ConfigService


log = logging.getLogger("SERVICES")
log.setLevel(config.getLogLevel("services"))


class Services(Abstract):

   @dataclass(frozen=True)
   class Service(ConfigService):
      class Status(str, Enum):
         DOWN   = "down"
         NORMAL = "normal"
      status:Optional[Status] = Status.DOWN


   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, Services.Service] = {}
      self.dictUUID:Dict[str, Services.Service] = {}
      self.dictID:  Dict[int, Services.Service] = {}




   @inject.autoparams()
   async def add(self,
                 RID:int,
                 name:str,
                 id:int,
                 description:str,
                 priority:int,
                 sServiceTemplateName:str,
                 state:Service.State,
                 endpoints:List[Service.Endpoint],
                 service_templates:IServiceTemplates,
                 mqtt:MQTT_Dispatcher) -> Service:
      async with self.lock:
         if name in self.dictName:
            raise exceptions.DuplicateNameException("Services", name)

         #Let's check they are there
         service_template = await service_templates.getByName(RID, sServiceTemplateName)


         if id == 0:
            id = self.getFreeId(id, 255)

         service = Services.Service(name=name,
                                    id=id,
                                    uuid=str(uuid.uuid4()),
                                    description=description,
                                    priority=priority,
                                    template=sServiceTemplateName,
                                    state=state,
                                    status=Services.Service.Status.DOWN,
                                    endpoints=endpoints)
         self.addDB(RID, service)

      await mqtt.addService(RID, service)
      return service



   @inject.autoparams()
   async def update(self,
                    RID:int,
                    name:str,
                    description:str,
                    priority:int,
                    sServiceTemplateName:str,
                    state:Service.State,
                    endpoints:List[Service.Endpoint],
                    service_templates:IServiceTemplates,
                    mqtt:MQTT_Dispatcher) -> Service:
      async with self.lock:
         current_service:Services.Service = await self.getByName(RID, name)

         #Let's check they are there
         service_template = await service_templates.getByName(RID, sServiceTemplateName)

         service = Services.Service(name=name,
                                    id=current_service.id,
                                    uuid=current_service.uuid,
                                    description=description,
                                    priority=priority,
                                    template=sServiceTemplateName,
                                    state=state,
                                    status=Services.Service.Status.DOWN,
                                    endpoints=endpoints)
         self.updateDB(RID, service)

      await mqtt.updateService(RID, service)
      return service



   @inject.autoparams()
   async def beforeDelete(self, RID:int, service:Service, mqtt:MQTT_Dispatcher):
      log.info(f"[{RID}] beforeDelete() name='{service.name}'")
      await mqtt.deleteService(RID, service)



   async def isLocked(self, RID:int, service:Service):
      log.info(f"[{RID}] isLocked() name='{service.name}'")
      return False




   def readFromFile(self):
      log.info("import()")

      dictServices = config.getServices()

      for sServiceName in dictServices.keys():
         dictServices[sServiceName]["name"] = sServiceName

         try:
            config_service = from_dict(ConfigService, dictServices[sServiceName])
            dictServiceConfig = dataclasses.asdict(config_service)
            service = from_dict(Services.Service, dictServiceConfig)

            self.addDB(-1, service)

         except Exception as e:
            log.critical(f"\n{log_utils.print_tree(dictServices[sServiceName])}\n{str(e)}\n" + "\n".join(traceback.format_tb(e.__traceback__)))


      log.info("\n" + self.printList(list(self.dictName.values())))




   def export(self):
      log.info("export()")

      dictConfig = {}
      for sServiceName in self.dictName.keys():
         dictService = dataclasses.asdict(self.dictName[sServiceName])
         configService = from_dict(ConfigService, dictService)
         dictConfig[sServiceName] = dataclasses.asdict(configService)
      return dictConfig



   def save(self, dict):
      config.saveServices(dict)






   def printOne(self, service:Service):
      tree = log_utils.Tree(f"SERVICE {service.name}")
      root = tree.getRoot()
      root.addNode(f"id={service.id}")
      root.addNode(f"uuid={service.uuid}")
      root.addNode(f"description={service.description}")
      root.addNode(f"template={service.template}")
      root.addNode(f"endpoints={service.endpoints}")
      root.addNode(f"state={service.state}")
      root.addNode(f"status={service.status}")

      return tree.print()


   def printList(self, listServices:List[Service]) -> str:
      logTable = []

      for service in listServices:

         logTable.append([service.name,
                          service.id,
                          service.uuid,
                          service.priority,
                          service.template,
                          service.description,
                          service.state,
                          service.status,
                          "\n".join(str(endpoint) for endpoint in service.endpoints)
                         ])

      return tabulate(logTable, headers=["Name",
                                         "ID",
                                         "UUID",
                                         "Priority",
                                         "Template",
                                         "Description",
                                         "State",
                                         "Status",
                                         "Endpoints"], tablefmt="grid")
