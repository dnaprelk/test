import copy
import logging
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional

import inject
from from_dict import from_dict
from tabulate import tabulate

import config
import exceptions
import log_utils
from abstract import Abstract


from interfaces.node_interface import ICpes
from config_objects.config_hub import ConfigHub

from mqtt import MQTT_Dispatcher

log = logging.getLogger("HUBS")
log.setLevel(config.getLogLevel("hubs"))



class Hubs(Abstract):

   @dataclass(frozen=True)
   class Hub(ConfigHub):

      status: Optional[ConfigHub.Status] = ConfigHub.Status.OFFLINE

      ip: Optional[str] = None
      pubkey: Optional[str] = None
      src: Optional[str] = None
      uptime: Optional[int] = None



   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, Hubs.Hub] = {}
      self.dictUUID:Dict[str, Hubs.Hub] = {}
      self.dictID:  Dict[int, Hubs.Hub] = {}



   # def addHub(self, hub:Hub):
   #    if hub.name in self.dictName:
   #       raise exceptions.DuplicateNameException("Hubs", hub.name)
   #    if hub.uuid in self.dictUUID:
   #       raise exceptions.DuplicateUuidException("Hubs", hub.uuid)
   #    if hub.id in self.dictID:
   #       raise exceptions.DuplicateIdException("Hubs", hub.id)
   #
   #    self.updateHub(hub)
   #
   #
   #
   # def updateHub(self, hub:Hub):
   #    self.dictName[hub.name] = hub
   #    self.dictUUID[hub.uuid] = hub
   #    self.dictID[hub.id] = hub





   def readFromFile(self):
      dictHubs = config.getHubs()

      for sHubName in dictHubs.keys():
         dictHubs[sHubName]["name"] = sHubName
         config_hub = from_dict(ConfigHub, dictHubs[sHubName])
         dictHubConfig = dataclasses.asdict(config_hub)
         hub = from_dict(Hubs.Hub, dictHubConfig)

         self.addDB(-1, hub)

      log.info("\n" + self.printList(list(self.dictName.values())))




   def export(self) -> dict:
      dictConfig = {}
      for sHubName in self.dictName.keys():
         hub = dataclasses.asdict(self.dictName[sHubName])
         configHub = from_dict(ConfigHub, hub)
         dictConfig[sHubName] = dataclasses.asdict(configHub)
      return dictConfig

   def save(self, dict):
      config.saveHubs(dict)



   @inject.autoparams()
   async def isLocked(self, RID:int, hub:Hub, cpes:ICpes):
      log.info(f"[{RID}] isLocked() name='{hub.name}'")
      for node in await cpes.getAllList(RID):
         if node.hub == hub.name:
            raise exceptions.ObjectInUseException("Hubs", "uuid", hub.uuid, "Cpes", "uuid", node.uuid)




   @inject.autoparams()
   async def add(self,
                 RID:int,
                 name:str,
                 id:int,
                 description:str,
                 address:str,
                 key:str,
                 longitude:float,
                 latitude:float,
                 port:int,
                 state:Hub.State,
                 easguid: str,
                 qcgeo: int,
                 mqtt:MQTT_Dispatcher) -> Hub:
      log.info(f"[{RID}] add() name='{name}' id={id} description='{description}'")
      async with self.lock:
         if id == 0:
            id = self.getFreeId(id, 253)

         hub = Hubs.Hub(name=name,
                        id=id,
                        uuid=str(uuid.uuid4()),
                        description=description,
                        address=address,
                        key=key,
                        longitude=longitude,
                        latitude=latitude,
                        port=port,
                        state=state,
                        status=Hubs.Hub.Status.OFFLINE,
                        easguid=easguid,
                        qcgeo=qcgeo)

         self.addDB(RID, hub)

      await mqtt.addHub(RID, hub)

      return hub



   @inject.autoparams()
   async def update(self,
                    RID:int,
                    uuid:str,
                    name:str,
                    description:str,
                    address:str,
                    key:str,
                    longitude:float,
                    latitude:float,
                    port:int,
                    state:Hub.State,
                    easguid: str,
                    qcgeo: int,
                    mqtt:MQTT_Dispatcher) -> Hub:
      log.info(f"[{RID}] add() name='{name}' description='{description}'")
      async with self.lock:
         current_hub:Hubs.Hub = await self.getByUUID(RID, uuid)

         hub = Hubs.Hub(name=name,
                        id=current_hub.id,
                        uuid=current_hub.uuid,
                        description=description,
                        address=address,
                        key=key,
                        longitude=longitude,
                        latitude=latitude,
                        port=port,
                        state=state,
                        status=Hubs.Hub.Status.OFFLINE,
                        easguid=easguid,
                        qcgeo=qcgeo)

         self.updateDB(RID, hub)

      await mqtt.updateHub(RID, hub)

      return hub


   @inject.autoparams()
   async def beforeDelete(self, RID:int, hub:Hub, mqtt:MQTT_Dispatcher):
      log.info(f"[{RID}] beforeDelete() name='{hub.name}'")
      await mqtt.deleteHub(RID, hub)


   def printOne(self, hub:Hub):
      tree = log_utils.Tree(f"HUB {hub.name}")
      root = tree.getRoot()
      root.addNode(f"id={hub.id}")
      root.addNode(f"uuid={hub.uuid}")
      root.addNode(f"description={hub.description}")
      root.addNode(f"state={hub.state}")
      root.addNode(f"status={hub.status}")
      root.addNode(f"ip:port={hub.ip}:{hub.port}")
      root.addNode(f"pubkey={hub.pubkey}")
      return tree.print()



   def printList(self, listHubs:List[Hub]) -> str:
      logTable = []

      for hub in listHubs:
         logTable.append([hub.name,
                          hub.id,
                          hub.description,
                          hub.key,
                          hub.longitude,
                          hub.latitude,
                          hub.port,
                          hub.state,
                          hub.ip,
                          hub.pubkey,
                          hub.status,
                          hub.uuid,
                          hub.src])

      return tabulate(logTable, headers=["Name", "ID", "Description", "Key", "Longitude", "Latitude", "Port", "State", "IP", "Pubkey", "Status", "UUID", "src"], tablefmt="grid")





   # async def registerHub(self, RID:int, sHubName:str, ip:str, pubkey:str, state:Hub.State, status:Hub.Status):
   #    log.info(f"[{RID}] registerHub() name='{sHubName}' ip='{ip}' pubkey='{pubkey}' state='{state}' status='{status}'")
   #
   #    async with self.lock:
   #       hub = await self.getByName(RID, sHubName)
   #       updatedHub = dataclasses.replace(hub, ip=ip, pubkey=pubkey, state=state, status=status)
   #
   #       self.updateDB(RID, updatedHub)
   #
   #    log.info(f"[{RID}] ok, registerred.")



   async def registerHub(self, RID:int, sHubName:str, ip:str, pubkey:str, status:Hub.Status):
      log.info(f"[{RID}] registerHub() name='{sHubName}' ip='{ip}' pubkey='{pubkey}' status='{status}'")

      async with self.lock:
         hub = await self.getByName(RID, sHubName)
         updatedHub = dataclasses.replace(hub, ip=ip, pubkey=pubkey,  status=status)

         self.updateDB(RID, updatedHub)

      log.info(f"[{RID}] ok, registerred.")