import time


def getTime() -> int:
   return int(time.time() * 1000)

def python2ms(timePython) -> int:
   return int(timePython * 1000)
