from typing import Dict, List, Optional

import config
import inject
from fastapi import FastAPI, Request
from interfaces.node_interface import ICpes
from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.vnf_interface import IVnfs
from interfaces.vnf_template_interface import IVnfTemplates
from config_objects.config_vnf import Vnf
from dataclasses import dataclass


@dataclass(frozen=True)
class LKAbstractVnf:
   vnfName: str
   vnfType: str
   siteId: str
   siteName: str
   vnfState: Vnf.State

@dataclass(frozen=True)
class LKVnf(LKAbstractVnf):
   vnfId: str
   vnfNumber:int
   vnfStatus: Vnf.Status
   cpeId: Optional[str] = None
   vnfDescription: Optional[str] = None


@dataclass(frozen=True)
class LKAddVnf(LKAbstractVnf):
   vnfConfig: Dict
   portMapping: Dict
   cpeId: Optional[str] = None
   vnfDescription: Optional[str] = None

@dataclass(frozen=True)
class LKUpdateVnf(LKAbstractVnf):
   vnfId: str
   vnfConfig: Dict
   portMapping: Dict
   cpeId: Optional[str] = None
   vnfDescription: Optional[str] = None




@dataclass(frozen=True)
class LKVnfOne(LKAbstractVnf):
   vnfId: str
   vnfNumber: str
   siteId: str
   vnfStatus: Vnf.Status
   vnfConfig: Dict
   portMapping: Dict
   cpeId: Optional[str] = None
   vnfDescription: Optional[str] = None



@inject.autoparams()
async def vnfToLK(RID,
                  vnf:Vnf,
                  sites:ISites,
                  vnfs:IVnfs,
                  vnf_templates:IVnfTemplates,
                  cpes:ICpes,
                  platforms:IPlatforms) -> LKVnf:
   site = await sites.getByName(RID, vnf.domain)

   cpeId = None
   if vnf.node is not None:
      cpeId = (await cpes.getByName(RID, vnf.node)).uuid

   vnfType = (await vnf_templates.getByName(RID, vnf.template)).type

   return LKVnf(vnfId=vnf.uuid,
                vnfNumber=vnf.id,
                vnfName=vnf.name,
                vnfDescription=vnf.description,
                vnfType=vnfType,
                siteId=site.uuid,
                siteName=site.name,
                cpeId=cpeId,
                vnfState=vnf.state,
                vnfStatus=Vnf.Status.RUNNING if vnf.status == Vnf.Status.RUNNING else Vnf.Status.STOPPED)

@inject.autoparams()
async def oneVnfToLK(RID,
                     vnf:Vnf,
                     sites:ISites,
                     vnfs:IVnfs,
                     vnf_templates:IVnfTemplates,
                     cpes:ICpes,
                     platforms:IPlatforms) -> LKVnfOne:
   siteId = (await sites.getByName(RID, vnf.domain)).uuid

   cpeId = None
   if vnf.node is not None:
      cpeId = (await cpes.getByName(RID, vnf.node)).uuid

   vnfType = (await vnf_templates.getByName(RID, vnf.template)).type

   return LKVnfOne(vnfId=vnf.uuid,
                   vnfNumber=vnf.id,
                   vnfName=vnf.name,
                   siteId=siteId,
                   vnfType=vnfType,
                   siteName=vnf.domain,
                   vnfState=vnf.state,
                   vnfStatus=Vnf.Status.RUNNING if vnf.status == Vnf.Status.RUNNING else Vnf.Status.STOPPED,
                   vnfConfig=vnf.config,
                   portMapping=vnf.ports,
                   vnfDescription=vnf.description,
                   cpeId=cpeId)
