import logging
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

import config
import inject
from fastapi import FastAPI, Request
from service_templates import ServiceTemplates
from services import Services


from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs
from interfaces.service_interface import IServices
from interfaces.vnf_template_interface import IVnfTemplates
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs
from interfaces.service_template_interface import IServiceTemplates


log = logging.getLogger("REST_LK")
log.setLevel(config.getLogLevel("rest_lk"))


@dataclass(frozen=True)
class LKServiceAbstract:
   serviceName: str
   serviceTemplateName: str
   serviceTemplateId: str
   serviceState: Services.Service.State

   @dataclass(frozen=True)
   class Endpoint:
      siteId: str
      siteName: str
      vnfId: str
      vnfName: str
      portNumber: int

      class PortType(str, Enum):
         ALL    = "all"
         ANY    = "any"
         SERVER = "server"
         CLIENT = "client"
      portType: PortType


   class ServiceType(str, Enum):
      ANY_TO_ANY = 'a2a'
      POINT_TO_MANY = 'p2m'

@dataclass(frozen=True)
class LKService(LKServiceAbstract):
   serviceId: str
   serviceNumber: int
   servicePriority: int
   serviceType: str
   serviceStatus: Services.Service.Status
   serviceDescription: Optional[str] = None


@dataclass(frozen=True)
class LKAddService(LKServiceAbstract):
   priority:int

   endpoints:List[LKServiceAbstract.Endpoint]
   serviceDescription: Optional[str] = None


# b'{
# "serviceId":"00000000-0000-0000-0000-000000000000",
# "serviceName":"111111111111111",
# "serviceDescription":null,
# "priority":1,
# "serviceTemplateId":"556fd7da-224c-42f8-be77-4a51e3609f6b",
# "serviceTemplateName":"NAT",
# "serviceType":"p2m",
# "serviceState":"disabled",
# "endpoints":[
#      {"siteId":"f00cdd69-900f-46a2-b77a-a61256ffdee8","siteName":"MOB_TEST","vnfId":"9fd4793b-f703-4998-82e6-a174663fba3b","vnfName":"GW1","portNumber":1,"portType":"server"},
#      {"siteId":"128cb0ac-fef4-4677-b74b-2792184f2440","siteName":"TEST","vnfId":"695739df-c1ab-458a-bf50-b4cc6f9f48fb","vnfName":"LAN2","portNumber":1,"portType":"client"}
#   ]
# }



@dataclass(frozen=True)
class LKServiceOne(LKServiceAbstract):
   serviceName:str
   serviceNumber:int
   serviceId:str
   priority:int
   serviceType: LKServiceAbstract.ServiceType
   serviceStatus: Services.Service.Status

   endpoints:List[LKServiceAbstract.Endpoint]
   serviceDescription: Optional[str] = None



@inject.autoparams()
async def addServiceRoutes(app:FastAPI,
                           sites:ISites,
                           vnfs:IVnfs,
                           vnf_templates:IVnfTemplates,
                           services:IServices,
                           service_templates:IServiceTemplates):


   async def serviceToLK(RID, service:Services.Service) -> LKService:
      serviceTemplateId = (await service_templates.getByName(RID, service.template)).uuid

      serviceType = 'a2a'

      if (await service_templates.getByName(RID, service.template)).port2 != None:
         serviceType = 'p2m'

      return LKService(serviceId=service.uuid,
                       serviceNumber=service.id,
                       serviceName=service.name,
                       serviceTemplateId=serviceTemplateId,
                       serviceTemplateName=service.template,
                       servicePriority=service.priority,
                       serviceType=serviceType,
                       serviceState=service.state,
                       serviceStatus=service.status)



   @app.get("/api/lk/v1.0/services")
   async def listServices(request: Request) -> List[LKService]:
      return [await serviceToLK(request.state.rid, service) for service in await services.getAllList(request.state.rid)]

   @app.get("/api/lk/v1.0/service/{uuid}")
   async def getService(request: Request, uuid: str) -> LKServiceOne:
      service:Services.Service = await services.getByUUID(request.state.rid, uuid)
      template: ServiceTemplates.ServiceTemplate = await service_templates.getByName(request.state.rid, service.template)

      service_type = LKServiceOne.ServiceType.ANY_TO_ANY
      if template.port2 is not None:
         service_type = LKServiceOne.ServiceType.POINT_TO_MANY


      endpoints = []
      for endpoint in service.endpoints:
         if endpoint.type == Services.Service.Endpoint.Type.ALL:
            portType = "any"
         else:
            portType = endpoint.type

         vnf = await vnfs.getByName(request.state.rid, endpoint.vnf)
         domain = await sites.getByName(request.state.rid, vnf.domain)

         endpoint = LKServiceOne.Endpoint(siteId=domain.uuid,
                                          siteName=domain.name,
                                          vnfId=vnf.uuid,
                                          vnfName=vnf.name,
                                          portType=portType,
                                          portNumber=endpoint.port)
         endpoints.append(endpoint)


      lk_service = LKServiceOne(serviceName=service.name,
                                serviceId=service.uuid,
                                serviceNumber=service.id,
                                serviceDescription=service.description,
                                serviceTemplateName=template.name,
                                serviceTemplateId=template.uuid,
                                priority=service.priority,
                                serviceState=service.state,
                                serviceStatus="fail" if service.status == Services.Service.Status.DOWN else service.status,
                                serviceType=service_type,
                                endpoints=endpoints)


      return lk_service




   @app.post("/api/lk/v1.0/service")
   async def addService(request: Request, lk:LKAddService) -> LKServiceOne:
      endpoints = []
      for lk_endpoint in lk.endpoints:
         endpoint = Services.Service.Endpoint(vnf=lk_endpoint.vnfName,
                                              uuid=str(uuid.uuid4()),
                                              port=lk_endpoint.portNumber,
                                              type=Services.Service.Endpoint.Type.ALL if lk_endpoint.portType == "any" else lk_endpoint.portType)
         endpoints.append(endpoint)


      service = await services.add(RID=request.state.rid,
                                   name=lk.serviceName,
                                   id=0,
                                   description=lk.serviceDescription,
                                   priority=lk.priority,
                                   state=Services.Service.State(lk.serviceState),
                                   sServiceTemplateName=lk.serviceTemplateName,
                                   endpoints=endpoints)
      return await getService(request, service.uuid)



   @app.put("/api/lk/v1.0/service/{uuid}")
   async def updateService(request: Request, lk:LKAddService) -> LKServiceOne:
      endpoints = []
      for lk_endpoint in lk.endpoints:
         endpoint = Services.Service.Endpoint(vnf=lk_endpoint.vnfName,
                                              uuid=str(uuid.uuid4()),
                                              port=lk_endpoint.portNumber,
                                              type=Services.Service.Endpoint.Type.ALL if lk_endpoint.portType == "any" else lk_endpoint.portType)
         endpoints.append(endpoint)


      service = await services.update(RID=request.state.rid,
                                      name=lk.serviceName,
                                      description=lk.serviceDescription,
                                      priority=lk.priority,
                                      state=Services.Service.State(lk.serviceState),
                                      sServiceTemplateName=lk.serviceTemplateName,
                                      endpoints=endpoints)
      return await getService(request, service.uuid)





   @app.delete("/api/lk/v1.0/service/{uuid}")
   async def deleteService(request: Request, uuid: str):
      service = await getService(request, uuid)
      await services.deleteByUUID(request.state.rid, uuid)
      return service


