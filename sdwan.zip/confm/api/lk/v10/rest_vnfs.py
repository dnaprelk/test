import logging
from dataclasses import dataclass
from typing import Dict, List, Optional

import config
import inject
from fastapi import FastAPI, Request
from interfaces.node_interface import ICpes
from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.vnf_interface import IVnfs
from interfaces.vnf_template_interface import IVnfTemplates
from config_objects.config_vnf import Vnf

from api.lk.v10.objects_vnfs import *

log = logging.getLogger("REST_LK")
log.setLevel(config.getLogLevel("rest_lk"))





@inject.autoparams()
async def addVnfRoutes(app:FastAPI,
                       sites:ISites,
                       vnfs:IVnfs,
                       vnf_templates:IVnfTemplates,
                       cpes:ICpes,
                       platforms:IPlatforms):

   @app.get("/api/lk/v1.0/vnfs")
   async def listVnfs(request: Request) -> List[LKVnf]:
      return [await vnfToLK(request.state.rid, vnf) for vnf in await vnfs.getAllList(request.state.rid)]


   @app.get("/api/lk/v1.0/vnf/{uuid}")
   async def getVnf(request: Request, uuid: str) -> LKVnfOne:
      return await oneVnfToLK(request.state.rid, await vnfs.getByUUID(request.state.rid, uuid))


   @app.post("/api/lk/v1.0/vnf")
   async def addVnf(request: Request, lk:LKAddVnf) -> LKVnfOne:

      vnf = await vnfs.add(RID=request.state.rid,
                           name=lk.vnfName,
                           id=0,
                           description=lk.vnfDescription,
                           sDomainName=lk.siteName,
                           sTemplateName=lk.vnfType,
                           state=Vnf.State(lk.vnfState),
                           config=lk.vnfConfig,
                           ports=lk.portMapping
                           )
      return await getVnf(request, vnf.uuid)



   @app.put("/api/lk/v1.0/vnf/{vnf}")
   async def updateVnf(request: Request, lk:LKUpdateVnf) -> LKVnfOne:

      vnf = await vnfs.update(RID=request.state.rid,
                              uuid=lk.vnfId,
                              name=lk.vnfName,
                              description=lk.vnfDescription,
                              sDomainName=lk.siteName,
                              sTemplateName=lk.vnfType,
                              state=Vnf.State(lk.vnfState),
                              config=lk.vnfConfig,
                              ports=lk.portMapping
                             )
      return await getVnf(request, vnf.uuid)



   @app.delete("/api/lk/v1.0/vnf/{uuid}")
   async def deleteVnf(request: Request, uuid: str):
      vnf = await getVnf(request, uuid)
      await vnfs.deleteByUUID(request.state.rid, uuid)
      return vnf


