import logging
from dataclasses import dataclass
from typing import List, Optional, Set

import config
import inject
import log_utils
from fastapi import FastAPI, Request
from interfaces.node_interface import ICpes
from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.vnf_interface import IVnfs
from interfaces.vnf_template_interface import IVnfTemplates
from cpes import Cpes
from platforms import Platforms
from sites import Sites
from vnf_templates import VnfTemplates
from vnfs import Vnfs

log = logging.getLogger("REST_LK")
log.setLevel(config.getLogLevel("rest_lk"))


@dataclass(frozen=True)
class LKAbstractSite:
   siteName:str
   siteAddress:str
   siteLongitude:float
   siteLatitude:float


@dataclass(frozen=True)
class LKAddSite(LKAbstractSite):
   siteDescription:Optional[str] = None
   siteEasGuid:Optional[str] = None
   siteQcGeo:Optional[int] = None


@dataclass(frozen=True)
class LKUpdateSite(LKAbstractSite):
   siteId:str
   siteDescription:Optional[str] = None
   siteEasGuid:Optional[str] = None
   siteQcGeo:Optional[int] = None


@dataclass(frozen=True)
class Site(LKAbstractSite):
   siteId: str
   siteDescription:Optional[str] = None
   siteEasGuid:Optional[str] = None
   siteQcGeo:Optional[int] = None



@dataclass(frozen=True)
class SiteDetailed:
    siteId: str
    siteName: str
    siteAddress: str
    siteLongitude: float
    siteLatitude: float

    @dataclass(frozen=True)
    class Port:
        lanPort: int
        portType: Optional[Platforms.Platform.Interface.Type] = None
        vnfName: Optional[str] = None
        vnfId: Optional[str] = None
    ports: List[Port]

    siteDescription: Optional[str] = None
    siteEasGuid:Optional[str] = None
    siteQcGeo:Optional[int] = None


@inject.autoparams()
async def addSiteRoutes(app:FastAPI,
                        sites:ISites,
                        vnfs:IVnfs,
                        vnf_templates:IVnfTemplates,
                        cpes:ICpes,
                        platforms:IPlatforms):
   @app.get("/api/lk/v1.0/sites")
   async def listSites(request: Request) -> List[Site]:
      return [Site(siteName=site.name,
                   siteId=site.uuid,
                   siteDescription=site.description,
                   siteAddress=site.address,
                   siteEasGuid=site.easguid,
                   siteLatitude=site.latitude,
                   siteLongitude=site.longitude,
                   siteQcGeo=site.qcgeo) for site in await sites.getAllList(request.state.rid)]

   @app.get("/api/lk/v1.0/site/{uuid}")
   async def getSite(request: Request, uuid: str) -> SiteDetailed:
      site: Sites.Site = await sites.getByUUID(request.state.rid, uuid)
      listVnfsForDomain: List[Vnfs.Vnf] = list(
         filter(lambda vnf: vnf.domain == site.name, await vnfs.getAllList(request.state.rid)))

      log.debug(f"[{request.state.rid}] VNFs for domain:\n" + vnfs.printList(listVnfsForDomain))

      ports: List[SiteDetailed.Port] = []

      setBusyPorts = set([])

      if len(listVnfsForDomain) > 0:

         platform:Platforms.Platform = None

         for vnf in listVnfsForDomain:
            try:
               template: VnfTemplates.VnfTemplate = await vnf_templates.getByName(request.state.rid, vnf.template)
               if template.type == template.Type.l2Bridge:
                  log.debug(f"[{request.state.rid}] template type is L2Bridge.")
                  if vnf.node == None:
                     port = SiteDetailed.Port(
                        vnf.ports["lan"],
                        None,
                        vnf.name,
                        vnf.uuid
                     )
                     ports.append(port)
                  else:
                     cpe: Cpes.Cpe = await cpes.getByName(request.state.rid, vnf.node)

                     platform = await platforms.getByName(request.state.rid, cpe.platform)

                     log.debug(f'[{request.state.rid}] {vnf.ports["lan"]}')
                     log.debug(f'[{request.state.rid}] platform.lan={platform.lan}')
                     log.debug(f'[{request.state.rid}] {platform.lan[vnf.ports["lan"]]}')

                     setBusyPorts.add(vnf.ports["lan"])

                     portType = platform.lan[vnf.ports["lan"]].type

                     port = SiteDetailed.Port(
                         vnf.ports["lan"],
                         portType,
                         vnf.name,
                         vnf.uuid
                     )
                     ports.append(port)

            except Exception as e:
               log.error(f"[{request.state.rid}] {log_utils.print_exception(e)}")

      log.debug(f"busy={setBusyPorts}")

      listNodesForDomain: List[Cpes.Cpe] = list(filter(lambda node: node.domain == site.name, await cpes.getAllList(request.state.rid)))
      for cpe in listNodesForDomain:
         try:
            platform: Platforms.Platform = await platforms.getByName(request.state.rid, cpe.platform)
            for iPortNumber, port in platform.lan.items():
               if iPortNumber in setBusyPorts:
                  continue
               port = SiteDetailed.Port(
                  iPortNumber,
                  platform.lan[iPortNumber].type
               )
               ports.append(port)
         except Exception as e:
            log.error(f"[{request.state.rid}] {log_utils.print_exception(e)}")

      result = SiteDetailed(
         siteId=site.uuid,
         siteName=site.name,
         siteDescription=site.description,
         siteAddress=site.address,
         ports=ports,
         siteLongitude=site.longitude,
         siteLatitude=site.latitude,
         siteQcGeo=site.qcgeo,
         siteEasGuid=site.easguid
      )

      return result

   @app.delete("/api/lk/v1.0/site/{uuid}")
   async def deleteSite(request: Request, uuid: str):
      site = await getSite(request, uuid)
      await sites.deleteByUUID(request.state.rid, uuid)
      return site


   @app.post("/api/lk/v1.0/site")
   async def addSite(request: Request, lk:LKAddSite) -> SiteDetailed:
      site = await sites.add(RID=request.state.rid,
                             name=lk.siteName,
                             description=lk.siteDescription,
                             address=lk.siteAddress,
                             latitude=lk.siteLatitude,
                             longitude=lk.siteLongitude,
                             easguid=lk.siteEasGuid,
                             qcgeo=lk.siteQcGeo
                            )
      return await getSite(request, site.uuid)


   @app.put("/api/lk/v1.0/site/{uuid}")
   async def addSite(request: Request, lk:LKUpdateSite) -> SiteDetailed:
      site = await sites.update(RID=request.state.rid,
                                uuid=lk.siteId,
                                name=lk.siteName,
                                description=lk.siteDescription,
                                address=lk.siteAddress,
                                latitude=lk.siteLatitude,
                                longitude=lk.siteLongitude,
                                easguid=lk.siteEasGuid,
                                qcgeo=lk.siteQcGeo
                               )
      return await getSite(request, site.uuid)
