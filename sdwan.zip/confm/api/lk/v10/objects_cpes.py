from dataclasses import dataclass
from fastapi import FastAPI, Request
from typing import Dict, List, Optional
import uuid
import logging
import inject


from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs


from cpes import Cpes
from vnfs import Vnfs

import config


@dataclass(frozen=True)
class LKAbstractCpe:
   cpeName: str
   siteName: str
   hubName: str
   cpeState: Cpes.Cpe.State
   cpePlatform: str

   @dataclass(frozen=True)
   class Uplink:
      uplinkCode: str
      uplinkType: str
      uplinkStatus: Cpes.Cpe.Interface.Status
      connectionProperties: Dict
      uplinkSpeed: Optional[int] = None

      @dataclass(frozen=True)
      class QOS:
         priority: int
         min: float
         max: float
         className: str

      qos: Optional[List[QOS]] = None



@dataclass(frozen=True)
class LKUplinkAddAndModify:
   uplinkCode: str
   uplinkType: str
   connectionProperties: Dict

   uplinkSpeed: Optional[int] = None

   @dataclass(frozen=True)
   class QOS:
      priority: int
      min: float
      max: float
      className: Optional[str] = None
   qos: Optional[List[QOS]] = None




@dataclass(frozen=True)
class LKAddCpe(LKAbstractCpe):
   cpeSerial:str
   uplinks: List[LKUplinkAddAndModify]
   cpeDescription: Optional[str] = None


@dataclass(frozen=True)
class LKUpdateCpe(LKAbstractCpe):
   cpeId:str
   cpeSerial:str
   uplinks: List[LKUplinkAddAndModify]
   cpeDescription: Optional[str] = None



@dataclass(frozen=True)
class LKCpe(LKAbstractCpe):
    cpeId: str
    cpeNumber: int
    model: str
    cpeStatus: Cpes.Cpe.Status
    SiteId: str
    hubId: str
    ip: str
    uplinkCode: str
    uplinkStatus: str
    uplinkSpeed: int
    uptime: int
    cpeDescription: Optional[str] = None
    currwan: Optional[int] = None,
    uptime: Optional[int] = None


@dataclass(frozen=True)
class LKCpeOne(LKAbstractCpe):
   cpeId: str
   cpeNumber:int
   cpeSerial: str
   hubId: str
   hubName: str
   siteId: str
   siteName: str
   cpeStatus: Cpes.Cpe.Status
   currentUplink: str
   ip: str
   uplinks: List[LKAbstractCpe.Uplink]
   cpeDescription: Optional[str] = None
   uplinkCode:Optional[str] = None
   uplinkType:Optional[str] = None
   uplinkStatus:Cpes.Cpe.Interface.Status = None
   uplinkSpeed:Optional[int] = None
   currwan:Optional[int] = None
