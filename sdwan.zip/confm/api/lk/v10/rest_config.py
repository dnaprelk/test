import json
import logging
import time
from dataclasses import dataclass
from typing import Dict, List, Optional
import uuid
import asyncio
import os
import signal
from stat import ST_CTIME, ST_MTIME, ST_SIZE
from tabulate import tabulate
import shutil
import subprocess

import config
import inject
import log_utils
import date_utils

from terminate import terminate
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from interfaces.node_interface import ICpes
from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.vnf_interface import IVnfs
from interfaces.vnf_template_interface import IVnfTemplates
from interfaces.hub_interface import IHubs
from interfaces.service_interface import IServices
from interfaces.service_template_interface import IServiceTemplates
from vnfs import Vnfs

log = logging.getLogger("REST_LK")
log.setLevel(config.getLogLevel("rest_lk"))


@dataclass(frozen=True)
class ConfigFile:
   id:str
   saveTime:int
   name:str
   comment:Optional[str] = None
   applyTime:Optional[int] = None




@dataclass(frozen=True)
class SaveConfigResponse:
   id:str
   saveTime:int
   name:str


def makeFakeSnap() -> SaveConfigResponse:
   timeConfig = config.getConfigTime()
   return SaveConfigResponse(str(uuid.UUID(int=timeConfig)), int(timeConfig / 1000), "Сохранено")


# Create an event loop
#loop = asyncio.get_event_loop()

DIRECTORY = "../etc"
CONFIG_FILE = "config.yaml"
CONFIG_FILE_FULL_PATH = os.path.join(DIRECTORY, CONFIG_FILE)


async def reboot():
   await asyncio.sleep(2)
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)


@inject.autoparams()
async def addConfigRoutes(app:FastAPI,
                          sites:ISites,
                          vnfs:IVnfs,
                          vnf_templates:IVnfTemplates,
                          cpes:ICpes,
                          platforms:IPlatforms,
                          hubs:IHubs,
                          services:IServices,
                          service_templates:IServiceTemplates):

   @app.post("/api/lk/v1.0/config/saveConfig")
   async def save(request: Request) -> SaveConfigResponse:
      config.saveHubs(hubs.export())
      config.saveCPEs(cpes.export())
      config.saveVnfs(vnfs.export())
      config.saveSites(sites.export())
      config.saveServices(services.export())
      config.saveServiceTemplates(service_templates.export()),
      config.saveVnfTemplates(vnf_templates.export()),
      config.savePlatforms(platforms.export())

      config.saveToFile()

      return makeFakeSnap()


   @app.get("/api/lk/v1.0/config")
   async def save(request: Request):
      return makeFakeSnap()


   @app.post("/api/lk/v1.0/config/loadConfig")
   async def load(request: Request) -> SaveConfigResponse:
      loop.create_task(reboot())

      return makeFakeSnap()






   @app.get("/api/lk/v1.0/config/list")
   async def getConfigList(request: Request) -> List[ConfigFile]:
      listConfigs = []


      arrTable = []

      for file in os.listdir(DIRECTORY):
         if file.endswith('.yaml'):
            try:
               arrRow = []
               arrTable.append(arrRow)

               file_path = os.path.join(DIRECTORY, file)
               arrRow.append(file_path)

               file_stats = os.stat(file_path)
               arrRow.append(file_stats[ST_SIZE])

               timeCreation = file_stats[ST_CTIME]
               arrRow.append(log_utils.print_date(date_utils.python2ms(timeCreation)))

               sComment = None
               file_path_comment = os.path.join(DIRECTORY, file + ".comment")
               arrRow.append(file_path_comment)
               if os.path.exists(file_path_comment):
                  with open(file_path_comment, 'r') as file_comment:
                     sComment = file_comment.read()

               if file != CONFIG_FILE and file != "system.yaml":
                  configFile = ConfigFile(id=str(uuid.UUID(int=timeCreation)),
                                          saveTime=timeCreation,
                                          name=file[:-5],
                                          comment=sComment,
                                          applyTime=None)

                  listConfigs.append(configFile)
            except Exception as e:
               log.error(e)

      log.info(tabulate(arrTable, headers=["Name", "ID", "Description", "Key", "Longitude", "Latitude", "Port", "State", "IP", "Pubkey", "Status", "UUID", "src"], tablefmt="grid"))


      return listConfigs



   @dataclass(frozen=True)
   class NewConfig:
      name:str
      config:str
      comment:Optional[str] = None

   @app.post("/api/lk/v1.0/config/new")
   async def newConfig(request: Request, new_config:NewConfig) -> ConfigFile:

      if new_config.comment is not None:
         with open(os.path.join(DIRECTORY, new_config.name) + ".yaml.comment", 'w') as file_comment:
            file_comment.write(new_config.comment)


      file_path = os.path.join(DIRECTORY, new_config.name) + ".yaml"
      with open(file_path, 'w') as file_config:
         file_config.write(new_config.config)


      file_stats = os.stat(file_path)

      configFile = ConfigFile(id=str(uuid.UUID(int=file_stats[ST_CTIME])),
                        saveTime=file_stats[ST_CTIME],
                        name=new_config.name,
                        comment=new_config.comment,
                        applyTime=None)
      return configFile



   @dataclass(frozen=True)
   class SaveConfig:
      name:str
      comment:Optional[str] = None

   @app.post("/api/lk/v1.0/config/save")
   async def saveConfig(request: Request, save_config:SaveConfig) -> ConfigFile:

      if save_config.comment is not None:
         with open(os.path.join(DIRECTORY, save_config.name) + ".yaml.comment", 'w') as file_comment:
            file_comment.write(save_config.comment)

      configFile = {
         "hubs"              : hubs.export(),
         "nodes"             : cpes.export(),
         "vnfs"              : vnfs.export(),
         "domains"           : sites.export(),
         "services"          : services.export(),
         "service_templates" : service_templates.export(),
         "vnf_templates"     : vnf_templates.export(),
         "platforms"         : platforms.export()
      }


      file_path = os.path.join(DIRECTORY, save_config.name) + ".yaml"
      config.saveToFile(file_path, configFile)


      file_stats = os.stat(file_path)

      configFile = ConfigFile(id=str(uuid.UUID(int=file_stats[ST_CTIME])),
                        saveTime=file_stats[ST_CTIME],
                        name=save_config.name,
                        comment=save_config.comment,
                        applyTime=None)
      return configFile


   @app.delete("/api/lk/v1.0/config/{uuid}")
   async def deleteConfig(request: Request, uuid:str) -> str:
      for config in await getConfigList(request):
         if config.id == uuid:
            subprocess.run(f"rm -f '{os.getcwd()}/{DIRECTORY}/{config.name}'.*", shell=True, check=True)
      return "ok"


   @app.get("/api/lk/v1.0/config/download/{uuid}")
   async def downloadConfig(request: Request, uuid:str) -> FileResponse:
      for config in await getConfigList(request):
         if config.id == uuid:
            return FileResponse(os.path.join(DIRECTORY, config.name) + ".yaml",
                                filename=config.name + ".yaml",
                                media_type="application/x-yaml")


   async def reboot():
      await asyncio.sleep(1)
      terminate()


   @app.post("/api/lk/v1.0/config/apply/{uuid}")
   async def applyConfig(request: Request, uuid:str) -> str:
      for config in await getConfigList(request):
         if config.id == uuid:
            file_path = os.path.join(DIRECTORY, config.name) + ".yaml"

            os.remove(CONFIG_FILE_FULL_PATH)
            shutil.copy2(file_path, CONFIG_FILE_FULL_PATH)

            asyncio.create_task(reboot())
      return "ok"
