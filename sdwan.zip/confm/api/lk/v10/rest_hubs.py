from dataclasses import dataclass
from typing import List, Optional

import inject
from fastapi import FastAPI, Request
from hubs import Hubs
from interfaces.hub_interface import IHubs


@dataclass(frozen=True)
class LKAbstractHub:
   hubName: str
   hubMachineId: str
   hubPort: int
   hubState: Hubs.Hub.State
   hubAddress: str
   hubLatitude: float
   hubLongitude: float


@dataclass(frozen=True)
class LKHub(LKAbstractHub):
   hubId: str
   hubNumber: int
   hubStatus: Hubs.Hub.Status
   hubIp: Optional[str] = None
   hubDescription: Optional[str] = None
   hubQcGeo: Optional[int] = None
   hubEasGuid: Optional[str] = None




def hubToLK(hub:Hubs.Hub) -> LKHub:
   return LKHub(hubId=hub.uuid,
                hubNumber=hub.id,
                hubName=hub.name,
                hubDescription=hub.description,
                hubMachineId=hub.key,
                hubIp=hub.ip,
                hubPort=hub.port,
                hubState=hub.state,
                hubStatus= Hubs.Hub.Status.ONLINE if hub.status == Hubs.Hub.Status.ONLINE else Hubs.Hub.Status.OFFLINE,
                hubAddress=hub.address,
                hubEasGuid=hub.easguid,
                hubLatitude=hub.latitude,
                hubLongitude=hub.longitude,
                hubQcGeo=hub.qcgeo)




@dataclass(frozen=True)
class LKNewHub(LKAbstractHub):
   hubIp: Optional[str] = None
   hubDescription: Optional[str] = None
   hubQcGeo: Optional[int] = None
   hubEasGuid: Optional[str] = None


@dataclass(frozen=True)
class LKUpdateHub(LKAbstractHub):
   hubId:str
   hubIp: Optional[str] = None
   hubDescription: Optional[str] = None
   hubQcGeo: Optional[int] = None
   hubEasGuid: Optional[str] = None


@inject.autoparams()
async def addHubRoutes(app:FastAPI, hubs:IHubs):


   @app.get("/api/lk/v1.0/hub/{uuid}")
   async def getHub(request: Request, uuid: str) -> LKHub:
      return hubToLK(await hubs.getByUUID(request.state.rid, uuid))



   @app.get("/api/lk/v1.0/hubs")
   async def listHubs(request: Request) -> List[LKHub]:
      # print(type(platforms.getAll()))
      # print(jsonpickle.encode(platforms.getAll()))
      # return JSONResponse(content=clean_nones(json.loads(jsonpickle.encode(hubs.getAll(), unpicklable=False))))
      return [hubToLK(item) for item in await hubs.getAllList(request.state.rid)]
      # return {key: hubToLK(value) for key, value in hubs.getAll().items()}




   @app.post("/api/lk/v1.0/hub")
   async def addHub(request:Request, lk:LKNewHub) -> LKHub:
      hub = await hubs.add(RID=request.state.rid,
                           name=lk.hubName,
                           id=0,
                           description=lk.hubDescription,
                           key=lk.hubMachineId,
                           port=lk.hubPort,
                           address=lk.hubAddress,
                           latitude=lk.hubLatitude,
                           longitude=lk.hubLongitude,
                           easguid=lk.hubEasGuid,
                           qcgeo=lk.hubQcGeo,
                           state=Hubs.Hub.State(lk.hubState)
                          )
      return hubToLK(hub)

   @app.put("/api/lk/v1.0/hub/{uuid}")
   async def updateHub(request:Request, lk:LKUpdateHub) -> LKHub:
      hub = await hubs.update(RID=request.state.rid,
                              uuid=lk.hubId,
                              name=lk.hubName,
                              description=lk.hubDescription,
                              key=lk.hubMachineId,
                              port=lk.hubPort,
                              address=lk.hubAddress,
                              latitude=lk.hubLatitude,
                              longitude=lk.hubLongitude,
                              easguid=lk.hubEasGuid,
                              qcgeo=lk.hubQcGeo,
                              state=Hubs.Hub.State(lk.hubState)
                              )
      return hubToLK(hub)


   @app.delete("/api/lk/v1.0/hub/{uuid}")
   async def deleteHub(request: Request, uuid: str) -> LKHub:
      hub = await getHub(request, uuid)
      await hubs.deleteByUUID(request.state.rid, uuid)
      return hub
