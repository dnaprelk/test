import logging
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

import config
import inject
from fastapi import FastAPI, Request
from service_templates import ServiceTemplates


from interfaces.service_template_interface import IServiceTemplates


log = logging.getLogger("REST_LK")
log.setLevel(config.getLogLevel("rest_lk"))





@dataclass(frozen=True)
class LKServiceAbstract:
   name: str
   uuid: str

   class ServiceType(str, Enum):
      ANY_TO_ANY = 'a2a'
      POINT_TO_MANY = 'p2m'


@dataclass(frozen=True)
class LKServiceTemplateList(LKServiceAbstract):
   type: LKServiceAbstract.ServiceType
   description: Optional[str] = None


@dataclass(frozen=True)
class LKServiceTemplateOne(LKServiceAbstract):
   type: LKServiceAbstract.ServiceType
   port1: List[List[str]]
   port2: Optional[List[List[str]]] = None
   description: Optional[str] = None



@dataclass(frozen=True)
class LKAddServiceTemplate():
   name: str
   port1: List[List[str]]
   port2: Optional[List[List[str]]] = None
   description: Optional[str] = None



def convertType(service_template) -> LKServiceAbstract.ServiceType:
   if service_template.port2 is not None:
      return LKServiceAbstract.ServiceType.POINT_TO_MANY
   return LKServiceAbstract.ServiceType.ANY_TO_ANY



@inject.autoparams()
async def addServiceTemplateRoutes(app:FastAPI,
                                   service_templates:IServiceTemplates):


   @app.get("/api/lk/v1.0/servicetemplates")
   async def listServices(request: Request) -> List[LKServiceTemplateList]:
      return [LKServiceTemplateList(name=service_template.name,
                                    uuid=service_template.uuid,
                                    description=service_template.description,
                                    type=convertType(service_template)) for service_template in await service_templates.getAllList(request.state.rid)]



   @app.get("/api/lk/v1.0/servicetemplate/{uuid}")
   async def getServiceTemplate(request: Request, uuid: str) -> LKServiceTemplateOne:
      serviceTemplate:ServiceTemplates.ServiceTemplate = await service_templates.getByUUID(request.state.rid, uuid)

      return LKServiceTemplateOne(name=serviceTemplate.name,
                                  uuid=serviceTemplate.uuid,
                                  description=serviceTemplate.description,
                                  type=convertType(serviceTemplate),
                                  port1=serviceTemplate.port1,
                                  port2=serviceTemplate.port2)



   @app.post("/api/lk/v1.0/servicetemplate")
   async def addServiceTemplate(request: Request, lk:LKAddServiceTemplate) -> LKServiceTemplateOne:
      serviceTemplate = await service_templates.add(RID=request.state.rid,
                                                    name=lk.name,
                                                    description=lk.description,
                                                    port1=lk.port1,
                                                    port2=lk.port2)

      return await getServiceTemplate(request, serviceTemplate.uuid)



   @app.put("/api/lk/v1.0/servicetemplate/{uuid}")
   async def updateServiceTemplate(request: Request, lk:LKAddServiceTemplate) -> LKServiceTemplateOne:
      serviceTemplate = await service_templates.update(RID=request.state.rid,
                                                       name=lk.name,
                                                       description=lk.description,
                                                       port1=lk.port1,
                                                       port2=lk.port2
                                                      )
      return await getServiceTemplate(request, serviceTemplate.uuid)





   @app.delete("/api/lk/v1.0/servicetemplate/{uuid}")
   async def deleteService(request: Request, uuid: str):
      serviceTemplate = await getServiceTemplate(request, uuid)
      await service_templates.deleteByUUID(request.state.rid, uuid)
      return serviceTemplate


