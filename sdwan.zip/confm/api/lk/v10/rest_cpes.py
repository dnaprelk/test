from dataclasses import dataclass
from fastapi import FastAPI, Request
from typing import Dict, List, Optional
import uuid
import logging
import inject


from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs


from cpes import Cpes

from api.lk.v10.objects_cpes import *
from api.lk.v10.objects_vnfs import *

import config

log = logging.getLogger("REST_LK")
log.setLevel(config.getLogLevel("rest_lk"))





@inject.autoparams()
async def addNodeRoutes(app:FastAPI,
                        sites:ISites,
                        vnfs:IVnfs,
                        cpes:ICpes,
                        platforms:IPlatforms,
                        hubs:IHubs):




   async def cpeToLK(RID, cpe:Cpes.Cpe) -> LKCpe:
      site = await sites.getByName(RID, cpe.domain)
      hub  = await hubs.getByName(RID, cpe.hub)
      return LKCpe(cpeId=cpe.uuid,
                   cpeNumber=cpe.id,
                   cpeName=cpe.name,
                   cpeDescription=cpe.description,
                   cpePlatform=cpe.platform,
                   cpeState=cpe.state,
                   cpeStatus=Cpes.Cpe.Status.ONLINE if cpe.status == Cpes.Cpe.Status.ONLINE else Cpes.Cpe.Status.OFFLINE,
                   SiteId=site.uuid,
                   siteName=site.name,
                   hubId=hub.uuid,
                   hubName=hub.name,
                   ip=cpe.ip,
                   uplinkCode='WAN'+str(cpe.currwan) if cpe.currwan != None else None,
                   uplinkStatus=cpe.wan[cpe.currwan].status if cpe.currwan != None and cpe.currwan in cpe.wan else None,
                   uplinkSpeed=cpe.wan[cpe.currwan].speed if cpe.currwan != None and cpe.currwan in cpe.wan else None,
                   model=cpe.platform,
                   currwan=cpe.currwan,
                   uptime=int(cpe.online_at / 1000) if cpe.online_at != None else None)



   async def oneCpeToLK(RID, cpe:Cpes.Cpe) -> LKCpeOne:
      site = await sites.getByName(RID, cpe.domain)
      hub  = await hubs.getByName(RID, cpe.hub)
      uplinks = []

      platform = await platforms.getByName(RID, cpe.platform)

      for number,interface in cpe.wan.items():
         qoses = []

         if interface.qos:
            for qos in interface.qos:
                qoses.append(LKCpeOne.Uplink.QOS(qos.priority, qos.min, qos.max, qos.className))
         else:
            qoses = None

         uplinks.append(LKCpeOne.Uplink(uplinkCode=f"WAN{number}",
                                        uplinkType=platform.wan[number].type if number in platform.wan else None,
                                        uplinkStatus=interface.status,
                                        uplinkSpeed=interface.speed,
                                        connectionProperties=interface.connection,
                                        qos=qoses))

      uplinkCode   = None
      uplinkType   = None
      uplinkStatus = None
      uplinkSpeed  = None
      if cpe.currwan is not None and cpe.currwan in platform.wan:
         uplinkCode = 'WAN'+str(cpe.currwan)
         uplinkType = platform.wan[cpe.currwan].type
         uplinkStatus = cpe.wan[cpe.currwan].status
         uplinkSpeed = platform.wan[cpe.currwan].speed
      else:
         uplinkStatus = "fail"


      return LKCpeOne(cpeId=cpe.uuid,
                      cpeNumber=cpe.id,
                      cpeName=cpe.name,
                      cpeDescription=cpe.description,
                      hubId=hub.uuid,
                      hubName=hub.name,
                      siteId=site.uuid,
                      siteName=site.name,
                      cpeState=cpe.state,
                      cpeStatus=Cpes.Cpe.Status.ONLINE if cpe.status == Cpes.Cpe.Status.ONLINE else Cpes.Cpe.Status.OFFLINE,
                      cpeSerial=cpe.key,
                      currentUplink='WAN'+str(cpe.currwan) if cpe.currwan != None else None,
                      uplinkCode=uplinkCode,
                      uplinkType=uplinkType,
                      uplinkStatus=uplinkStatus,
                      uplinkSpeed=uplinkSpeed,
                      ip=cpe.ip,
                      cpePlatform=cpe.platform,
                      uplinks=uplinks,
                      currwan=cpe.currwan)



   @app.get("/api/lk/v1.0/cpes")
   async def listNodes(request: Request) -> List[LKCpe]:
      return [await cpeToLK(request.state.rid, node) for node in await cpes.getAllList(request.state.rid)]

   @app.get("/api/lk/v1.0/cpe/{uuid}")
   async def getCpe(request: Request, uuid: str) -> LKCpeOne:
      node = await cpes.getByUUID(request.state.rid, uuid)
      return await oneCpeToLK(request.state.rid, node)

   @app.delete("/api/lk/v1.0/cpe/{uuid}")
   async def deleteNode(request: Request, uuid: str):
      node = await getCpe(request, uuid)
      await cpes.deleteByUUID(request.state.rid, uuid)
      return node


   @app.post("/api/lk/v1.0/cpe")
   async def addCpe(request: Request, lk:LKAddCpe) -> LKCpeOne:

      wan = {}
      for uplink in lk.uplinks:
         iNumber = int(uplink.uplinkCode[3:])
         interface = Cpes.Cpe.Interface(connection=uplink.connectionProperties,
                                        speed=uplink.uplinkSpeed,
                                        qos=uplink.qos,
                                        status=Cpes.Cpe.Interface.Status.UP)
         wan[iNumber] = interface


      #log.info(wan)


      node = await cpes.add(RID=request.state.rid,
                            name=lk.cpeName,
                            id=0,
                            description=lk.cpeDescription,
                            sDomainName=lk.siteName,
                            state=lk.cpeState,
                            sPlatformName=lk.cpePlatform,
                            sHubName=lk.hubName,
                            key=lk.cpeSerial,
                            uplinks=wan
                            )
      return await getCpe(request, node.uuid)



   @app.put("/api/lk/v1.0/cpe/{uuid}")
   async def updateCpe(request: Request, lk:LKUpdateCpe) -> LKCpeOne:

      wan = {}
      for uplink in lk.uplinks:
         iNumber = int(uplink.uplinkCode[3:])
         interface = Cpes.Cpe.Interface(connection=uplink.connectionProperties,
                                        speed=uplink.uplinkSpeed,
                                        qos=uplink.qos,
                                        status=Cpes.Cpe.Interface.Status.DOWN)
         wan[iNumber] = interface

      cpe = await cpes.update(RID=request.state.rid,
                              name=lk.cpeName,
                              uuid=lk.cpeId,
                              description=lk.cpeDescription,
                              sDomainName=lk.siteName,
                              state=Vnf.State(lk.cpeState),
                              sPlatformName=lk.cpePlatform,
                              sHubName=lk.hubName,
                              key=lk.cpeSerial,
                              uplinks=wan
                             )
      return await getCpe(request, cpe.uuid)



