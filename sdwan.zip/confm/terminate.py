import os
import signal

def terminate():
   sig = getattr(signal, "SIGKILL", signal.SIGTERM)
   os.kill(os.getpid(), sig)