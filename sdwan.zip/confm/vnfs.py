import sys
from dataclasses import dataclass, replace
from typing import Dict, List, Optional
import logging
from tabulate import tabulate
from from_dict import from_dict
import traceback
import uuid
import inject
import dataclasses
#from injector import inject


import config
import log_utils
from abstract import Abstract
import exceptions
import dict_utils

from interfaces.site_interface import ISites
from interfaces.service_interface import IServices
from interfaces.vnf_template_interface import IVnfTemplates

from config_objects.config_vnf import ConfigVnf, Vnf



from mqtt import MQTT_Dispatcher
from rabbit import RabbitEvents


log = logging.getLogger("VNF")
log.setLevel(config.getLogLevel("vnfs"))


class Vnfs(Abstract):


   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, Vnf] = {}
      self.dictUUID:Dict[str, Vnf] = {}
      self.dictID:  Dict[int, Vnf] = {}



   # def addVNF(self, vnf:Vnf):
   #    if vnf.name in self.dictName:
   #       raise exceptions.DuplicateNameException("Vnfs", vnf.name)
   #    if vnf.uuid in self.dictUUID:
   #       raise exceptions.DuplicateUuidException("Vnfs", vnf.uuid)
   #    if vnf.id in self.dictID:
   #       raise exceptions.DuplicateIdException("Vnfs", vnf.id)
   #
   #    self.updateVNF(vnf)
   #
   # def updateVNF(self, vnf:Vnf):
   #    self.dictName[vnf.name] = vnf
   #    self.dictUUID[vnf.uuid] = vnf
   #    self.dictID[vnf.id] = vnf



   @inject.autoparams()
   async def isLocked(self, RID:int, vnf:Vnf, services:IServices):
      log.info(f"[{RID}] isLocked() name='{vnf.name}'")

      if vnf.state == Vnf.State.ENABLED:
         raise exceptions.ObjectLockedException("Vnfs", "state", vnf.state)

      for service in await services.getAllList(RID):
         for endpoint in service.endpoints:
            if endpoint.vnf == vnf.name:
               raise exceptions.ObjectInUseException("Vnfs", "uuid", vnf.uuid, "Services", "uuid", service.uuid)





   @inject.autoparams()
   async def add(self,
                 RID:int,
                 name:str,
                 id:int,
                 description:str,
                 sDomainName:str,
                 sTemplateName:str,
                 state:Vnf.State,
                 config:Dict,
                 ports:Dict,
                 sites:ISites,
                 vnf_templates:IVnfTemplates,
                 mqtt:MQTT_Dispatcher,
                 rabbitEvents:RabbitEvents) -> Vnf:

      config = dict_utils.clean_nones(config)
      ports = dict_utils.clean_nones(ports)

      async with self.lock:
         #Let's check they are there
         site         = await sites.getByName(RID, sDomainName)
         vnf_template = await vnf_templates.getByName(RID, sTemplateName)


         if id == 0:
            id = self.getFreeId(id, 255)

         vnf = Vnf(name=name,
                   id=id,
                   uuid=str(uuid.uuid4()),
                   domain=sDomainName,
                   description=description,
                   template=sTemplateName,
                   config=config,
                   ports=ports,
                   state=state,
                   status=Vnf.Status.STOPPED)

         self.addDB(RID, vnf)

      await mqtt.addVnf(RID, vnf)
      await rabbitEvents.addVnf(RID, vnf)


      return vnf



   @inject.autoparams()
   async def update(self,
                    RID:int,
                    uuid:str,
                    name: str,
                    id: int,
                    description: str,
                    sDomainName: str,
                    sTemplateName: str,
                    state: Vnf.State,
                    config: Dict,
                    ports: Dict,
                    sites: ISites,
                    vnf_templates: IVnfTemplates,
                    mqtt: MQTT_Dispatcher,
                    rabbitEvents:RabbitEvents) -> Vnf:

      config = dict_utils.clean_nones(config)
      ports = dict_utils.clean_nones(ports)

      async with self.lock:
         current_vnf:Vnf = await self.getByUUID(RID, uuid)

         #Let's check they are there
         site         = await sites.getByName(RID, sDomainName)
         vnf_template = await vnf_templates.getByName(RID, sTemplateName)

         current_vnf:Vnf = await self.getByUUID(RID, uuid)

         vnf = Vnf(name=name,
                   id=current_vnf.id,
                   uuid=current_vnf.uuid,
                   domain=sDomainName,
                   description=description,
                   template=sTemplateName,
                   config=config,
                   ports=ports,
                   state=state,
                   status=current_vnf.status,
                   node=current_vnf.node)

         self.updateDB(RID, vnf)

      await mqtt.updateVnf(RID, vnf)
      await rabbitEvents.updateVnf(RID, vnf)

      return vnf



   @inject.autoparams()
   async def beforeDelete(self, RID:int, vnf:Vnf, mqtt:MQTT_Dispatcher, rabbitEvents:RabbitEvents):
      log.info(f"[{RID}] beforeDelete() name='{vnf.name}'")
      await mqtt.deleteVnf(RID, vnf)
      await rabbitEvents.deleteVnf(RID, vnf)




   def readFromFile(self):
      log.info("import()")

      dictVnfs = config.getVnfs()

      for sVnfName in dictVnfs.keys():
         dictVnfs[sVnfName]["name"] = sVnfName
         try:
            config_vnf = from_dict(ConfigVnf, dictVnfs[sVnfName])
            dictVnfConfig = dataclasses.asdict(config_vnf)
            vnf = from_dict(Vnf, dictVnfConfig)

            self.addDB(-1, vnf)

         except Exception as e:
            log.critical(f"\n{log_utils.print_tree(dictVnfs[sVnfName])}\n{str(e)}\n" + "\n".join(traceback.format_tb(e.__traceback__)))
            sys.exit(-1)

      log.info("\n" + self.printList(list(self.dictName.values())))




   def export(self):
      log.info("export()")

      dictConfig = {}
      for sVnfName in self.dictName.keys():
         vnf = dataclasses.asdict(self.dictName[sVnfName])
         configVnf = from_dict(ConfigVnf, vnf)
         dictConfig[sVnfName] = dataclasses.asdict(configVnf)
      return dictConfig


   def save(self, dict):
      config.saveVnfs(dict)





   def printOne(self, vnf:Vnf):
      tree = log_utils.Tree(f"VNF {vnf.name}")
      root = tree.getRoot()
      root.addNode(f"id={vnf.id}")
      root.addNode(f"uuid={vnf.uuid}")
      root.addNode(f"description={vnf.description}")
      root.addNode(f"state={vnf.state}")
      root.addNode(f"status={vnf.status}")
      root.addNode(f"node={vnf.node}")
      root.addNode(f"domain={vnf.domain}")
      root.addNode(f"template={vnf.template}")
      return tree.print()




   def printList(self, listPlatforms:List[Vnf]) -> str:
      logTable = []

      for vnf in listPlatforms:
         logTable.append([vnf.name,
                          f"id={vnf.id}\nuuid={vnf.uuid}",
                          vnf.description,
                          vnf.template,
                          vnf.status,
                          vnf.state,
                          vnf.domain,
                          vnf.node,
                          log_utils.print_tree(vnf.config),
                          log_utils.print_tree(vnf.ports)])

      return tabulate(logTable, headers=["Name",
                                         "ID/UUID",
                                         "Description",
                                         "Template",
                                         "Status",
                                         "State",
                                         "Domain",
                                         "Node",
                                         "Config",
                                         "Ports"], tablefmt="grid")



   @inject.autoparams()
   async def setState(self, rid:int, sVNFName:str, node:str, state:Vnf.State, status:Vnf.Status, rabbitEvents:RabbitEvents=None):
      log.info(f"[{rid}] setState() name='{sVNFName}' node='{node}' state='{state}' status='{status}'")

      vnf = await self.getByName(rid, sVNFName)
      updatedVnf = replace(vnf, node=node, state=state, status=status)

      self.updateDB(rid, updatedVnf)

      await rabbitEvents.updateVnf(rid, updatedVnf)


      log.info(f"[{rid}] ok, state updated.")