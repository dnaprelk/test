from dataclasses import dataclass, field
import dataclasses
import from_dict
from typing import Dict, List, Optional
import logging
from tabulate import tabulate

import config
import log_utils
from abstract import Abstract
from enum import Enum



log = logging.getLogger("VNF_TEMPLATES")
log.setLevel(config.getLogLevel("vnf_templates"))


class VnfTemplates(Abstract):

   @dataclass(frozen=True)
   class VnfTemplate:

      name:str

      @dataclass(frozen=True)
      class Type(str,Enum):
         dhcp = "dhcp"
         l2Bridge = "l2Bridge"
         firewall = "firewall"
         l3Router = "l3Router"
         port8_switch = "8 port switch"
         nat = "nat"
      type: Type

      config:Dict
      ports:Dict

      @dataclass(frozen=True)
      class Image:
         name:str
         size:int
         sha:str
      image:Image


   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, VnfTemplates.VnfTemplate] = {}





   def readFromFile(self):
      dictVnfTemplates = config.getVnfTemplates()

      for sVnfName in dictVnfTemplates.keys():
         dictVnfTemplates[sVnfName]["name"] = sVnfName
         hub = VnfTemplates.VnfTemplate(**dictVnfTemplates[sVnfName])

         self.dictName[sVnfName] = hub


      log.info("\n" + self.printList(list(self.dictName.values())))



   def export(self):
      log.info("export()")

      dictConfig = {}
      for sVnfTemplateName in self.dictName.keys():
         vnfTemplate = dataclasses.asdict(self.dictName[sVnfTemplateName])
         dictConfig[sVnfTemplateName] = vnfTemplate
      return dictConfig


   def save(self, dict):
      config.saveVnfTemplates(dict)



   def printOne(self, vnfTemplate:VnfTemplate):
      tree = log_utils.Tree(f"VNF TEMPLATE: '{vnfTemplate.name}'")
      root = tree.getRoot()
      root.addNode(f"type={vnfTemplate.type}")
      root.addNode(f"config={vnfTemplate.config}")
      root.addNode(f"ports={vnfTemplate.ports}")
      return tree.print()

   def printList(self, listVnfTemplates:List[VnfTemplate]) -> str:
      logTable = []

      for vnfTemplate in listVnfTemplates:
         logTable.append([vnfTemplate.name,
                          vnfTemplate.type,
                          log_utils.print_tree(vnfTemplate.config),
                          log_utils.print_tree(vnfTemplate.ports)])

      return tabulate(logTable, headers=["Name", "Type", "Config", "Ports"], tablefmt="grid")
