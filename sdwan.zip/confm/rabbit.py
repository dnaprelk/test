import json
from dataclasses import dataclass,asdict
import logging
import asyncio
import time
import ssl
from typing import Dict
from enum import Enum
from rabbit_utils import Rabbit


from config_objects.config_vnf import ConfigVnf
from api.lk.v10.objects_vnfs import oneVnfToLK

import config
import log_utils

log = logging.getLogger("RABBIT_EVENTS")
log.setLevel(config.getLogLevel("rabbit"))



counter:int = 0
counter_lock = asyncio.Lock()

async def increment() -> int:
   global counter
   async with counter_lock:
      counter += 1
      return counter



@dataclass(frozen=True)
class Event:
   number:int
   time: float

   class Type(str,Enum):
      NEW    = "new"
      UPDATE = "update"
      DELETE = "delete"
   type:Type

   object: Dict


class RabbitEvents:

   async def start(self):
      events = config.getEvents()

      if events is not None and events.rabbit is not None:
         if events.rabbit.ssl is not None:
            context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=events.rabbit.ssl.cafile)
            context.load_cert_chain(events.rabbit.ssl.client_certificate, events.rabbit.ssl.client_key)
            self.rabbit = Rabbit(events.rabbit.connection, context)
         else:
            self.rabbit = Rabbit(events.rabbit.connection)

         await self.rabbit.connect()
      else:
         self.rabbit = None


   async def send(self, type:Event.Type, object:Dict):
      event = Event(number=await increment(),
                    time=time.time(),
                    type=type,
                    object = object)

      #log.info(log_utils.print_object_tree(event))
      dictEvent = asdict(event)
      log.info(log_utils.print_tree(dictEvent))

      if self.rabbit is not None:
         await self.rabbit.send_message("test", json.dumps(dictEvent))





   async def addVnf(self, rid:int, vnf:ConfigVnf):
      if self.rabbit:
         log.info(f"[{rid}] addVnf() name={vnf.name}")
         await self.send(Event.Type.NEW, asdict(await oneVnfToLK(rid, vnf)))
   async def updateVnf(self, rid:int, vnf:ConfigVnf):
      if self.rabbit:
         log.info(f"[{rid}] updateVnf() name={vnf.name}")
         await self.send(Event.Type.UPDATE, asdict(await oneVnfToLK(rid, vnf)))
   async def deleteVnf(self, rid:int, vnf:ConfigVnf):
      if self.rabbit:
         log.info(f"[{rid}] deleteVnf() name={vnf.name}")
         await self.send(Event.Type.DELETE, asdict(await oneVnfToLK(rid, vnf)))


