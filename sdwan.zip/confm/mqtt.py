import asyncio
import uuid

from injector import inject
import logging
import dataclasses
import json
import inject
import os
from from_dict import from_dict
from dataclasses import dataclass
from typing import Dict, List, Set


from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs
from interfaces.service_interface import IServices
from interfaces.vnf_template_interface import IVnfTemplates
from interfaces.node_interface import ICpes
from interfaces.vnf_interface import IVnfs
from interfaces.service_template_interface import IServiceTemplates

from platforms import Platforms
#from hubs import Hubs
#from sites import Sites
#from cpes import Cpes
#from vnf_templates import VnfTemplates
#from vnfs import Vnfs
#from services import Services
#from service_templates import ServiceTemplates

from config_objects.config_vnf import ConfigVnf
from config_objects.config_hub import ConfigHub
from config_objects.config_cpe import ConfigCpe
from config_objects.config_service import ConfigService
from config_objects.config_service_template import ConfigServiceTemplate


import config
from mqtt_utils import MQTT
import request_counter
import log_utils
import date_utils
import dict_utils


loop = asyncio.get_event_loop()


log = logging.getLogger("MQTT_DISPATCHER")
log.setLevel(config.getLogLevel("mqtt"))


SERVICE_ID_NODE_MANAGER = "node_manager"
SERVICE_ID_VNF_MANAGER = "vnf_manager"
SERVICE_ID_COMMAND_LINE_INTERFACE = "cli"
SERVICE_ID_CONFIGURATION_MANAGER = "conf_manager"


class MQTT_Dispatcher:

   @dataclass()
   class Event:
      uuid: str
      time: int
      time_human: str
      topic: str
      body: dict


      @dataclass(frozen=True)
      class Acknowldge:
         service:str
         time:int
         time_human:str

         def __hash__(self):
            return hash(self.service)
      ack:Set[Acknowldge]



      @dataclass(frozen=True)
      class Error:
         service:str
         time:int
         time_human:str
         description:str

         def __hash__(self):
            return hash(self.service)
      errors:Set[Error]





      pending:Set[str]

   def __init__(self):
      self.lock = asyncio.Lock()
      self.dictEvents = {}
      self.listEvents = []



   # @inject.autoparams()
   # async def update(self, hubs: IHubs):
   #    while True:
   #       rid:int = await request_counter.increment()
   #       for hub in await self.hubs.getAllList(rid):
   #          try:
   #             result = {hub.name: dataclasses.asdict(hub)}
   #             #await self.mqtt.publish("confm/update/hub", result)
   #
   #             if hub.state == ConfigHub.State.DISABLED:
   #                await self.rebootHub(rid, hub.name)
   #
   #
   #          except Exception as e:
   #             log.error(f"[{rid}] {log_utils.print_tree(e)}")
   #             result = {'confm': {'code': 1, 'msg': f"Hub {hub.name} add() failed: {e}"}}
   #       await asyncio.sleep(5)




   async def send(self, topic:str, body:dict):
      event = MQTT_Dispatcher.Event(str(uuid.uuid4()), date_utils.getTime(), topic, dict_utils.clean_nones(body))
      await self.sendEvent(event)

   async def sendEvent(self, event:Event):
      async with self.lock:
         self.dictEvents[event.uuid] = event
         self.listEvents.append(event)
      await self.mqtt.publish(event.topic, {"uuid":event.uuid, "message":event.body})





   async def confirm(self, uuid:str, service:str):
      log.debug(f"confirm() uuid='{uuid}' service='{service}'")
      async with self.lock:
         if uuid in self.dictEvents:
            event = self.dictEvents[uuid]

            if event is not None:
               for obj in event.pending.copy():  # Use copy to avoid modifying the set while iterating
                  if obj == service:
                     event.pending.remove(obj)

               event.ack.add(MQTT_Dispatcher.Event.Acknowldge(service=service,
                                                              time=date_utils.getTime(),
                                                              time_human=log_utils.print_date(date_utils.getTime())))

               if len(event.pending) == 0:
                  del self.dictEvents[uuid]
                  self.listEvents = list(filter(lambda event: event.uuid != uuid, self.listEvents))



   async def sendConfirmation(self, uuid:str):
      await self.mqtt.publish('confirmations', {"uuid": uuid, "service": SERVICE_ID_CONFIGURATION_MANAGER})



   async def error(self, uuid:str, service:str, error:str):
      log.info(f"error() uuid='{uuid}' service='{service}'")

      async with self.lock:
         event = self.dictEvents[uuid]

         if event is not None:
            event.errors.add(MQTT_Dispatcher.Event.Error(service=service,
                                                         time=date_utils.getTime(),
                                                         time_human=log_utils.print_date(date_utils.getTime()),
                                                         description=error))




   async def sendMonitor(self):
      log.info("Confirmation monitor started.")
      async with self.lock:
         for event in self.listEvents:
            if event.time + 30000 < date_utils.getTime():
               log.critical(f"We have a dead event:\n{log_utils.print_object_tree(event)}")
               self.dictEvents.clear()
               self.listEvents.clear()
               await self.mqtt.publish("admin/reset/system", {})

         await asyncio.sleep(2)




   async def getOutgoingEvents(self) -> List[Event]:
      async with self.lock:
         return self.listEvents


   @inject.autoparams()
   async def start(self,
                   platforms: IPlatforms,
                   hubs: IHubs,
                   nodes: ICpes,
                   domains: ISites,
                   vnf_templates: IVnfTemplates,
                   vnfs: IVnfs,
                   services: IServices,
                   service_templates: IServiceTemplates):
      self.platforms = platforms
      self.hubs = hubs
      self.cpes = nodes
      self.domains = domains
      self.vnf_templates = vnf_templates
      self.vnfs = vnfs
      self.services = services
      self.service_templates = service_templates


      self.mqtt = MQTT("CONF")
      await self.mqtt.connect(os.environ.get("MQTT_SERVER"))
      await self.mqtt.subscribe(["cli/#",
                                 "gui/#",
                                 "api/#",
                                 "nodem/#",
                                 "ctl/#",
                                 "vnfm/#",
                                 "confirmations",
                                 "errors"])

      #Let's make global RESET
      await self.resetSystem(-1)


      loop.create_task(self.sendMonitor(), name="MQTT MONITOR")


      while True:
         try:
            message = await self.mqtt.get()

            rid:int = await request_counter.increment()

            arrTopics = message.topic.split("/")


            if arrTopics[0] == "confirmations":
               await self.confirm(message.body["uuid"], message.body["service"])

            elif arrTopics[0] == "errors":
               await self.error(message.body["uuid"], message.body["service"], message.body["error"])


            elif arrTopics[0] == 'cli' or arrTopics[0] == 'gui' or arrTopics[0] == 'api':
               # if set(('cookie')).issubset(m[n]):
               #    if sessions.check(m[n]['cookie']) != True:
               #       result = {'confm': {'code': 1, 'msg': 'Cookie ' + m[n]['cookie'] + ' not authorized'}}
               #       client.publish('confm/result', json.dumps(result), 0)
               #       return

               if arrTopics[1] == 'add':
                  if arrTopics[2] == 'hub':
                     for sVnfName in message.body.keys():
                        dictAdd = message.body[sVnfName]

                        try:
                           hub = await self.hubs.add(rid,
                                                     name=sVnfName,
                                                     id=dictAdd["id"],
                                                     description=dictAdd["description"],
                                                     address=dictAdd["address"],
                                                     key=dictAdd["key"],
                                                     longitude=dictAdd["longitude"],
                                                     latitude=dictAdd["latitude"],
                                                     port=dictAdd["port"],
                                                     state=ConfigHub.State(dictAdd["state"]))
                           result = {sVnfName: dataclasses.asdict(hub)}
                           result[sVnfName].update({'src': 'confm'})
                           await self.mqtt.publish("confm/new/hub", result)
                           #result = {'confm': {'code': 0, 'msg': f"Hub {sHubName} added."}}
                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_exception(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Hub {sHubName} add() failed: {e}"}}


                  elif arrTopics[2] == 'domain':
                     for sDomainName in message.body.keys():
                        dictAdd = message.body[sDomainName]

                        try:
                           domain = await self.domains.add(rid,
                                                           name=sDomainName,
                                                           description=dictAdd["description"],
                                                           address=dictAdd["address"],
                                                           longitude=dictAdd["longitude"],
                                                           latitude=dictAdd["latitude"])
                           result = {sDomainName: dataclasses.asdict(domain)}
                           result[sDomainName].update({'src': 'confm'})
                           await self.mqtt.publish("confm/new/domain", result)
                           #result = {'confm': {'code': 0, 'msg': f"Domain {sDomainName} added"}}

                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_exception(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Hub {sDomainName} add() failed: {e}"}}


                  elif arrTopics[2] == 'node':
                     for sNodeName in message.body.keys():
                        dictAdd = message.body[sNodeName]

                        try:
                           node = await self.cpes.add(rid,
                                                      name=sNodeName,
                                                      id=dictAdd["id"],
                                                      sDomainName=dictAdd["domain"],
                                                      description=dictAdd["description"],
                                                      key=dictAdd["key"],
                                                      sPlatformName=dictAdd["platform"],
                                                      sHubName=dictAdd["hub"],
                                                      state=ConfigCpe.State(dictAdd["state"]))
                           result = {sNodeName: dataclasses.asdict(node)}
                           result[sNodeName].update({'src': 'confm'})
                           await self.mqtt.publish("confm/new/node", result)
                           #result = {'confm': {'code': 0, 'msg': f"Node {sNodeName} added."}}
                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_tree(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Hub {sNodeName} add() failed: {e}"}}

                  elif arrTopics[2] == 'vnf':
                     for sVnfName in message.body.keys():
                        dictAdd = message.body[sVnfName]

                        try:
                           vnf = await self.vnfs.add(rid,
                                                     name=sVnfName,
                                                     id=dictAdd["id"],
                                                     description=dictAdd["description"],
                                                     sDomainName=dictAdd["domain"],
                                                     sTemplateName=dictAdd["template"],
                                                     state=ConfigVnf.State(dictAdd["state"]),
                                                     config=dictAdd["config"],
                                                     ports=dictAdd["startup"])
                           result = {sVnfName: dataclasses.asdict(vnf)}
                           result[sVnfName].update({'src': 'confm'})
                           await self.mqtt.publish("confm/new/vnf", result)
                           #result = {'confm': {'code': 0, 'msg': f"VNF {sHubName} added"}}

                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_exception(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Vnf {sHubName} add() failed: {e}"}}

                  else:
                     pass
                     #result = {'confm': {'code': 1, 'msg': f"Unknown object {arrTopics[2]} to add."}}

                  #await self.mqtt.publish("confm/result", result)



            elif arrTopics[0] == "nodem":
               uuid = message.body["uuid"]
               dictData = message.body["message"]



               if arrTopics[1] == "update":
                  if arrTopics[2] == "hub":
                     for sVnfName in dictData.keys():
                        dictUpdate = dictData[sVnfName]

                        try:
                           status = ConfigHub.Status(dictUpdate["status"])
                           state  = ConfigHub.State(dictUpdate["state"])

                           #if state == Hubs.Hub.State.DISABLED:
                           #   await self.rebootHub(rid, sHubName)

                           if status == ConfigHub.Status.OFFLINE:
                              await self.hubs.registerHub(rid,
                                                          sVnfName,
                                                          ip=None,
                                                          pubkey=None,
                                                          status=ConfigHub.Status.OFFLINE,
                                                          #state=Hubs.Hub.State(dictUpdate["state"])
                                                         )
                           else:
                              await self.hubs.registerHub(rid,
                                                          sVnfName,
                                                          ip=dictUpdate["ip"],
                                                          pubkey=dictUpdate["pubkey"],
                                                          status=ConfigHub.Status(dictUpdate["status"]),
                                                          #state=Hubs.Hub.State(dictUpdate["state"])
                                                         )

                           #result = {sHubName: dataclasses.asdict(await self.hubs.getByName(rid, sHubName))}
                           #result[sHubName].update({'src': 'confm'})
                           #await self.mqtt.publish("confm/update/hub", result)
                           #await self.send("confm/update/hub", {sHubName: dataclasses.asdict(await self.hubs.getByName(rid, sHubName))})
                           #result = {'confm': {'code': 0, 'msg': f'Hub {sHubName} updated'}}
                           await self.updateHub(rid, await self.hubs.getByName(rid, sVnfName))

                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_exception(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Hub {sHubName} update failed"}}


                  elif arrTopics[2] == "node":
                     for sNodeName in dictData.keys():
                        dictUpdate = dictData[sNodeName]

                        try:
                           dictWan = {}
                           for strwanNumber,wanInterface in dictUpdate["wan"].items():
                              interface = from_dict(ConfigCpe.Interface, wanInterface)
                              dictWan[int(strwanNumber)] = interface

                           await self.cpes.registerNode(rid,
                                                        sNodeName,
                                                        ip=dictUpdate["ip"] if "ip" in dictUpdate else None,
                                                        pubkey=dictUpdate["pubkey"] if "pubkey" in dictUpdate else None,
                                                        status=ConfigCpe.Status(dictUpdate["status"]),
                                                        state=ConfigCpe.State(dictUpdate["state"]),
                                                        sPlatformName=dictUpdate["platform"],
                                                        wan=dictWan,
                                                        currwan=dictUpdate["currwan"] if "currwan" in dictUpdate else None)

                           #dictFix = dataclasses.asdict(await self.cpes.getByName(rid, sNodeName))
                           #dictFix["pubkey"] = currentCPE.pubkey
                           #dictFix["ip"] = currentCPE.ip

                           #result = {sNodeName: dataclasses.asdict(await self.cpes.getByName(rid, sNodeName))}
                           #result[sNodeName].update({'src': 'confm'})
                           #await self.mqtt.publish("confm/update/node", result)
                           #await self.send("confm/update/node", {sNodeName: dataclasses.asdict(await self.cpes.getByName(rid, sNodeName))})
                           #result = {'confm': {'code': 0, 'msg': f'Node {sNodeName} updated'}}
                           await self.updateCpe(rid, await self.cpes.getByName(rid, sNodeName))

                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_exception(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Node {sNodeName} update failed"}}
                  else:
                     result = {'confm': {'code': 1, 'msg': 'Unknown object ' + arrTopics[2] + ' to update from Node Manager'}}

                  #await self.mqtt.publish('confm/result', result)
               await self.sendConfirmation(uuid)


            elif arrTopics[0] == "vnfm":
               uuid = message.body["uuid"]
               dictData = message.body["message"]

               if arrTopics[1] == "update":
                  if arrTopics[2] == "vnf":
                     for sVnfName in dictData.keys():
                        dictUpdate = dictData[sVnfName]

                        try:
                           await self.vnfs.setState(rid,
                                                    sVnfName,
                                                    node=dictUpdate["node"] if "node" in dictUpdate else None,
                                                    status=ConfigVnf.Status(dictUpdate["status"]),
                                                    state=ConfigVnf.State(dictUpdate["state"]))

                           #result = {sHubName: dataclasses.asdict(await self.vnfs.getByName(rid, sHubName))}
                           #result[sHubName].update({'src': 'confm'})
                           #await self.mqtt.publish("confm/update/vnf", result)
                           #result = {'confm': {'code': 0, 'msg': f'Vnf {sHubName} updated'}}
                           await self.updateVnf(rid, await self.vnfs.getByName(rid, sVnfName))

                        except Exception as e:
                           log.error(f"[{rid}] {log_utils.print_exception(e)}")
                           #result = {'confm': {'code': 1, 'msg': f"Vnf {sHubName} update failed"}}
               await self.sendConfirmation(uuid)

         except Exception as e:
            log.error(f"{log_utils.print_exception(e)}")

   # result = {'confm': {'code': 1, 'msg': f"Vnf {sHubName} update failed"}}

   async def transactionNodeVnfCli(self, rid, topic:str, body:dict):
      log.info(f"[{rid}]transaction() node,vnf,cli")
      await self.transaction(rid, topic, body, {SERVICE_ID_NODE_MANAGER, SERVICE_ID_VNF_MANAGER})

   async def transactionNodeCli(self, rid, topic:str, body:dict):
      log.info(f"[{rid}]transaction() node,cli")
      await self.transaction(rid, topic, body, {SERVICE_ID_NODE_MANAGER})

   async def transactionVnfCli(self, rid, topic:str, body:dict):
      log.info(f"[{rid}]transaction() node,cli")
      await self.transaction(rid, topic, body, {SERVICE_ID_VNF_MANAGER})


   async def transaction(self, rid:int, topic:str, body:dict, services:set[str]):
      event = MQTT_Dispatcher.Event("conf:" + str(rid),
                                    time=date_utils.getTime(),
                                    time_human=log_utils.print_date(date_utils.getTime()),
                                    topic=topic,
                                    body=dict_utils.clean_nones(body),
                                    ack=set(),
                                    errors=set(),
                                    pending=services)
      #log.info(f"[{rid}]transaction() {log_utils.print_tree(dataclasses.asdict(event))}")

      await self.sendEvent(event)




   async def resetSystem(self, rid:int):
      log.info(f"[{rid}] reset()")
      await self.mqtt.publish("admin/reset/system", {})


   async def resetHub(self, rid:int, hubName:str):
      log.info(f"[{rid}] resetHub() name={hubName}")
      await self.mqtt.publish("admin/reset/hub", {"name": hubName})
   async def rebootHub(self, rid:int, hubName:str):
      log.info(f"[{rid}] rebootHub() name={hubName}")
      await self.mqtt.publish("admin/reboot/hub", {"name": hubName})


   async def resetCPE(self, rid:int, cpeName:str):
      log.info(f"[{rid}] resetCPE() name={cpeName}")
      await self.mqtt.publish("admin/reset/cpe", {"name": cpeName})
   async def rebootCpe(self, rid:int, cpeName:str):
      log.info(f"[{rid}] rebootCPE() name={cpeName}")
      await self.mqtt.publish("admin/reboot/cpe", {"name": cpeName})


   async def addHub(self, rid:int, hub:ConfigHub):
      log.info(f"[{rid}] addHub() name={hub.name}")
      await self.transactionNodeCli(rid, "confm/new/hub", {hub.name: dataclasses.asdict(hub)})
   async def updateHub(self, rid:int, hub:ConfigHub):
      log.info(f"[{rid}] updateHub() name={hub.name}")
      if hub.state == ConfigHub.State.DISABLED:
         await self.rebootHub(rid, hub.name)
      await self.transactionNodeCli(rid, "confm/update/hub", {hub.name: dataclasses.asdict(hub)})
   async def deleteHub(self, rid:int, hub:ConfigHub):
      log.info(f"[{rid}] deleteHub() name={hub.name}")
      await self.rebootHub(rid, hub.name)
      await self.transactionNodeCli(rid, "confm/delete/hub", {hub.name: dataclasses.asdict(hub)})




   async def addCpe(self, rid:int, cpe:ConfigCpe):
      log.info(f"[{rid}] addCpe() name={cpe.name}")
      await self.transactionNodeVnfCli(rid, "confm/new/node", {cpe.name: dataclasses.asdict(cpe)})
   async def updateCpe(self, rid:int, cpe:ConfigCpe):
      log.info(f"[{rid}] updateCpe() name={cpe.name}")
      if cpe.state == ConfigCpe.State.DISABLED:
         await self.rebootCpe(rid, cpe.name)
      await self.transactionNodeVnfCli(rid, "confm/update/node", {cpe.name: dataclasses.asdict(cpe)})
   async def deleteCpe(self, rid:int, cpe:ConfigCpe):
      log.info(f"[{rid}] deleteCpe() name={cpe.name}")
      await self.rebootCpe(rid, cpe.name)
      await self.transactionNodeVnfCli(rid, "confm/delete/node", {cpe.name: dataclasses.asdict(cpe)})



   async def addVnf(self, rid:int, vnf:ConfigVnf):
      log.info(f"[{rid}] addVnf() name={vnf.name}")
      await self.transactionVnfCli(rid, "confm/new/vnf", {vnf.name: dataclasses.asdict(vnf)})
   async def updateVnf(self, rid:int, vnf:ConfigVnf):
      log.info(f"[{rid}] updateVnf() name={vnf.name}")
      await self.transactionVnfCli(rid, "confm/update/vnf", {vnf.name: dataclasses.asdict(vnf)})
   async def deleteVnf(self, rid:int, vnf:ConfigVnf):
      log.info(f"[{rid}] deleteVnf() name={vnf.name}")
      await self.transactionVnfCli(rid, "confm/delete/vnf", {vnf.name: dataclasses.asdict(vnf)})



   async def addService(self, rid:int, service:ConfigService):
      log.info(f"[{rid}] addService() name={service.name}")
      await self.transactionVnfCli(rid, "confm/new/service", {service.name: dataclasses.asdict(service)})
   async def updateService(self, rid:int, service:ConfigService):
      log.info(f"[{rid}] updateService() name={service.name}")
      await self.transactionVnfCli(rid, "confm/update/service", {service.name: dataclasses.asdict(service)})
   async def deleteService(self, rid:int, service:ConfigService):
      log.info(f"[{rid}] deleteService() name={service.name}")
      await self.transactionVnfCli(rid, "confm/delete/service", {service.name: dataclasses.asdict(service)})




   async def addServiceTemplate(self, rid:int, service_template:ConfigServiceTemplate):
      log.info(f"[{rid}] addServiceTemplate() name={service_template.name}")
      await self.transactionVnfCli(rid, "confm/new/service_template", {service_template.name: dataclasses.asdict(service_template)})
   async def updateServiceTemplate(self, rid:int, service_template:ConfigServiceTemplate):
      log.info(f"[{rid}] updateServiceTemplate() name={service_template.name}")
      await self.transactionVnfCli(rid, "confm/update/service_template", {service_template.name: dataclasses.asdict(service_template)})
   async def deleteServiceTempate(self, rid:int, service_template:ConfigServiceTemplate):
      log.info(f"[{rid}] deleteServiceTemplate() name={service_template.name}")
      await self.transactionVnfCli(rid, "confm/delete/service_template", {service_template.name: dataclasses.asdict(service_template)})
