import logging
import sys
import time
import traceback
import uuid
from dataclasses import dataclass
import dataclasses
from enum import Enum
from typing import Dict, List, Optional
from from_dict import from_dict
import inject



import config
import exceptions
import log_utils
from abstract import Abstract
import dict_utils

from config_objects.config_cpe import ConfigCpe

from interfaces.vnf_interface import IVnfs
from interfaces.platform_interface import IPlatforms
from interfaces.site_interface import ISites
from interfaces.hub_interface import IHubs

from mqtt import MQTT_Dispatcher

log = logging.getLogger("CPES")
log.setLevel(config.getLogLevel("nodes"))


class Cpes(Abstract):

   @dataclass(frozen=True)
   class Cpe(ConfigCpe):
      status: Optional[ConfigCpe.Status] = ConfigCpe.Status.OFFLINE

      currwan: Optional[int] = None
      ip: Optional[str] = None
      pubkey: Optional[str] = None
      #uptime: Optional[int] = None
      online_at: Optional[int] = None


   def __init__(self):
      super().__init__()
      self.dictName:Dict[str, Cpes.Cpe] = {}
      self.dictUUID:Dict[str, Cpes.Cpe] = {}
      self.dictID:  Dict[int, Cpes.Cpe] = {}


   # def addCPE(self, cpe):
   #    if cpe.name in self.dictName:
   #       raise exceptions.DuplicateNameException("Cpes", cpe.name)
   #    if cpe.uuid in self.dictUUID:
   #       raise exceptions.DuplicateUuidException("Cpes", cpe.uuid)
   #    if cpe.id in self.dictID:
   #       raise exceptions.DuplicateIdException("Cpes", cpe.id)
   #
   #    self.updateCPE(cpe)
   #
   # def updateCPE(self, cpe):
   #    self.dictName[cpe.name] = cpe
   #    self.dictUUID[cpe.uuid] = cpe
   #    self.dictID[cpe.id] = cpe



   @inject.autoparams()
   async def isLocked(self, RID:int, cpe:Cpe, vnfs:IVnfs):
      log.info(f"[{RID}] isLocked() name='{cpe.name}'")

      for vnf in await vnfs.getAllList(RID):
         if vnf.node == cpe.name:
            raise exceptions.ObjectInUseException("Cpes", "uuid", cpe.uuid, "Vnfs", "uuid", vnf.uuid)


   @inject.autoparams()
   async def beforeDelete(self, RID:int, cpe:Cpe, mqtt:MQTT_Dispatcher):
      log.info(f"[{RID}] beforeDelete() name='{cpe.name}'")
      await mqtt.deleteCpe(RID, cpe)



   @inject.autoparams()
   async def add(self, RID:int,
                 name:str,
                 id:int,
                 sDomainName:str,
                 description:str,
                 key:str,
                 sPlatformName:str,
                 sHubName:str,
                 state:Cpe.State,
                 uplinks:Dict[int, Cpe.Interface],
                 sites:ISites,
                 platforms:IPlatforms,
                 hubs:IHubs,
                 mqtt:MQTT_Dispatcher) -> Cpe:
      log.info(f"[{RID}] add() name='{name}' id={id}")
      async with self.lock:
         #Let's check they are there
         site     = await sites.getByName(RID, sDomainName)
         platform = await platforms.getByName(RID, sPlatformName)
         hub      = await hubs.getByName(RID, sHubName)


         if id == 0:
            id = self.getFreeId(id, 253)

         uplinks_filterred = {}
         for number, uplink in uplinks.items():
            uplinks_filterred[number] = Cpes.Cpe.Interface(connection=dict_utils.clean_nones(uplink.connection),
                                                           speed=uplink.speed,
                                                           qos=uplink.qos,
                                                           status=Cpes.Cpe.Interface.Status.DOWN)

         cpe = Cpes.Cpe(name=name,
                        id=id,
                        uuid=str(uuid.uuid4()),
                        domain=sDomainName,
                        description=description,
                        key=key,
                        platform=sPlatformName,
                        hub=sHubName,
                        wan=uplinks_filterred,
                        state=state,
                        status=Cpes.Cpe.Status.OFFLINE)
         self.addDB(RID, cpe)

      await mqtt.addCpe(RID, cpe)

      return cpe



   @inject.autoparams()
   async def update(self, RID:int,
                 uuid:str,
                 name:str,
                 id:int,
                 sDomainName:str,
                 description:str,
                 key:str,
                 sPlatformName:str,
                 sHubName:str,
                 state:Cpe.State,
                 uplinks:Dict[int, Cpe.Interface],
                 sites:ISites,
                 platforms:IPlatforms,
                 hubs:IHubs,
                 mqtt:MQTT_Dispatcher) -> Cpe:
      log.info(f"[{RID}] update() name='{name}' id={id} uuid='{uuid}'")
      async with self.lock:

         current_cpe:Cpes.Cpe = await self.getByName(RID, name)

         #Let's check they are there
         site     = await sites.getByName(RID, sDomainName)
         platform = await platforms.getByName(RID, sPlatformName)
         hub      = await hubs.getByName(RID, sHubName)


         uplinks_filterred = {}
         for number, uplink in uplinks.items():
            uplinks_filterred[number] = Cpes.Cpe.Interface(connection=dict_utils.clean_nones(uplink.connection),
                                                           speed=uplink.speed,
                                                           qos=uplink.qos,
                                                           status=Cpes.Cpe.Interface.Status.DOWN)

         cpe = Cpes.Cpe(name=name,
                        id=id if (id is not None and id != 0) else current_cpe.id,
                        uuid=uuid,
                        domain=sDomainName,
                        description=description,
                        key=key,
                        platform=sPlatformName,
                        hub=sHubName,
                        wan=uplinks_filterred,
                        state=state,
                        status=current_cpe.status,
                        online_at=current_cpe.online_at)
         self.updateDB(RID, cpe)

      await mqtt.updateCpe(RID, cpe)

      return cpe




   def readFromFile(self):
      dictNodes = config.getNodes()


      for sCpeName in dictNodes.keys():
         dictNodes[sCpeName]["name"] = sCpeName
         try:
            config_cpe = from_dict(ConfigCpe, dictNodes[sCpeName])
            dictCpeConfig = dataclasses.asdict(config_cpe)
            for interfaceNumber, interface in dictCpeConfig["wan"].items():
               interface["status"] = Cpes.Cpe.Interface.Status.DOWN

            cpe = from_dict(Cpes.Cpe, dictCpeConfig)

            # platform = await platforms.getByName(-1, cpe.platform)
            #
            # if len(cpe.wan.values()) > len(platform.wan.values()):
            #    log.error(f"Config of {cpe.name} is DAMAGED."
            #              f"CPE has {len(cpe.wan.values())} WANs and "
            #              f"Platform has{len(platform.wan.values())}")
            # else:

            self.addDB(-1, cpe)
         except Exception as e:
            log.critical(f"\n{log_utils.print_tree(dictNodes[sCpeName])}\n{str(e)}\n" + "\n".join(traceback.format_tb(e.__traceback__)))

            sys.exit(-1)

      log.info(f"\n{self.printList(list(self.dictName.values()))}\n")


   def export(self) -> dict:
      dictConfig = {}
      for sCpeName in self.dictName.keys():
         dictCpe = dataclasses.asdict(self.dictName[sCpeName])
         for interfaceNumber, interface in dictCpe["wan"].items():
            del interface["status"]
         configCpe = from_dict(ConfigCpe, dictCpe)
         dictConfig[sCpeName] = dataclasses.asdict(configCpe)
      return dictConfig



   def save(self, dict):
      config.saveCPEs(dict)



   def printOne(self, cpe:Cpe):
      tree = log_utils.Tree("CPE")
      root = tree.getRoot()
      root.addNode(f"id={cpe.id}")
      root.addNode(f"uuid={cpe.uuid}")
      root.addNode(f"description={cpe.description}")
      root.addNode(f"domain={cpe.domain}")
      root.addNode(f"key={cpe.key}")
      root.addNode(f"hub={cpe.hub}")
      root.addNode(f"ip={cpe.ip}")
      root.addNode(f"pubkey={cpe.pubkey}")
      root.addNode(f"state={cpe.state}")
      root.addNode(f"status={cpe.status}")
      root.addNode(f"platform={cpe.platform}")
      root.addNode(f"currwan={cpe.currwan}")
      root.addNode(f"online_at={log_utils.print_date(cpe.online_at)}")
      nodeWANs = root.addNode("WAN")
      for sWanName, wan in cpe.wan.items():
         wan = cpe.wan[sWanName]
         nodeWAN = nodeWANs.addNode(str(sWanName))
         nodeWAN.addNode(f"speed={wan.speed}")
         nodeWAN.addNode(f"status={wan.status}")
         nodeWANConnection = nodeWAN.addNode("connection")
         nodeWANConnection.addNode(f"{wan.connection}")
         nodeWANQos = nodeWAN.addNode("qos")
         if wan.qos is not None:
            for qos in wan.qos:
               nodeWANQosPriority = nodeWANQos.addNode(f"priority={qos.priority}")
               nodeWANQosPriority.addNode(f"min={qos.min}")
               nodeWANQosPriority.addNode(f"max={qos.max}")
               nodeWANQosPriority.addNode(f"className={qos.className}")
         else:
            nodeWANQos.addNode("---")


      return tree.print()



   def printList(self, listCpes: List[Cpe]) -> str:
      tree = log_utils.Tree("CPEs")
      root = tree.getRoot()

      for cpe in listCpes:
         try:
            nodeNode = root.addNode(cpe.name)
            nodeNode.addNode(f"id={cpe.id}")
            nodeNode.addNode(f"uuid={cpe.uuid}")
            nodeNode.addNode(f"description={cpe.description}")
            nodeNode.addNode(f"domain={cpe.domain}")
            nodeNode.addNode(f"key={cpe.key}")
            nodeNode.addNode(f"hub={cpe.hub}")
            nodeNode.addNode(f"ip={cpe.ip}")
            nodeNode.addNode(f"pubkey={cpe.pubkey}")
            nodeNode.addNode(f"state={cpe.state}")
            nodeNode.addNode(f"status={cpe.status}")
            nodeNode.addNode(f"platform={cpe.platform}")
            nodeNode.addNode(f"currwan={cpe.currwan}")
            nodeNode.addNode(f"online_at={log_utils.print_date(cpe.online_at)}")
            nodeWANs = nodeNode.addNode("WAN")
            for sWanName, wan in cpe.wan.items():
               wan = cpe.wan[sWanName]
               nodeWAN = nodeWANs.addNode(str(sWanName))
               nodeWAN.addNode(f"speed={wan.speed}")
               nodeWAN.addNode(f"status={wan.status}")
               nodeWANConnection = nodeWAN.addNode("connection")
               nodeWANConnection.addNode(f"{wan.connection}")
               nodeWANQos = nodeWAN.addNode("qos")
               if wan.qos is not None:
                  for qos in wan.qos:
                     nodeWANQosPriority = nodeWANQos.addNode(f"priority={qos.priority}")
                     nodeWANQosPriority.addNode(f"min={qos.min}")
                     nodeWANQosPriority.addNode(f"max={qos.max}")
                     nodeWANQosPriority.addNode(f"className={qos.className}")
               else:
                  nodeWANQos.addNode("---")
         except Exception as e:
            log.error(e)
            log.error(cpe)

      return tree.print()




   @inject.autoparams()
   async def registerNode(self,
                          RID:int,
                          sNodeName:str,
                          ip:str,
                          pubkey:str,
                          state:Cpe.State,
                          status:Cpe.Status,
                          sPlatformName:str,
                          wan:Dict[int, Cpe.Interface],
                          platforms:IPlatforms,
                          currwan:int):
      log.info(f"[{RID}] registerNode() name='{sNodeName}' ip='{ip}' pubkey='{pubkey}' state='{state}' status='{status}', platform='{sPlatformName}'")

      current_cpe = await self.getByName(RID, sNodeName)

      #we check it exists
      platform = await platforms.getByName(RID, sPlatformName)

      online_at:int = None
      if status == Cpes.Cpe.Status.ONLINE:
         if current_cpe.status != Cpes.Cpe.Status.ONLINE:
            online_at = int(time.time() * 1000)
         else:
            online_at = current_cpe.online_at
      else:
         online_at = None


      updatedCpe = dataclasses.replace(current_cpe,
                                       ip=ip,
                                       pubkey=pubkey,
                                       state=state,
                                       status=status,
                                       platform=sPlatformName,
                                       wan=wan,
                                       currwan=currwan,
                                       online_at=online_at)
      self.updateDB(RID, updatedCpe)

      log.info(f"[{RID}] ok, registerred.")