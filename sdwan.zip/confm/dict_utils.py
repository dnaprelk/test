from math import isnan


def clean_nones(value):
   def checkNan(value):
      if isinstance(value, float) and isnan(value):
         return True if (isinstance(value, float) and isnan(value)) else False

   if isinstance(value, list):
      return [clean_nones(x) for x in value if (x is not None and x != 'NULL' and not checkNan(x))]
   elif isinstance(value, dict):
      return {
         key: clean_nones(val)
         for key, val in value.items()
         if (val is not None and val != 'NULL' and not checkNan(val))
      }
   else:
      return value
