import logging
from dataclasses import dataclass
# import jsonpickle
from typing import Dict, List

# from injector import inject
import inject
from fastapi import Request

import config
from interfaces.hub_interface import IHubs
from interfaces.keys import *
from interfaces.node_interface import ICpes
from interfaces.platform_interface import IPlatforms
from interfaces.service_interface import IServices
from interfaces.service_template_interface import IServiceTemplates
from interfaces.site_interface import ISites
from interfaces.vnf_interface import IVnfs
from interfaces.vnf_template_interface import IVnfTemplates
from platforms import Platforms

log = logging.getLogger("API LK")
log.setLevel(config.getLogLevel("api_lk"))






@dataclass(frozen=True)
class LKEndpoint:
   endpointId:str
   vnfId:str
   serviceId:str


class ApiLK_1_0:

   def __init__(self):
      pass





   @inject.autoparams()
   async def addRoutes(self,
                       app: FastAPI,
                       platforms: IPlatforms,
                       hubs: IHubs,
                       nodes: ICpes,
                       sites: ISites,
                       vnf_templates: IVnfTemplates,
                       vnfs: IVnfs,
                       services: IServices,
                       service_templates: IServiceTemplates):

      from api.lk.v10.rest_hubs import addHubRoutes
      await addHubRoutes()

      from api.lk.v10.rest_sites import addSiteRoutes
      await addSiteRoutes()

      from api.lk.v10.rest_vnfs import addVnfRoutes
      await addVnfRoutes()

      from api.lk.v10.rest_cpes import addNodeRoutes
      await addNodeRoutes()

      from api.lk.v10.rest_services import addServiceRoutes
      await addServiceRoutes()

      from api.lk.v10.rest_config import addConfigRoutes
      await addConfigRoutes()

      from api.lk.v10.rest_service_templates import addServiceTemplateRoutes
      await addServiceTemplateRoutes()





      @app.get("/api/lk/v1.0/endpoints")
      async def listEndpoints(request: Request) -> List[LKEndpoint]:
         arrEndpoints = []
         for service in await services.getAllList(request.state.rid):
            for endpoint in service.endpoints:
               vnf = await vnfs.getByName(request.state.rid, endpoint.vnf)
               lkEndpoint = LKEndpoint(endpointId=endpoint.uuid, vnfId=vnf.uuid, serviceId=service.uuid)
               arrEndpoints.append(lkEndpoint)

         return arrEndpoints




      @app.get("/api/lk/v1.0/models")
      async def listPlatforms(request: Request) -> Dict[str, Platforms.Platform]:
         return await platforms.getAllDict(request.state.rid)



#import uvicorn
#uvicorn.run(app, host="localhost", port=8000)