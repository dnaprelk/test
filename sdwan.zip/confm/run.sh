#!/bin/bash


### Find the script's path
SOURCE=${BASH_SOURCE[0]}
while [ -L "$SOURCE" ]; do DIR=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd ); SOURCE=$(readlink "$SOURCE"); [[ $SOURCE != /* ]] && SOURCE=$DIR/$SOURCE; done
DIR=$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )
###
cd "$DIR" || exit

source "../common/project_root.sh"
source "$PROJECT_ROOT/common/python_path.sh"
source "$PROJECT_ROOT/common/microservices/env.sh"

while :
do
   uvicorn confm:app --host 0.0.0.0 --port 8000
   sleep 1
done