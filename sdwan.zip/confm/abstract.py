import asyncio
from typing import TypeVar, Dict, List, Generic
import logging
from enum import Enum


import config
import exceptions
import log_utils

T = TypeVar('T')





class Abstract(Generic [T]):
   def __init__(self):
      self.class_type = type(self).__name__
      self.log = logging.getLogger(self.class_type.upper())
      self.log.setLevel(config.getLogLevel(self.class_type.lower()))

      self.lock = asyncio.Lock()

   async def getAllDict(self, RID:int) -> Dict[str, T]:
      self.log.info(f"[{RID}] getAll()")

      self.log.debug(f"[{RID}]\n" + self.printList(self.dictName.values()))

      return self.dictName

   async def getAllList(self, RID:int) -> List[T]:
      self.log.info(f"[{RID}] getAll()")

      #self.log.debug(f"[{RID}]\n" + self.printList(self.dictName.values()))

      return self.dictName.values()



   def getFreeId(self, RID:int, max:int):
      self.log.info(f"getFreeID()")
      listBusyIDes = []

      for item in self.dictName.values():
         listBusyIDes.append(item.id)
      listBusyIDes.sort()

      #print(listBusyIDes)

      i = 1
      index = 0

      if len(listBusyIDes) == 0:
         self.log.info(f"freeID={i} (List is empty)")
         return i


      while index < len(listBusyIDes):
         if i <  listBusyIDes[index]:
            self.log.info(f"freeID={i} (before {listBusyIDes[index]})")
            return i
         else:
            #next vacant thing to test
            i = listBusyIDes[index] + 1
            index += 1

      if i < max:
         self.log.info(f"freeID={i} (at the end of list)")
         return i

      raise exceptions.NoFreeIDesException(self.class_type)





   async def getByUUID(self, RID:int, uuid:str) -> T:
      self.log.info(f"[{RID}] get() uuid='{uuid}'")

      if uuid in self.dictUUID:
         entity = self.dictUUID[uuid]
         self.log.info(f"[{RID}]\n" + self.printOne(entity))
         return entity
      else:
         self.log.error(f"[{RID}] uuid='{uuid}' is NOT found.")
         raise exceptions.NotFoundException(self.class_type, "uuid", uuid)

   async def getByName(self, RID:int, name:str) -> T:
      self.log.info(f"[{RID}] getByName() name='{name}'")

      if name in self.dictName:
         entity = self.dictName[name]
         self.log.info(f"[{RID}]\n" + self.printOne(entity))
         return entity
      else:
         self.log.error(f"[{RID}] name='{name}' is NOT found.")
         raise exceptions.NotFoundException(self.class_type, "name", name)


   async def deleteByUUID(self, RID:int, uuid:str):
      self.log.info(f"[{RID}] delete() uuid='{uuid}'")

      async with self.lock:
         entity = await self.getByUUID(RID, uuid)

         if hasattr(self, "isLocked"):
            await self.isLocked(RID, entity)

         if hasattr(self, "beforeDelete"):
            await self.beforeDelete(RID, entity)


         if hasattr(entity, "name"):
            self.dictName.pop(entity.name)

         if uuid in self.dictUUID:
            self.dictUUID.pop(uuid)

         if hasattr(entity, "id"):
            self.dictID.pop(entity.id)



   def addDB(self, RID:int, obj):
      self.log.info(f"[{RID}] add()\n" + self.printOne(obj))

      if hasattr(obj, "name") and obj.name in self.dictName:
         raise exceptions.DuplicateNameException(self.class_type, obj.name)
      if hasattr(obj, "uuid") and obj.uuid in self.dictUUID:
         raise exceptions.DuplicateUuidException(self.class_type, obj.uuid)
      if hasattr(obj, "id") and obj.id in self.dictID:
         raise exceptions.DuplicateIdException(self.class_type, obj.id)

      if hasattr(obj, "name"):
         self.dictName[obj.name] = obj
      if hasattr(obj, "uuid"):
         self.dictUUID[obj.uuid] = obj
      if hasattr(obj, "id"):
         self.dictID[obj.id] = obj

      self.log.info(f"[{RID}] ok, added.")

   def updateDB(self, RID:int, obj):
      self.log.info(f"[{RID}] update()\n" + self.printOne(obj))

      if hasattr(obj, "name"):
         self.dictName[obj.name] = obj
      if hasattr(obj, "uuid"):
         self.dictUUID[obj.uuid] = obj
      if hasattr(obj, "id"):
         self.dictID[obj.id] = obj

      self.log.info(f"[{RID}] ok, updated.")
