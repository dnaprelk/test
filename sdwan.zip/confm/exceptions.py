import json
from enum import Enum
from typing import Dict


class Errors(Enum):
   OK = 0
   UNKNOWN_ERROR = 1
   OBJECT_NOT_FOUND = 1000
   OBJECT_LOCKED    = 1001
   OBJECT_IN_USE_BY = 1002
   DUPLICATE_NAME   = 1003
   NO_FREE_IDES     = 1004
   DUPLICATE_ID     = 1005
   DUPLICATE_UUID   = 1006


class AbstractException(Exception):
   def __init__(self, iErrorCode:Errors, iHttpErrorCode:int, message:str, addParams:Dict):
      super().__init__(message)
      self.iHttpErrorCode = iHttpErrorCode
      self.dict = {"errorCode": iErrorCode.value, "message":message}
      self.dict.update(addParams)
      self.message = message

   def getHttpErrorCode(self):
      return self.iHttpErrorCode

   def getMessage(self):
      return self.message

   def getDictionary(self):
      return self.dict


class NotFoundException(AbstractException):
   def __init__(self, class_type, attribute, value:str):
      super().__init__(Errors.OBJECT_NOT_FOUND,
                       404,
                       f"{class_type} {attribute}='{value}' is not found.",
                       {"entity":{"type":class_type, "attribute":attribute, "value":value}})



class ObjectLockedException(AbstractException):
   def __init__(self, class_type, attribute, value:str):
      super().__init__(Errors.OBJECT_LOCKED,
                       403,
                       f"{class_type} {attribute}='{value}' is locked.",
                       {"entity":{"type":class_type, "attribute":attribute, "value":value}})

class ObjectInUseException(AbstractException):
   def __init__(self, class_type, attribute, value:str, lockedBy:str, lockedByAtrribute:str, lockedByValue:str):
      super().__init__(Errors.OBJECT_IN_USE_BY,
                       403,
                       f"{class_type} {attribute}='{value}' is in use by {lockedBy} {lockedByAtrribute}='{lockedByValue}'",
                       {"entity":{"type":class_type, "attribute":attribute, "value":value},
                        "in_use":{"type":lockedBy, "attribute":lockedByAtrribute, "value": lockedByValue}})



class DuplicateNameException(AbstractException):
   def __init__(self, class_type:str, name:str):
      super().__init__(Errors.DUPLICATE_NAME,
                       403,
                       f"{class_type} name='{name}' already exists.",
                       {"entity":{"type":class_type, "attribute":"name", "value":name}})
class DuplicateUuidException(AbstractException):
   def __init__(self, class_type:str, uuid:str):
      super().__init__(Errors.DUPLICATE_UUID,
                       403,
                       f"{class_type} uuid='{uuid}' already exists.",
                       {"entity":{"type":class_type, "attribute":"uuid", "value":uuid}})
class DuplicateIdException(AbstractException):
   def __init__(self, class_type:str, id:int):
      super().__init__(Errors.DUPLICATE_ID,
                       403,
                       f"{class_type} id='{id}' already exists.",
                       {"entity":{"type":class_type, "attribute":"id", "value":id}})


class NoFreeIDesException(AbstractException):
   def __init__(self, class_type):
      super().__init__(Errors.NO_FREE_IDES,
                       500,
                       f"{class_type} has no free IDes left.",
                       {"entity":{"type":class_type}})
