import aio_pika
import ssl
from ssl import SSLContext

class Rabbit:
   def __init__(self,
                sConnection:str,
                context:SSLContext=None
                ):
      self.sConnection = sConnection
      self.context = context

   async def connect(self):
      if self.context is not None:
         self.connection = await aio_pika.connect_robust(self.sConnection, ssl_context=self.context)
      else:
         self.connection = await aio_pika.connect(self.sConnection)


   async def send_message(self, queue:str, message_body):
      async with self.connection.channel() as channel:
         # Declaring queue (can be done outside if queue is known to exist)
         queue = await channel.declare_queue(queue, durable=True)

         # Sending message
         await channel.default_exchange.publish(aio_pika.Message(body=message_body.encode()), routing_key=queue.name)
