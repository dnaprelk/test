import asyncio

counter:int = 0
counter_lock = asyncio.Lock()

# Function to increment the counter atomically
async def increment() -> int:
   global counter
   async with counter_lock:
      counter += 1
      return counter

# Function to get the current value of the counter atomically
async def get():
   async with counter_lock:
      return counter