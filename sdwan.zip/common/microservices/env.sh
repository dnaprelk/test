#!/bin/bash

if [ -z "$MQTT_SERVER" ]
then
      export MQTT_SERVER=root@127.0.0.1
fi

if [ -z "$CONFM_URL" ]
then
      export CONFM_URL=http://127.0.0.1:8000
fi

if [ -z "$CTL" ]
then
      export CTL=http://127.0.0.1:8080
fi

if [ -z "$SSH" ]
then
      # export SSH="ssh -p 5022 root@91.185.88.125"
      # Do not use ssh on local host
      export SSH=""
fi
