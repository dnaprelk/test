#!/bin/bash

export PYTHONPATH="$PROJECT_ROOT/patched_external:$PROJECT_ROOT/common:$PYTHONPATH"
