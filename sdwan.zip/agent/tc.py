import asyncio
import logging
from dataclasses import dataclass
from typing import Dict

import os_command_utils

import config
import log_utils

# Set up logging configuration
logging.basicConfig(
   level=logging.DEBUG,
   format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s - Line %(lineno)d'
   #format = '\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)

log = logging.getLogger("QoS")
log.setLevel(config.getLogLevel("qos"))


class TS:
   @dataclass(frozen=True)
   class QoS:
      name:str
      priority:int
      min:int
      max:int

   def __init__(self, device:str, speed:int):
      self.device = device
      self.speed = speed
      self.dictQoS:Dict[str, TS.QoS] = {}



   async def addQoS(self, name:str, priority:int, min:int, max:int):
      log.info(f"Add Qos name='{name}' priority={priority} min={min} max={max}")

      if name in self.dictQoS:
         log.error(f"The QoS rule='{name}' already exists.")
      else:
         qos = TS.QoS(name, priority, min, max)
         self.dictQoS[name] = qos

         await os_command_utils.os_command_halt(f"tc class add dev {self.device} parent 1:1 classid 1:1{priority} htb rate {min}mbit ceil {max}mbit prio {priority}")
         await os_command_utils.os_command_ignore(f"tc filter add dev {self.device} parent 1: protocol ip prio {priority} u32 match ip dst 169.254.0.1/32 flowid 1:1{priority}")
         log.info("ok, added.")


   def delQos(self, name:str):
      qos = self.dictQoS[name]
      print(qos)
      #await os_command_utils.os_command_halt(f"tc class del dev {self.device} parent 1:1 classid 1:1{priority}")


   async def clear(self):
      log.info(f"Let's clear the Qos settings")
      await os_command_utils.os_command_halt(f"tc qdisc del dev {self.device} root")
      #os_command_utils.os_command_halt(f"tc filter del dev {self} parent 1")
      self.dictQoS.clear()

      log.debug(f"Let's add the root class...")
      await os_command_utils.os_command_halt(f"tc qdisc add dev {self.device} root handle 1: htb default 100")
      log.debug(f"ok, the root ruls is ready.")


      log.debug(f"We set the link speed limit...")
      await  os_command_utils.os_command_halt(f"tc class add dev {self.device} parent 1: classid 1:1 htb rate {self.speed}mbit ceil {self.speed}mbit")
      log.debug(f"Link speed set.")

      log.info("ok, cleared.")


   async def reapply(self):
      await self.clear()


   def build_tree(self, data):
      return {k: self.build_tree(v) if isinstance(v, dict) else v for k, v in data.items()}


   async def printQoS(self):
      tree = log_utils.Tree("root")
      root = tree.getRoot()

      for rule in self.dictQoS.values():
         nodeRule = root.addNode(f"{rule.name}")
         nodeFilter = nodeRule.addNode(f"priority={rule.priority} min={rule.min} max={rule.max}")
         nodeFilter.addNode(f"filter=AAA")

      return tree.print()

async def test():
   ts = TS("enp7s0", 10)
   await ts.clear()

   await ts.addQoS('Q1', 10, 2, 3)
   await ts.addQoS('Q2', 11, 3, 4)
   await ts.printQoS()

   print(await ts.printQoS())


asyncio.run(test())
