import asyncio
import subprocess
import os
import logging
import random


import config
from os_command_utils import os_command_call


log = logging.getLogger("PING")
log.setLevel(config.getLogLevel("ping"))


class Ping:


   def __init__(self, interface, ip):
      self.interface = interface
      self.ip = ip
      self.iCounter = 0
      self.id = random.randint(1000, 65000)


   async def send(self):

      self.iCounter += 1
      if self.iCounter > 65000:
         self.iCounter = 1

#      sCommand = config.getUtils().ping + " " + self.interface + " " + self.ip + " " + str(self.id) + " " + str(self.iCounter)
      sCommand = f"{config.getUtils().ping} -s -c 1 -I {self.interface}  --icmp_id {str(self.id)} --seq {str(self.iCounter)} {self.ip}"
#log.debug(sCommand)

      result = await os_command_call(sCommand)

      #log.debug("\nOUT: " + result.out + "\nError: " + result.error)
      log.debug("\nOUT: " + result.out + ((len(result.error) > 0) and ("\nERROR: " + result.error) or ""))


      try:
         response = float(result.out)
      except Exception:
         response = None

      log.info(sCommand + " => " + str(response))

      return response