import asyncio
import json
import os
import logging
import fcntl


#import config
import log_utils

FIFO_IN  = "/tmp/pipe_admin_in"
FIFO_OUT = "/tmp/pipe_admin_out"


log = logging.getLogger("ADMIN_PANEL")



if not os.path.exists(FIFO_IN):
   #os.remove(FIFO_IN)
   os.mkfifo(FIFO_IN)
if not os.path.exists(FIFO_OUT):
   #os.remove(FIFO_OUT)
   os.mkfifo(FIFO_OUT)


lock = asyncio.Lock()

fifoIN = os.open(FIFO_IN, os.O_RDWR | os.O_NONBLOCK)
fifoOUT = os.open(FIFO_OUT, os.O_RDWR | os.O_NONBLOCK)
fcntl.fcntl(fifoOUT, fcntl.F_SETFL, os.O_NONBLOCK)

dictInterfaces = {}
state = {}
master = {}


loop = asyncio.get_event_loop()


async def sendInterfaces():
   global dictInterfaces
   global state
   global master

   while True:
      dictInterfacesMessage = {}
      dictRouterStateMessage = {}
      dictMasterMessage = {}

      async with lock:
         dictInterfacesMessage["type"]       = "interfaces"
         dictInterfacesMessage["interfaces"] = dictInterfaces

         if "state" in state:
            dictRouterStateMessage["type"]    = "router_state"
            dictRouterStateMessage["state"]   = state["state"]
            dictRouterStateMessage["message"] = state["message"]

         if "host" in master:
            dictMasterMessage["type"] = "master"
            dictMasterMessage["host"] = master["host"]

      try:

         #log.info(log_utils.print_tree(dictInterfacesMessage))

         try:
            os.write(fifoIN, (json.dumps(dictInterfacesMessage) + "\n").encode("utf8"))
            os.write(fifoIN, (json.dumps(dictRouterStateMessage) + "\n").encode("utf8"))
            os.write(fifoIN, (json.dumps(dictMasterMessage) + "\n").encode("utf8"))
         except BlockingIOError:
            pass

         try:
            data = os.read(fifoOUT, 10000)
            log.info("PANEL=" + data.decode("utf8"))
         except BlockingIOError:
            pass

      except Exception as e:
         log.error(log_utils.print_exception(e))
      await asyncio.sleep(0.5)



async def sendMaster(host:str):
   global master
   master["host"] = host



async def sendPlannedInterfaces(listPlannedInterfaces):
   global  dictInterfaces
   async with lock:
      #log.info(log_utils.print_tree(listPlannedInterfaces))
      for interface in listPlannedInterfaces:
         dictInterfaces[interface["name"]] = interface
         interface["data"] = {}

async def sendCurrentInterface(interface:str, ip:str, gate:str, isDefaultRoute:bool):
   global  dictInterfaces

   async with lock:
      dictInterfaces[interface]["current"] = {}
      dictInterfaces[interface]["current"]["ip"] = ip
      dictInterfaces[interface]["current"]["gate"] = gate
      dictInterfaces[interface]["isDefault"] = isDefaultRoute




async def sendInterfaceType(interface:str, type: str):
   global  dictInterfaces
   async with lock:
      dictInterfaces[interface]["type"] = type


async def sendInterfacePing(interface:str, ping: float):
   global  dictInterfaces
   async with lock:
      dictInterfaces[interface]["ping"] = ping

async def sendInterfaceIO(interface:str, input:int, output:int):
   global  dictInterfaces
   async with lock:
      dictInterfaces[interface]["data"]["in"] = input
      dictInterfaces[interface]["data"]["out"] = output




async def sendRouterState(new_state: str, message: str = ""):
   global state
   async with lock:
      state["state"] = new_state
      state["message"] = message


async def sendInterface(ip:str, gate:str):
   pass


#if config.getAdminPanel().isEnabled:
#   loop.create_task(sendInterfaces())