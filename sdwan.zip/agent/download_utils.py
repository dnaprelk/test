import aiohttp
import asyncio
import os
import logging

#loop = asyncio.new_event_loop()
import config
import ssl
from enum import Enum
from dataclasses import dataclass
import hashlib
from tabulate import tabulate

import log_utils

loop = asyncio.get_event_loop()

log = logging.getLogger("DOWNLOAD")
#log.setLevel(config.getLogLevel("download"))


logging.basicConfig(
   level=logging.DEBUG,
   format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s - Line %(lineno)d'
)





class Downloader:
   class State(Enum):
      STARTED = 0
      DOWNLOADING = 1
      FINISHED = 2
      ERROR = 3

   @dataclass(frozen=True)
   class Task:
      url: str
      state: 'Downloader.State'
      error_message: str


   class _Task:
      def __init__(self, sURL: str, sFullFileName: str):
         self.lock = asyncio.Lock()
         self.url = sURL
         self.full_file_name = sFullFileName

         self._local_file_size = None
         self._remote_file_size = None
         self.state = Downloader.State.STARTED
         self.eventIsReady = asyncio.Event()
         self.task = loop.create_task(self.__start())


      def check_sha512(self, sha512_expected: str) -> bool:
         log.info(f"[{self.full_file_name}] Let's calculate the checksum...")
         try:
            sha512_hash = hashlib.sha512()

            # Open the file in binary mode
            with open(self.full_file_name, 'rb') as file:
               # Read the file in chunks
               for chunk in iter(lambda: file.read(4096), b''):
                  # Update the hash object with the current chunk
                  sha512_hash.update(chunk)

            # Get the hexadecimal representation of the hash digest
            sha512_hash_hex = sha512_hash.hexdigest()

            log.debug(f"[{self.full_file_name}] Done. sha512={sha512_hash_hex}")

            if str(sha512_hash_hex) == sha512_expected:
               log.info(f"[{self.full_file_name}] Verification ok.")
               return True
            else:
               log.error(f"[{self.full_file_name}] Checksum mismatch.\nActual={sha512_hash_hex}\nExpected={sha512_expected}")
               return False
         except Exception:
            return False


      async def isFinished(self):
         log.debug("Let's wait the task is ready.")
         await self.eventIsReady.wait()
         log.debug("ok, that's one is completed.")



      async def restart(self):
         log.info(f"{self.full_file_name} is restarted!")

         if os.path.exists(self.full_file_name):
            os.remove(self.full_file_name)

         async with self.lock:
            self.eventIsReady.clear()
            self._local_file_size = None
            self._remote_file_size = None
            self.state = Downloader.State.STARTED
            self.task = loop.create_task(self.__start())


      async def getLocalFileSize(self):
         async with self.lock:
            return self._local_file_size


      async def getRemoteFileSize(self):
         async with self.lock:
            return self._remote_file_size


      async def __start(self):
         try:
            async with aiohttp.ClientSession() as session:
               headers = {}
               if os.path.exists(self.full_file_name):
                  log.info(f"[{self.full_file_name}] Partial file exists.")
                  async with self.lock:
                     self._local_file_size = os.path.getsize(self.full_file_name)
                  headers['Range'] = f'bytes={self._local_file_size}-'

               async with session.get(self.url, headers=headers) as response:
                  if response.status == 200:
                     # Start from the beginning
                     async with self.lock:
                        self._local_file_size = 0
                        self._remote_file_size = int(response.headers.get('Content-Length'))
                        self.state = Downloader.State.DOWNLOADING
                  elif response.status == 206:
                     # Partial content supported
                     async with self.lock:
                        self._remote_file_size = self._local_file_size + int(response.headers.get('Content-Length'))
                        self.state = Downloader.State.DOWNLOADING
                  elif response.status == 416:
                     log.info(f"[{self.full_file_name}] Seems the file is fully loaded already.")
                     async with self.lock:
                        self._remote_file_size = self._local_file_size
                        self.state = Downloader.State.FINISHED
                     raise Exception
                  else:
                     async with self.lock:
                        self.state = Downloader.State.ERROR
                        log.error("%s\nError: %i, %s" % (self.full_file_name, response.status, await response.text("utf8")))
                     raise Exception

                  with open(self.full_file_name, 'ab') as file:
                     while True:
                        try:
                           chunk = await asyncio.wait_for(response.content.iter_any().__anext__(), timeout=5)  # Set a timeout of 5 seconds for each chunk

                           file.write(chunk)
                           async with self.lock:
                              self._local_file_size += len(chunk)

                        except asyncio.TimeoutError:
                           log.error(f"[{self.full_file_name}] Timeout.")
                           self.state = Downloader.State.ERROR
                           raise Exception

                        except StopAsyncIteration:
                           break



                  self.state = Downloader.State.FINISHED
                  log.info("%s\nDownloaded. Local file size=%i Remote file size=%i" % (self.full_file_name, self._local_file_size, self._remote_file_size))

         except Exception:
            pass

         self.eventIsReady.set()




   def __init__(self):
      self.lock = asyncio.Lock()
      self.mapTasks = {}

      self.task_monitor = loop.create_task(self.monitor(),name="DOWNLOAD_MONITOR")


   async def addTask(self, sURL: str, sFileName: str):
      log.info(f"addTesk() url='{sURL}' local_file='{sFileName}'")
      async with self.lock:
         task =  self.mapTasks.get(sURL)
         if task is None:
            task = self.mapTasks[sURL] = Downloader._Task(sURL, sFileName)
            log.info(f"New task has been added.")
         else:
            log.info(f"Task already exists.")
         return task


   async def getTasks(self):
      async with self.lock:
         return self.mapTasks.values()


   async def monitor(self):
      while True:
         try:
            isAlive = False
            for task in self.mapTasks.values():
               async with task.lock:
                  if task.state == Downloader.State.DOWNLOADING or task.state == Downloader.State.ERROR:
                     isAlive = True

            if isAlive:
               log.debug("\n" + await self.printStatus())

            await asyncio.sleep(2)
         except asyncio.CancelledError as e:
            break
         except Exception as e:
            log.error(log_utils.print_exception(e))

   async def printStatus(self) -> str:
      listRows = []

      async with self.lock:
         for _task in self.mapTasks.values():
            listRow = []
            listRow.append(_task.state.name)
            if _task._local_file_size is not None and _task._remote_file_size is not None:
               listRow.append(str(round(float(_task._local_file_size) * 100 / _task._remote_file_size, 2)) + "%")
            else:
               listRow.append("--")
            listRow.append(_task.full_file_name)
            listRow.append(_task.url)
            listRows.append(listRow)

      return tabulate(listRows, headers=["State", "Progress", "File", "URL"], tablefmt="grid")



"""
async def main():
   test = Downloader()
   await test.addTask("https://download.microsoft.com/download/B/F/0/BF01726A-3DD0-4D7D-9521-6C5B0DB467DB/LyncEntry_bypass_ship_x64_ru-ru_exe/lyncentry.exe", "/tmp/1")
   #"dcb6d765e9e671000d2630fbe30aefc9959bf766e7419197385c355cf8aa61d5e0c6391e224b653f5bba8d050c3c175c7193f013341e81b945a5007bff899420")
   await test.addTask("https://download.microsoft.com/download/B/F/0/BF01726A-3DD0-4D7D-9521-6C5B0DB467DB/LyncEntry_bypass_ship_x86_ru-ru_exe/lyncentry.exe", "/tmp/2")
   #"2c29ccc7349370fd5643eb59db1afeb8c88b88ece000fe8bd021c428e6c59fcf4120bbf4b89e4d4bf11c46f3015e3c3076c6ea6863cd1d9dbae341f6ec8cc9c4")

   while True:
      #print(await test.printStatus())
      await asyncio.sleep(1)

# Run the main function
loop.run_until_complete(main())
"""
