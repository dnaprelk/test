import asyncio
import logging
from dataclasses import dataclass
import os
import time
import traceback

from os_command_utils import os_command_halt
import config
from ping import Ping
import log_utils


log = logging.getLogger("WIREGUARD")
log.setLevel(config.getLogLevel("wireguard"))

loop = asyncio.get_event_loop()





@dataclass(frozen=True)
class Keys:
   private: str
   public: str


@dataclass(frozen=True)
class StatExport:
   ping_fails: int
   ping_delay: float
   time_last_good: float




class WireGuard:
   class Stat:
      def __init__(self):
         self.ping_fails = None
         self.ping_delay = None
         self.time_last_good = time.time()

   def __init__(self):
#      self.conf = conf
#      log.info(log_utils.print_object_tree(conf))


      self.isStarted = False
      self.ping = None
      self.stat:WireGuard.Stat = None
      self.check_deamon = None

      self.lock = asyncio.Lock()

      self.keys:Keys = None


   async def configure(self, remote_address_port:str,
                       remote_virtual_ip:str,
                       remote_key:str,
                       local_virtual_ip:str):
      self.remote_address_port = remote_address_port
      self.remote_virtual_ip   = remote_virtual_ip
      self.remote_key          = remote_key
      self.local_virtual_ip    = local_virtual_ip

      tree = log_utils.Tree("WIREGUARD")
      root = tree.getRoot()

      treeLocal = root.addNode("Local")
      treeLocal.addNode(f"ip={self.local_virtual_ip}")
      treeLocalKeys = treeLocal.addNode("keys")
      treeLocalKeys.addNode(f"private={self.keys.private}")
      treeLocalKeys.addNode(f"public={self.keys.public}")

      treeRemote = root.addNode("Remote")
      treeRemote.addNode(f"endpoint={self.remote_address_port}")
      treeRemote.addNode(f"ip={self.remote_virtual_ip}")
      treeRemote.addNode(f"key={self.remote_key}")

      log.info("\n" + tree.print() + "\n")


   async def generateKeys(self):
      private = (await os_command_halt("wg genkey")).rstrip()
      public = (await os_command_halt('echo %s | wg pubkey' % (private))).rstrip()

      self.keys = Keys(private, public)



   def getKeys(self):
      return self.keys



   async def generateConfigFile(self):
      result = '[Interface]\n'
      result += f"PrivateKey = {self.keys.private}\n"
      result += 'ListenPort = 51820\n\n'
      result += '[Peer]\n'
      result += f"PublicKey = {self.remote_key}\n"
      result += 'AllowedIPs = 169.254.0.0/16\n'
      result += f"Endpoint = {self.remote_address_port}\n"
      result += 'PersistentKeepalive = 10\n'

      wg_conf = open('wg0.conf', 'w')
      wg_conf.write('%s' % result)
      wg_conf.close()


   async def start(self):
      log.info("Starting Wireguard...")
      self.ping = Ping("wg0", self.remote_virtual_ip)
      await self.generateConfigFile()

      await os_command_halt('ip link add dev wg0 type wireguard')
      await os_command_halt('ethtool -K wg0 tx off')
      #await os_command_halt('tc qdisc add dev wg0 root handle 1: htb default 100')

      # configure IP address for wg0 interface
      await os_command_halt(f"ip address add dev wg0 {self.local_virtual_ip}")
      await os_command_halt('ip link set up dev wg0')

      # apply config for Wireguard interface
      await os_command_halt('wg setconf wg0 wg0.conf')
      #cmd = 'ip address replace 169.254.%d.%d/24 dev wg0' % (self.hub_id, self.id)
      #os.system(cmd)

      await self.resetPingStatistics()
      self.check_deamon = loop.create_task(self.check_tunnel())
      log.info("Started!")

   async def stop(self):
      log.info("Stopping Wireguard...")

      #Just to be sure if we call stop not being started
      if self.check_deamon is not None:
         self.check_deamon.cancel()

      self.stat = None
      await os_command_halt('ip link del dev wg0  2>/dev/null')

      log.info("Stopped.")

   async def restart(self):
      await self.stop()
      await self.start()



   async def check_tunnel(self):

      while True:
         try:
            ping = await self.ping.send()

            async with self.lock:
               if self.stat:
                  if ping == None:
                     if self.stat.ping_fails is None:
                        self.stat.ping_fails = 1
                     else:
                        self.stat.ping_fails += 1
                     self.stat.ping_delay = None
                  else:
                     self.stat.ping_fails = 0
                     self.stat.ping_delay = ping
                     self.stat.time_last_good = time.time()
            await asyncio.sleep(config.TIMER_WG_PING)

         except Exception as e:
            log.fatal(log_utils.print_exception(e))



   async def getStatistics(self) -> StatExport:
      async with self.lock:
         if self.stat is None:
            return None
         return StatExport(self.stat.ping_fails, self.stat.ping_delay, self.stat.time_last_good)


   async def resetPingStatistics(self):
      async with self.lock:
         if self.stat == None:
            self.stat = WireGuard.Stat()
         else:
            self.stat.ping_delay = None
            self.stat.ping_fails = None

   async def reset(self):
      await self.resetPingStatistics()

      if os.path.exists("wg0.conf"):
         os.remove("wg0.conf")
      await self.stop()