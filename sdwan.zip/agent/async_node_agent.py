#!/usr/bin/env python3

import asyncio
import os
import time
import traceback
import aiohttp
import json
import logging
import signal
import psutil
from enum import Enum
import sys
import tabulate
from datetime import datetime
from typing import List, Union
from dataclasses import dataclass
from tabulate import tabulate




VERSION = 0.029
VERSION_COMMENT = "CPE Unneeded vnf will be removed."



# Set up logging configuration
logging.basicConfig(
   level=logging.DEBUG,
   format='%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s - Line %(lineno)d'
   #format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s - Line %(lineno)d'
   #format = '\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)


loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)



log = logging.getLogger("MAIN")

import api
import download_utils
import terminate


if sys.version.startswith("3.9") != True:
   log.critical(f"You have to use Python 3.9.x instead of current {sys.version}.")
   terminate.terminate()


class STATE:

   class State(Enum):
      READING_CONFIG = 0
      CONFIGURING_INTERFACES = 1
      OFFLINE = 2
      REGISTERRING_WITH_MASTER = 3
      STARTING_NETWORK = 4
      MQTT = 5
      ONLINE = 6

   def __init__(self):
      self.state = STATE.State.READING_CONFIG
      self.time = time.time()
      self.lock = asyncio.Lock()

   async def setState(self, state: State, message:str = ""):
      async with self.lock:
         log.info(self.state.name + "->" + state.name)
         self.state = state
         await api.sendRouterState(state.name, message)

   async def getState(self) -> State:
      async with self.lock:
         return self.state
   async def getTime(self) -> float:
      async with self.lock:
         return self.time


state = STATE()



import config




import lxc_utils
from network import WAN,LAN
import network
import network_interface
import network_interface_wan
from os_command_utils import os_command_halt, os_command_ignore
from wireguard import WireGuard
from mqtt import MQTT
import log_utils
import crash_utils


log.setLevel(config.getLogLevel("main"))

wan = WAN()
lan = LAN()
lxc = lxc_utils.LXC()


class RegistrationException(Exception):
   code: int
   body: str

async def post_request(url, data):
   async with aiohttp.ClientSession() as session:
      try:
         async with session.post(url, json=data, timeout=10) as response:
            if response.status == 200:
               return await response.json()
            else:
               raise RegistrationException(response.status, await response.text("utf8"))
      except asyncio.TimeoutError:
         raise RegistrationException(None, "Request timed out")
      except aiohttp.ClientError as e:
         raise RegistrationException(None, f"{str(e)}")
      except Exception as e:
         raise RegistrationException(None, f"Unknown Error: {str(e)}")




@dataclass(frozen=True)
class Node:
   name: str
   id: int
   domain: str
   speed: int
   machine_id: str







#Let's configure the things
async def init():
#   async with lockNetwork:
   log.info("Let's run auxillar things first...")

   #keys: Wireguard.Keys = await WireGuard.generateKeys()
   #log.info("WG keys:\n" + log_utils.print_tree(keys.__dict__))
   #return keys



@dataclass(frozen=True)
class Registration:

   @dataclass(frozen=True)
   class Node:
      name: str
      id: int
      domain: str
      #speed: int
      machine_id: str


   @dataclass(frozen=True)
   class Hub:
      id: int
      ip: str
      port: int
      public_key: str
      virtual_ip: str

   node: Node
   hub: Hub




async def registerNode(host: str,
                       machine_id: str,
                       wg_public_key: str,
#                       platform: str,
                       currwan: int) -> Registration:
   log.info(f"registerNode() host={host} machine_id={machine_id} currwan={currwan}")

   data = {
      "key": machine_id,
      "pubkey": wg_public_key,
#      "platform": platform,
      "currwan": currwan,
      "version": VERSION
   }

   sUrl = f"https://{host}/register/node"
   log.info(" => " + sUrl + "\n" + log_utils.print_tree(data))

   answer = await post_request(sUrl, data)
   log.info(log_utils.print_tree(answer))

   #What's for the dictionary here for?
   sNodeName = next(iter(answer))

   fMinVersion = answer[sNodeName]["agent"]["min_version"]
   if VERSION < fMinVersion:
      log.fatal(f"We have to upgrade agent to version={fMinVersion}")


      FILE_PATH = "/tmp/distrib.zip"

      if os.path.exists(FILE_PATH):
         os.remove(FILE_PATH)

      downloader = download_utils.Downloader()
      task = await downloader.addTask(answer[sNodeName]["agent"]["distrib"], FILE_PATH)

      await task.isFinished()

      if (task.check_sha512(answer[sNodeName]["agent"]["sha"])):
         await os_command_ignore(f"rm {os.getcwd()}/*.py")
         log.info(await os_command_halt(f"unzip -o {FILE_PATH} -d {os.getcwd()}"))

      await destroy()



   node = Registration.Node(sNodeName,
                            answer[sNodeName]["id"],
                            answer[sNodeName]["domain"],
#                            answer[sNodeName]["speed"],
                            machine_id)
   #log.info("Node:\n" + log_utils.print_tree(node.__dict__))


   hub = Registration.Hub(answer[sNodeName]["hub_id"],
                          answer[sNodeName]["hub_ip"],
                          answer[sNodeName]["hub_port"],
                          answer[sNodeName]["hub_pubkey"],
                          '169.254.%s.254' % answer[sNodeName]["hub_id"])
   #log.info("Hub:\n" + log_utils.print_tree(hub.__dict__))

   tree = log_utils.Tree("REGISTRATION")
   root = tree.getRoot()

   treeNode = root.addNode("Node")
   treeNode.addNode(f"name={node.name}")
   treeNode.addNode(f"id={node.id}")
   treeNode.addNode(f"domain={node.domain}")
   treeNode.addNode(f"machine_id={machine_id}")
   treeNode.addNode(f"platform={answer[sNodeName]['platform']}")


   treeHub = root.addNode("HUB")
   treeHub.addNode(f"id={hub.id}")
   treeHub.addNode(f"remote={hub.ip}:{hub.port}")
   treeHub.addNode(f"local={hub.virtual_ip}")
   treeHub.addNode(f"pub_key={hub.public_key}")

   log.info("\n" + tree.print() + "\n")

   return Registration(node, hub)


async def startNetwork(conf: Registration):
   # Stop damned firewall
   await os_command_halt("systemctl stop firewalld")

   # Let's clear config and start OVS
   await os_command_ignore("/usr/share/openvswitch/scripts/ovs-ctl stop")
   await os_command_ignore("rm -f /etc/openvswitch/conf.db* /etc/openvswitch/.conf.db*")
   await os_command_halt("/usr/share/openvswitch/scripts/ovs-ctl start")

   # set hostname
   await os_command_halt('hostnamectl set-hostname %s.%s.local' % (conf.node.name, conf.node.domain))


   # setup TC
   #await os_command_halt('tc class add dev wg0 parent 1: classid 1:1 htb rate %smbit ceil %smbit' % (conf.node.speed, conf.node.speed))
   #await os_command_halt('tc class add dev wg0 parent 1:1 classid 1:10 htb rate 100kbit ceil 100kbit prio 0')
   #await os_command_halt('tc filter add dev wg0 parent 1: protocol ip prio 0 u32 match ip dst 169.254.0.1/32 flowid 1:10')


   await os_command_halt('sysctl -w net.ipv4.conf.all.rp_filter=2')


   # setup Openvswitch
   await os_command_ignore('ovs-vsctl add-br br0')
   await os_command_halt('ovs-vsctl set bridge br0 other_config:datapath-id=00000000a9fe%02x%02x' % (conf.hub.id, conf.node.id))
   await os_command_halt('ovs-vsctl set bridge br0 protocols=OpenFlow13')
   await os_command_ignore('ovs-vsctl add-port br0 tun0 -- set Interface tun0 type=gre options:remote_ip=flow options:key=flow options:df_default=false')
   await os_command_halt('ovs-vsctl set-fail-mode br0 secure')
   await os_command_halt('ovs-vsctl --inactivity-probe=1000 set-controller br0 tcp:169.254.0.1:6633')



async def mqtt_listener(registration: Registration, mqtt: MQTT):
   while True:
      try:
         incomingMessage = await mqtt.get()

         if incomingMessage.topic == f"from_vnfm/to_cpe/{registration.node.name}/start_vnf":
            body = incomingMessage.body
            sVNF = incomingMessage.body["name"]
            log.info(f"{sVNF} -> UP")

            if lxc.isContainerExist(sVNF):
               log.info(f"{sVNF} is already exist. Let's reuse the existing one.")
            else:
               await lxc.createContainer(sVNF,
                                         body["image"]["name"],
                                         int(body["image"]["size"]),
                                         body["image"]["sha"])

            await lxc.setContainerConfig(sVNF, body["lxc_config"])
            await lxc.setContainerStartScript(sVNF, body["vnf_config"])
            await lxc.startContainer(sVNF)

         elif incomingMessage.topic == f"from_vnfm/to_cpe/{registration.node.name}/stop_vnf":
            body = incomingMessage.body
            sVNF = incomingMessage.body["name"]
            log.info(f"{sVNF} -> DOWN")

            try:
               await lxc.stopContainer(sVNF)
            except lxc_utils.LXC.ContainerNotFoundException:
               pass
         elif incomingMessage.topic == f"from_vnfm/to_cpe/{registration.node.name}/remove_vnf":
            body = incomingMessage.body
            sVNF = incomingMessage.body["name"]
            log.info(f"{sVNF} -> REMOVE!")

            try:
               await lxc.removeContainer(sVNF)
            except lxc_utils.LXC.ContainerNotFoundException:
               pass
         elif incomingMessage.topic == "admin/reset/system":
            log.critical("Let's stop process.")
            sig = getattr(signal, "SIGKILL", signal.SIGTERM)
            os.kill(os.getpid(), sig)
         elif incomingMessage.topic == "admin/reboot/hub":
            log.critical("Let's reboot the device.")
            os.system("reboot")
         elif incomingMessage.topic == "admin/reboot/cpe":
            if incomingMessage.body["name"] == registration.node.name:
               log.critical("Let's reboot the device.")
               os.system("reboot")


      except Exception as e:
         log.fatal(log_utils.print_exception(e))




async def send_statistics_mqtt(conf: Registration, mqtt:MQTT, wg:WireGuard):

   log = logging.getLogger("STAT")
   log.setLevel(config.getLogLevel("stat"))

   log.info("MQTT statistic deamon is starting...")

   while True:
      try:
         net = psutil.net_io_counters(pernic=True)

#         result = {
#            conf.node.name: {
#               'status': 'online',
#               'delay': (await wg.getStatistics()).ping_delay,
#               'cpu': psutil.cpu_percent(),
#               'mem': psutil.virtual_memory()[2],
#               'disk': psutil.disk_usage('/')[3],
#               'temperature': psutil.sensors_temperatures()['coretemp'][0][1],
#               'uplink_tx': net['wg0'][0],
#               'uplink_rx': net['wg0'][1],
#               'interfaces': {}
#            }
#         }

         result = {
            conf.node.name: {
               'status': 'online',
               'delay': (await wg.getStatistics()).ping_delay,
               'cpu': psutil.cpu_percent(),
               'mem': psutil.virtual_memory()[2],
               'disk': psutil.disk_usage('/')[3],
               #'temperature': psutil.sensors_temperatures()['coretemp'][0][1],
               'uplink_tx': net['wg0'][0],
               'uplink_rx': net['wg0'][1],
               'interfaces': {
                   'wan': {},
                   'lan': {}
                }
            }
         }


         if "coretemp" in psutil.sensors_temperatures():
            result[conf.node.name]["temperature"] = psutil.sensors_temperatures()['coretemp'][0][1]
         else:
            log.debug("No temperature data in psutil.")


         for wanInterface in wan.getInterfaceList():
             data = {}
             data["status"] = (await wanInterface.getState()).name.lower()

             #print(log_utils.print_tree(net))
             if wanInterface.getPhysName() in net:
                data["data_tx"] = net[wanInterface.getPhysName()][0]
                data["data_rx"] = net[wanInterface.getPhysName()][1]
             result[conf.node.name]['interfaces']['wan'][wanInterface.getNumber()] = data

         for lanInterface in lan.getInterfaceList():
             data = {}
             data["status"] = (await lanInterface.getState()).name.lower()
             if lanInterface.getPhysName() in net:
                data["data_tx"] = net[lanInterface.getPhysName()][0]
                data["data_rx"] = net[lanInterface.getPhysName()][1]
             result[conf.node.name]['interfaces']['lan'][lanInterface.getNumber()] = data


         result[conf.node.name]['interfaces']["currwan"] = (await wan.getDefaultRoute()).getNumber()


#         for wanInterface in wan.getInterfaceList():
#            result[conf.node.name]['interfaces'][wanInterface.getName()] = (await wanInterface.getState()).name
#         for lanInterface in lan.getInterfaceList():
#            result[conf.node.name]['interfaces'][lanInterface.getName()] = (await lanInterface.getState()).name

         #log.info(log_utils.print_tree(result))

         await mqtt.publish('node/' + conf.node.name + '/ping', result)
      # except mqtt.client.ClientException as e:
      #    await state.setState(STATE.State.OFFLINE)
      except Exception as e:
         log.fatal(log_utils.print_exception(e))

      await asyncio.sleep(2)



async def send_statistics_api():

   log = logging.getLogger("STAT")
   log.setLevel(config.getLogLevel("stat"))

   log.info("API statistic deamon is starting...")

   while True:
      try:
         net = psutil.net_io_counters(pernic=True)

         for wanInterface in wan.getInterfaceList():
            if wanInterface.isValid():
               await api.sendInterfaceIO(wanInterface.getName(),
                                         net[wanInterface.getPhysName()][1],
                                         net[wanInterface.getPhysName()][0])

               await api.sendCurrentInterface(wanInterface.getName(),
                                              await wanInterface.get_ip_address(),
                                              await wanInterface.getRoute(),
                                              (await wan.hasDefaultRoute()) and (await wan.getDefaultRoute()).name == wanInterface.name)

      except Exception as e:
         log.fatal(log_utils.print_exception(e))
      await asyncio.sleep(2)








async def monitor_vnfs(conf: Registration, mqtt: MQTT):
   log = logging.getLogger("VNF MONITOR")
   log.setLevel(config.getLogLevel("stat"))

   log.info("VNF deamon is starting...")
   while True:
      try:
         listVnfs = []
         for container in lxc.getContainers():
            vnf = {}
            listVnfs.append(vnf)
            vnf["name"] = container.name
            if container.state == lxc_utils.State.RUNNING:
               vnf["pid"] = container.pid
               vnf["cpu"] = await lxc.getCpuUsage(container.name)
               vnf["mem"] = await lxc.getMemoryUsage(container.name)
         await mqtt.publish(f"from_cpe/{conf.node.name}/to_vnfm/vnf_states", listVnfs)
      except Exception as e:
         log.fatal(log_utils.print_exception(e))

      await asyncio.sleep(1)



async def monitor_interfaces(wan:WAN):
   while True:
      try:
         log.info(f"\n{await wan.print()}")


         arrRows = []
         statWg = await wg.getStatistics()
         if statWg is not None:
            arrRow = []
            arrRows.append(arrRow)
            arrRow.append(datetime.fromtimestamp(round(statWg.time_last_good, 0)))
            arrRow.append(statWg.ping_fails if statWg.ping_fails is not None else "---")
            arrRow.append(statWg.ping_delay if statWg.ping_delay is not None else "---")
            log.info("\n" + tabulate(arrRows, headers=["Last good ping", "Ping fails", "Ping delay"], tablefmt="grid"))


         arrRows = []
         arrDefaultRoutes = (await os_command_halt("ip route")).split("\n")
         for sLine in arrDefaultRoutes:
            if sLine.startswith("default"):
               arrSections = sLine.split(" ")
               arrRow = []
               arrRows.append(arrRow)
               arrRow.append(arrSections[2])
               arrRow.append(arrSections[4])

               if len(arrSections) > 6:
                  arrRow.append(arrSections[6])
               else:
                  arrRow.append(0)
         log.info("\n" + tabulate(arrRows, headers=["Gate", "Device", "Metric"], tablefmt="grid"))

      except Exception as e:
         log.fatal(log_utils.print_exception(e))

      await asyncio.sleep(1)


wg = WireGuard()





async def switchUplinkByPing():
   log.error("switchUplink()")

   listAliveInterfaces: List[network.InterfaceWAN] = []
   for interface in wan.getInterfaceList():
      stat = interface.getStatistics()

      ping_fails = stat.getPingFails()
      if interface.isValid() \
            and (await interface.check_state() == network_interface.Interface.State.UP) \
            and (await interface.hasIP()) \
            and (ping_fails is None or ping_fails == 0)\
            and interface.getNumber() != (await wan.getDefaultRoute()):
         listAliveInterfaces.append(interface)

   if len(listAliveInterfaces) == 0:
      log.critical("ALL WAN INTERFACES are DEAD.")
      # await state.setState(STATE.State.OFFLINE)
      #await destroy()
   else:
      await wg.resetPingStatistics()
      await wan.setDefaultRoute(listAliveInterfaces[0])


async def switchUplinkToNext():
   log.error("switchUplinkToNext()")

   listAliveInterfaces: List[network.InterfaceWAN] = []
   for wanInterface in wan.getInterfaceList():
      if wanInterface.isValid()\
            and (await wanInterface.check_state() == network_interface.Interface.State.UP)\
            and (await wanInterface.hasIP())\
            and (await wanInterface.hasRoute())\
            and wanInterface.getNumber() != (await wan.getDefaultRoute()):
         listAliveInterfaces.append(wanInterface)

   if len(listAliveInterfaces) == 0:
      log.critical("ALL WAN INTERFACES are DEAD.")
      # await state.setState(STATE.State.OFFLINE)
      #await destroy()
   else:
      for wanInterface in listAliveInterfaces:
         wanDefaultRoute = await wan.getDefaultRoute()
         if wanDefaultRoute == None or wanInterface.getNumber() > wanDefaultRoute.number:
            await wan.setDefaultRoute(wanInterface)
            return
      await wan.setDefaultRoute(listAliveInterfaces[0])


# some shit
#no idea how but we constantly get default route with metric 0
async def removeFakeMetric():
   await os_command_ignore("ip route del default metric 0")


def convertConfiguration(configuration:Union[config.__Interfaces.Interface.ConfigurationStatic,
                                             config.__Interfaces.Interface.ConfigurationDHCP]) -> Union[network_interface_wan.InterfaceWAN.ConfigurationStatic,
                                                                                                        network_interface_wan.InterfaceWAN.ConfigurationDHCP]:

   if isinstance(configuration, config.__Interfaces.Interface.ConfigurationStatic):
      return network_interface_wan.InterfaceWAN.ConfigurationStatic(ip=configuration.ip,
                                                                    gate=configuration.gate,
                                                                    dns=configuration.dns)
   if isinstance(configuration, config.__Interfaces.Interface.ConfigurationDHCP):
      return network_interface_wan.InterfaceWAN.ConfigurationDHCP(server=configuration.server,
                                                                  dns=configuration.dns)

   return None


async def stateMachine(state:STATE):
   log.info("Let's START!")

   registration: Registration

   # Let's publish stat data to api
   loop.create_task(send_statistics_api())

   try:
      await wan.resetRoutes()

      log.info("Let' register WAN interfaces in system...")

      loop.create_task(monitor_interfaces(wan))

      for confInterfaceWAN in config.getInterfaces().listWAN:
         await state.setState(STATE.State.CONFIGURING_INTERFACES, confInterfaceWAN.name)

         interface = None

         log.info("\n" + log_utils.print_object_tree(confInterfaceWAN))

         if isinstance(confInterfaceWAN.hardware, config.__Interfaces.Interface.HardwareWired):
            interface = network_interface_wan.InterfaceWAN_Wired(confInterfaceWAN.name,
                                                                 confInterfaceWAN.phys,
                                                                 confInterfaceWAN.number,
                                                                 configuration=convertConfiguration(confInterfaceWAN.hardware.configuration))

         if isinstance(confInterfaceWAN.hardware, config.__Interfaces.Interface.HardwareWireless):
               interface = network_interface_wan.InterfaceWAN_Wireless(confInterfaceWAN.name,
                                                                    confInterfaceWAN.phys,
                                                                    confInterfaceWAN.number,
                                                                    confInterfaceWAN.hardware.ssid,
                                                                    confInterfaceWAN.hardware.password,
                                                                    configuration=convertConfiguration(confInterfaceWAN.hardware.configuration))

         if isinstance(confInterfaceWAN.hardware, config.__Interfaces.Interface.HardwareModem):
            interface = network_interface_wan.InterfaceWAN_Modem(confInterfaceWAN.name,
                                                                 confInterfaceWAN.phys,
                                                                 confInterfaceWAN.number,
                                                                 confInterfaceWAN.hardware.apn,
                                                                 confInterfaceWAN.hardware.user,
                                                                 confInterfaceWAN.hardware.password)

         if interface is None:
            crash_utils.registerIncident(f"{confInterfaceWAN.name} has unknown interface type.")
            terminate.terminate()

         wan.add(interface)

         await api.sendInterfaceType(interface.name, interface.getType().name)



      if len(wan.getInterfaceList()) == 0:
         crash_utils.registerIncident("No WAN uplinks.")
         terminate.terminate()



      log.info("Let' register LAN interfaces in system...")
      for interfaceLAN in config.getInterfaces().listLAN:
         lan.add(interfaceLAN.name, interfaceLAN.phys, interfaceLAN.number)





      mqtt: MQTT = None
   #   deamon_main: asyncio.Task = None
   #   deamon_mqtt: asyncio.Task = None

   #   conf_wg_keys: Wireguard.keys
   #   conf_node: Node
   #   conf_wg:   Wireguard


      await state.setState(STATE.State.OFFLINE)

      while True:
         try:
            #await asyncio.sleep(1)

            log.debug("state=" + (await state.getState()).name)

            # arrDefaultRoutes = (await os_command_halt("ip route")).split("\n")
            #
            # for sLine in arrDefaultRoutes:
            #    try:
            #       if sLine.startswith("default"):
            #          arrSections = sLine.split(" ")
            #          if len(arrSections) > 6:
            #             pass
            #          else:
            #             if len(arrDefaultRoutes) > 1:
            #                await removeFakeMetric()
            #    except Exception as e:
            #       pass
            #
            #
            # await wan.restoreRoutes()


            if await state.getState() == STATE.State.OFFLINE:
               #await destroy(wan, lan, wg, mqtt)

               await wg.reset()
               await wg.generateKeys()

               await os_command_ignore("killall dhclient")
               await os_command_ignore("killall wpa_supplicant")

               await state.setState(STATE.State.REGISTERRING_WITH_MASTER)

            elif await state.getState() == STATE.State.REGISTERRING_WITH_MASTER:
               if await wan.getDefaultRoute() == None:
                  log.info("No Default Route yet.")
                  await switchUplinkToNext()

                  if await wan.getDefaultRoute() == None:
                     log.error(f"We are waiting for any alive interface for {round(time.time() - await state.getTime(), 2)} seconds.")
                     if await state.getTime() > 100:
                        pass

                     await asyncio.sleep(1)

                     continue

               registration = await registerNode(host=config.getMaster().url,
                                                 machine_id=config.getNode().machine_id,
                                                 wg_public_key=wg.getKeys().public,
                                                 #config.getNode().platform,
                                                 currwan=(await wan.getDefaultRoute()).getNumber())

               for wanInterface in wan.getInterfaceList():
                  await wanInterface.setHubIP(registration.hub.ip)

               await state.setState(STATE.State.STARTING_NETWORK)

            elif await state.getState() == STATE.State.STARTING_NETWORK:

               #await os_command_ignore('ip link del dev wg0 2>/dev/null')
               #await os_command_ignore('ovs-vsctl del-br br0 2>/dev/null')

               await wg.configure(remote_address_port=f"{registration.hub.ip}:{registration.hub.port}",
                                  remote_virtual_ip=f"169.254.{registration.hub.id}.254",
                                  remote_key=registration.hub.public_key,
                                  local_virtual_ip=f"169.254.{registration.hub.id}.{registration.node.id}/16")
               await wg.restart()
               await startNetwork(registration)

               await state.setState(STATE.State.MQTT)

            elif await state.getState() == STATE.State.MQTT:
               mqtt = MQTT(registration.node.machine_id)

               try:
                  result = await asyncio.wait_for(mqtt.connect("169.254.0.1"), timeout=20)
               except asyncio.TimeoutError:
                  log.error("MQTT timeout!")
                  #await state.setState(STATE.State.OFFLINE)
                  await destroy()

               await mqtt.subscribe([
                                     f"nodem/#",
                                     f"admin/#",
                                     f"from_vnfm/to_cpe/{registration.node.name}/#",
                                    ])

               deamon_mqtt_listener   = loop.create_task(mqtt_listener(registration, mqtt))
               deamon_mqtt_statistics = loop.create_task(send_statistics_mqtt(registration, mqtt, wg))
               deamon_mqtt_vnf        = loop.create_task(monitor_vnfs(registration, mqtt))

               #result = {
               #   registration.node.name: {
               #      'status': 'online'
               #   }
               #}
               #await mqtt.publish("node/update", result)

               await state.setState(STATE.State.ONLINE)

            elif await state.getState() == STATE.State.ONLINE:
               statWg = await wg.getStatistics()

               if time.time() - statWg.time_last_good > 30:
                  log.critical("TUNNEL TIMEOUT.")
                  await destroy()

               elif statWg.ping_fails is not None and statWg.ping_fails > 10:
                  log.fatal("TUNNEL is dead, we offline.")
                  await switchUplinkByPing()
                  await asyncio.sleep(0.1)
                  continue



               for wanInterface in wan.getInterfaceList():
                  if (await wanInterface.check_state()) == network_interface.Interface.State.DOWN:

                     defaultRouteInterface = await wan.getDefaultRoute()
                     if defaultRouteInterface is not None and defaultRouteInterface.name == wanInterface.name:
                        await wan.setDefaultRoute(None)
                        await switchUplinkByPing()
                        break



               #No errors but we want to rollback to a faster interface if possible
               listAliveInterfaces: List[network.InterfaceWAN] = []
               for wanInterface in wan.getInterfaceList():
                  if wanInterface.isValid() \
                        and (await wanInterface.check_state() == network_interface.Interface.State.UP) \
                        and (await wanInterface.hasIP()) \
                        and wanInterface.getNumber() != (await wan.getDefaultRoute()) \
                        and await wanInterface.getStatistics().checkHealth():
                     listAliveInterfaces.append(wanInterface)

               for wanInterface in listAliveInterfaces:
                  defaultRoute = await wan.getDefaultRoute()

                  if defaultRoute == None or wanInterface.getNumber() < defaultRoute.number:
                     log.info(f"Let's switch back to a faster interface {wanInterface.logTag}")
                     await wan.setDefaultRoute(wanInterface)
                     break
            await asyncio.sleep(config.TIMER_MAIN_CYCLE)

         except RegistrationException as e:
            log.error(e)
            await state.setState(STATE.State.REGISTERRING_WITH_MASTER, str(e))
            await asyncio.sleep(1)
            await switchUplinkToNext()

         except asyncio.CancelledError:
            break
         except Exception as e:
            sErrorMessage = log_utils.print_exception(e)
            log.fatal(sErrorMessage)
            crash_utils.registerIncident(sErrorMessage)
            await asyncio.sleep(1)


   except Exception as e:
      sErrorMessage = log_utils.print_exception(e)
      log.fatal(sErrorMessage)
      crash_utils.registerIncident(sErrorMessage)
      loop.stop()

daemon_main = loop.create_task(stateMachine(state), name="MAIN")

async def destroy():
   #await wan.close()
   loop.stop()

def destroy_signal(signum, frame):
   log.info("Let's close the things")

   asyncio.run_coroutine_threadsafe(destroy(), loop)
   #loop.stop()

signal.signal(signal.SIGINT, destroy_signal)
signal.signal(signal.SIGHUP, destroy_signal)

loop.run_forever()
log.info("Program terminated.")


lxc.stopAll()



async def destroy_old(wan: WAN, lan: LAN, wg: WireGuard, mqtt: MQTT):

   if wan is not None:
#      await wan.stop()
      pass
   if lan is not None:
#      await lan.stop()
      pass
   if wg is not None:
      await wg.stop()
   if mqtt is not None:
      await mqtt.disconnect()

   await os_command_halt('ip route del 0.0.0.0/0 metric 99 2>/dev/null')
   await os_command_halt('ip link del dev wg0 2>/dev/null')
   await os_command_halt('ovs-vsctl del-br br0 2>/dev/null')
