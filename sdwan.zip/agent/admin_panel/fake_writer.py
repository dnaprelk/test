import os
import time
import json
import random

FIFO_IN  = "/tmp/pipe_admin_in"
FIFO_OUT = "/tmp/pipe_admin_out"

fifoIN = os.open(FIFO_IN, os.O_RDWR | os.O_NONBLOCK)
fifoOUT = os.open(FIFO_OUT, os.O_RDWR | os.O_NONBLOCK)

iCounter = 0

while True:

   try:
      dictInterfacesMessage = {}
      dictInterfacesMessage["type"] = "interfaces"

      dictInterfaces = {}
      dictInterfacesMessage["interfaces"] = dictInterfaces


      interface = {}
      interface["name"] = "eth1"
      interface["type"] = "WIRED"
      interface["ping"] = random.randint(10, 100)
      interface["data"] = {}
      iCounter += random.randint(1, 10)
      interface["data"]["in"] = iCounter
      interface["data"]["out"] = (iCounter + 100)
      interface["static"] = {}
      interface["static"]["ip"] = "1.2.3.4/24"
      interface["static"]["gate"] = "1.2.3.1"
      interface["static"]["dns"] = "8.8.8.8"
      interface["current"] = {}
      interface["current"]["ip"] = "5.6.7.8/28"
      interface["current"]["gate"] = "5.6.7.1"
      dictInterfaces[interface["name"]] = interface


      interface = {}
      interface["name"] = "eth2"
      interface["type"] = "WIRED"
      interface["ping"] = random.randint(10, 100)
      interface["data"] = {}
      iCounter += random.randint(1, 10)
      interface["data"]["in"] = iCounter
      interface["data"]["out"] = (iCounter + 100)
      interface["static"] = {}
      interface["static"]["ip"] = "10.20.30.40/24"
      interface["static"]["gate"] = "10.20.30.10"
      interface["static"]["dns"] = "8.8.8.8"
      interface["current"] = {}
      interface["current"]["ip"] = "10.20.30.40/24"
      interface["current"]["gate"] = "10.20.30.10"
      dictInterfaces[interface["name"]] = interface


      interface = {}
      interface["name"] = "wlan1"
      interface["type"] = "WIRELESS"
      interface["ping"] = random.randint(10, 100)
      interface["data"] = {}
      iCounter += random.randint(1, 10)
      interface["data"]["in"] = iCounter
      interface["data"]["out"] = (iCounter + 100)
      interface["dhcp"] = {}
      interface["dhcp"]["dns"] = "18.18.18.18"
      interface["current"] = {}
      interface["current"]["ip"] = "12.234.34.24/24"
      interface["current"]["gate"] = "12.234.34.1"
      dictInterfaces[interface["name"]] = interface


      interface = {}
      interface["name"] = "wlan2"
      interface["type"] = "NOT_FOUND"
      interface["dhcp"] = {}
      interface["dhcp"]["dns"] = "18.18.18.18"
      dictInterfaces[interface["name"]] = interface


      os.write(fifoIN, (json.dumps(dictInterfacesMessage) + "\n").encode("utf8"))

      dictMasterMessage = {}
      dictMasterMessage["type"] = "master"
      dictMasterMessage["url"] = "mtsdemo.henelora.net"
      os.write(fifoIN, (json.dumps(dictMasterMessage) + "\n").encode("utf8"))


      data = os.read(fifoOUT, 10000)
   except Exception as e:
      print (e)


   time.sleep(0.5)


   #dictRouterStateMessage = {}
   #dictRouterStateMessage["type"] = "router_state"
   #dictRouterStateMessage["state"] = state["state"]
   #dictRouterStateMessage["message"] = state["message"]