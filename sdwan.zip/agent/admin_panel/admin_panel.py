import asyncio
import json

import websockets
import os


FIFO_IN  = "/tmp/pipe_admin_in"
FIFO_OUT = "/tmp/pipe_admin_out"


"""
if os.path.exists(FIFO_IN):
   os.remove(FIFO_IN)
os.mkfifo(FIFO_IN)
if os.path.exists(FIFO_OUT):
   os.remove(FIFO_OUT)
os.mkfifo(FIFO_OUT)
"""


fifoIN = os.open(FIFO_IN, os.O_RDWR | os.O_NONBLOCK)
fifoOUT = os.open(FIFO_OUT, os.O_RDWR | os.O_NONBLOCK)

listSockets = []
dictBuffer = {}





async def sendToAll(sData):
   listActiveSockets = []
   for websocket in listSockets:
      if websocket.closed:
         pass
      else:
         listActiveSockets.append(websocket)
         await websocket.send_messages(sData)
   listSockets.clear()
   listSockets.extend(listActiveSockets)





async def readFIFO():
   global dictBuffer

   sBuffer = ""
   while True:
      try:
         data = os.read(fifoIN, 10000)
         sIncomingData = data.decode("utf8")
         print(sIncomingData)
         sBuffer += sIncomingData
         #print(sBuffer)

         try:
            for sMessage in sBuffer.split("\n"):
               if sMessage == "":
                  continue
               #print(sMessage)
               jsonIncomingData = json.loads(sMessage)
               print(jsonIncomingData)

               #if jsonIncomingData["type"] == "interfaces":
               await sendToAll(json.dumps(jsonIncomingData))
            sBuffer = ""
            os.write(fifoOUT, "\n".encode("utf8"))


         except Exception as e:
            #Seems some rubbish in channel
            #Let's drop it out
            print(e)


         await asyncio.sleep(0.1)
      except BlockingIOError as e:
         await asyncio.sleep(0.1)
         pass


async def handle_client(websocket, path):
#   global dictBuffer

   listSockets.append(websocket)

   #print(dictBuffer)

#   if "plannedInterfaces" in dictBuffer:
#      await websocket.send(json.dumps(dictBuffer["plannedInterfaces"]))

   async for message in websocket:
      print(f"Received message from client: {message}")

      os.write(fifoOUT, message.encode("utf8"))


async def start_server():
    server = await websockets.serve(handle_client, 'localhost', 8000)
    print("WebSocket server started")

    await server.wait_closed()


loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

loop.create_task(start_server())
loop.create_task(readFIFO())

loop.run_forever()