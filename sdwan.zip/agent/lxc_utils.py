import os

import lxc
import asyncio
import logging
from enum import Enum
from dataclasses import dataclass
from tabulate import tabulate
from typing import Dict
import zipfile
import stat
import shutil


import config
import log_utils
import os_command_utils



#loop = asyncio.new_event_loop()

#loop = asyncio.get_event_loop()


import download_utils



# Set up logging configuration
logging.basicConfig(
   level=logging.DEBUG,
   format='\033[35m%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
)


log = logging.getLogger("LXC")
log.setLevel(config.getLogLevel("lxc"))


class State(Enum):
   NOT_INITED = -1
   STOPPED = 0
   STARTING = 1
   RUNNING = 2
   STOPPING = 3
   ERROR = 4


class LXC:

   @dataclass(frozen=True)
   class ContainerNotFoundException(Exception):
      name: str

   @dataclass(frozen=True)
   class ContainerAlreadyExistException(Exception):
      name: str



   #User representation
   @dataclass(frozen=True)
   class Container:
      name: str
      state: State
      pid: int
      config_file_path: str


   #internal state
   class _ContainerState:
      name: str
      state: State = State.NOT_INITED
      task: asyncio.Task

      def __init__(self, sName):
         self.name = sName



   def __init__(self):
      self.downloader = download_utils.Downloader()
      self.lock = asyncio.Lock()

      self.dictContainers: Dict[str, LXC._ContainerState] = {}

      self.dictCpu: Dict[str, ()] = {}


   def _getContainerState(self, sName):
      log.debug(f"[sName] getState()")

      if sName not in self.dictContainers:
         log.debug(f"[sName] No such container, let's create.")

         containerState = LXC._ContainerState(sName)
         self.dictContainers[sName] = containerState

      containerState = self.dictContainers[sName]

      return containerState



   def __printTable(self):
      logContainers = []
      for container in lxc.list_containers(as_object=True):
         logRow = [container.name, container.state, container.init_pid, container.config_file_name]
         logContainers.append(logRow)

      return tabulate(logContainers, headers=["Name", "State", "PID", "Config file"], tablefmt="grid")



   def __getContainer(self, sName) -> lxc.Container:
      container = next(filter(lambda container: container.name == sName, lxc.list_containers(as_object=True)), None)

      if container == None:
         log.critical("Container '%s' is NOT FOUND" % (sName))
         raise LXC.ContainerNotFoundException(sName)
      else:
         return container


   def getContainers(self):
      log.debug("Containers:\n" + self.__printTable())

      listContainers = []
      for _container in lxc.list_containers(as_object=True):
         container = LXC.Container(_container.name,
                                   State[_container.state],
                                   _container.init_pid,
                                   _container.config_file_name)
         listContainers.append(container)
      return tuple(listContainers)


   def isContainerExist(self, sName:str):
      container = next(filter(lambda container: container.name == sName, lxc.list_containers(as_object=True)), None)
      if container is None:
         return False
      else:
         return True


   async def createContainer(self, sName: str, sTemplate: str, iSize:int, sha:str):
      log.info(f"[{sName}] Let's create a container from template '{sTemplate}', size={iSize}, sha512={sha}")
      container = lxc.Container(sName)

      if container.defined:
         log.error(f"[{sName}] already exists!")
         raise LXC.ContainerAlreadyExistException(sName)
      else:
         while True:
            sFullFileName = config.getVNF().repo.local_dir + "/" + sTemplate + ".zip"
            task = await self.downloader.addTask(config.getVNF().repo.url + "/" + sTemplate + ".zip", sFullFileName)
            await task.isFinished()

            if (await task.getLocalFileSize()) != iSize:
               log.info(f"[{sName}] Size mismatch. Let's remove the file='{sFullFileName}' and try again.")
               await task.restart()

            if task.check_sha512(sha):
               break
            else:
               log.info(f"[{sName}] CRC mismatch. Let's remove the file='{sFullFileName}' and try again.")
               await task.restart()

            await asyncio.sleep(10)


         sTempFolder = "/tmp/" + sName
         if os.path.exists(sTempFolder):
            log.debug(f"[{sName}] Let's remove the temp='{sTempFolder}' folder.")
            try:
               shutil.rmtree(sTempFolder)
               log.debug(f"[{sName}] ...done.")
            except Exception as e:
               log.error(f"[{sName}]" + str(e))


         log.debug(f"[{sName}] Now let's create the '{sTempFolder}' folder.")
         os.mkdir(sTempFolder)

         log.debug(f"[{sName}] We are going to unzip the things into temp='{sTempFolder}' folder.")

         # with zipfile.ZipFile(sFullFileName, 'r') as zip_ref:
         #    # Extract all files to the destination path
         #    for member in zip_ref.namelist():
         #       file_info = zip_ref.getinfo(member)
         #
         #       # Extract the file to the specified path
         #       zip_ref.extract(member, sTempFolder)
         #
         #       # Recover Linux file attributes
         #       if hasattr(file_info, 'external_attr') and stat.S_ISREG(file_info.external_attr >> 16):
         #          # Extract the file permissions
         #          file_permissions = file_info.external_attr >> 16
         #
         #          # Set the file permissions on the extracted file
         #          extracted_file_path = f"{sTempFolder}/{member}"
         #          os.chmod(extracted_file_path, file_permissions)
         await os_command_utils.os_command_ignore(f"unzip {sFullFileName} -d {sTempFolder}")



         log.debug(f"[{sName}] ok, unzipped.")


         container.create()
         log.info(f"[{sName}] The empty container has been created.")

         #os.mkdir("/vnf/" + sTemplate + "/rootfs")
         try:
            shutil.move(sTempFolder + "/rootfs", config.getLXC().dir + "/" + sName)
            log.info(f"[{sName}] The root fs has been moved.")
         except Exception as e:
            log.error(f"[{sName}]" + str(e))

         container.append_config_item("lxc.rootfs.path", f"dir:{config.getLXC().dir}/{sName}/rootfs")
         container.save_config()

         log.debug(f"[{sName}] The container is ready.")




   # async def _startContainerTask(self, sName: str, sTemplate: str):
   #    log.info(f"[{sName}] startContainer() task has been created")
   #    container = self.__getContainer(sName)
   #
   #    if container == None:
   #       log.critical(f"[{sName}] is NOT FOUND, let's create!")
   #       await self.createContainer(sName, sTemplate)
   #       container = self.__getContainer(sName)
   #
   #    container.start()
   #    log.info(f"[{sName}] ok, has been started.")
   #
   #    log.info("Now the Containers are:\n" + self.__printTable())



   async def startContainer(self, sName):
      log.info(f"[{sName}] startContainer()")

      container = self.__getContainer(sName)

      async with self.lock:
         containerState = self._getContainerState(sName)

         if containerState.state == State.STARTING or containerState.state == State.RUNNING:
            log.info(f"[{sName}] is already running.")
            return

      container.start()
      log.info(f"[{sName}] ok, has been started.")

      log.info("Now the Containers are:\n" + self.__printTable())


      """
      m[n]['status'] = 'running'
      client.publish('vnf/update', json.dumps(m))
      """




   async def stopContainer(self, sName):
      log.info(f"[{sName}] Let's stop the container")
      container = self.__getContainer(sName)

      container.stop()
      log.info(f"[{sName}] ok, '%s' has been stopped." % (sName))

      log.info("Now the Containers are:\n" + self.__printTable())

      """
      topic = 'vnf/%s' % (m[n])
      m[n]['status'] = 'stopped'
      client.publish(topic, json.dumps(m[n]))
      """


   async def removeContainer(self, sName):
      log.info(f"[{sName}] Let's REMOVE the container.")
      container = self.__getContainer(sName)
      container.destroy()

      log.info(f"[{sName}] ok, removed.")



   def stopAll(self):
      log.info("stopAll()")
      for _container in lxc.list_containers(as_object=True):
         if _container.name != config.getAdminPanel().lxc_container:
            #we never stop the "admin panel" this way
            _container.stop()
      log.info("Done. The Containers are:\n" + self.__printTable())




   async def setContainerConfig(self, sName:str, sConfig: str):
      log.info(f"[{sName}] setConfig()\n{config}")

      self.__getContainer(sName)

      with open(f"{config.getLXC().dir}/{sName}/config", "w") as file:
         file.write(sConfig)

      log.info(f"[{sName}] ok, the config set.")



   async def setContainerStartScript(self, sName:str, sScript:str):
      log.info(f"[{sName}] setStartScript() container='{str}'\n{sScript}")

      self.__getContainer(sName)

      with open(f"{config.getLXC().dir}/{sName}/rootfs/etc/local.d/vnf.start", "w") as file:
         file.write(sScript)
      os.chmod(f"{config.getLXC().dir}/{sName}/rootfs/etc/local.d/vnf.start", 0o755)

      log.info(f"[{sName}] ok, the script added.")



   async def getMemoryUsage(self, sName) -> int:
      with open(f"/sys/fs/cgroup/lxc.monitor.{sName}/memory.current", "r") as file:
         return int(file.read())


   def read_system_cpu_time(self):
      with open('/proc/stat', 'r') as file:
         line = file.readline()
         parts = line.split(' ')[2:6]  # Get user, nice, system, and idle times
         cpu_time = sum(int(part) for part in parts)
         return cpu_time


   def read_cpu_usage_from_stat(self, container_name:str):
      path = f"/sys/fs/cgroup/lxc.monitor.{container_name}/cpu.stat"
      try:
         with open(path, 'r') as file:
            for line in file:
               if line.startswith("usage_usec"):
                  cpu_usage_usec = int(line.split()[1])
                  return cpu_usage_usec
      except FileNotFoundError:
         print(f"Container {container_name} not found.")
         return None


   async def getCpuUsage(self, name:str):
      # Initial readings
      container_usage = self.read_cpu_usage_from_stat(name)
      system_cpu_time = self.read_system_cpu_time()

      if name in self.dictCpu:
         delta_container_usage = container_usage - self.dictCpu[name][0]
         delta_system_cpu_time = system_cpu_time - self.dictCpu[name][1]
         delta_system_cpu_time_usec = delta_system_cpu_time * 10000  # Convert from jiffies to microseconds
         cpu_usage_percentage = "{:.2f}".format((delta_container_usage / delta_system_cpu_time_usec) * 100 * 2)  # Adjust for number of CPUs

         self.dictCpu[name] = (container_usage, system_cpu_time)

         return cpu_usage_percentage
      else:
         #first run
         self.dictCpu[name] = (container_usage, system_cpu_time)
         return None

#test = LXC()
#loop.create_task(test.startContainer("test", "DHCP"))
#test.getContainers()
#test.startContainer("DHCP")
#test.stopContainer("DHCP")

#loop.run_forever()
