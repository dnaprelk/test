import asyncio
import copy
import ipaddress
import os
import time
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from stat import ST_MTIME
from typing import Union, Optional, Set
from tabulate import tabulate


import psutil

import config
import crash_utils
import terminate
import log_utils
import api
from network_interface import Interface, exists
from os_command_utils import os_command_halt, os_command_ignore, os_command_exception
from ping import Ping

loop = asyncio.get_event_loop()

DHCP_LOG = "[DHCP]"


class InterfaceWAN(Interface):


   class Hardware(str,Enum):
      WIRED    = "wired"
      WIRELESS = "wireless"
      MODEM    = "modem"

   class Configuration(str,Enum):
      STATIC = "static"
      DHCP   = "dhcp"


   @dataclass(frozen=True)
   class ConfigurationStatic:
      ip:str
      gate:str
      dns:Set[str]

   @dataclass(frozen=True)
   class ConfigurationDHCP:
      server:str
      dns:Set[str]



   def __init__(self, sName:str, sPhysName:str, number:int):
      super().__init__(sName, sPhysName, number)
      self.hubIP = None
      self.log.info(f"add WAN {self.logTag}")

      self.ping = None
      self.statistics = Interface.Statistics()
      self.gw = None
      self.hardwareType:InterfaceWAN.Hardware = None
      self.configurationType:Union[InterfaceWAN.ConfigurationStatic,
                                   InterfaceWAN.ConfigurationDHCP] = None
      self.dhclient_pid_file = f"/var/run/dhclient--{self.physName}.pid"
      self.dhclient_lease_file = f"/var/lib/dhclient/dhclient--{self.physName}.lease"
      self.dhclient_lease_time = None


   def startMonitor(self):
      self.task_check_deamon = loop.create_task(self.check_thread())
      self.task_check_deamon_ping = loop.create_task(self.check_thread_ping())


   @exists
   async def os_get_route(self):
      self.log.debug("getRoute()")
      try:
         gw_raw = await os_command_ignore(f"ip route show 0.0.0.0/0 dev {self.physName}")
         self.log.debug("GATE raw output=" + gw_raw)
         route = gw_raw.split(' ')[2]
         self.log.info("GATE=" + route)
         return route
      except Exception as e:
         self.log.info("GATE=None")
         return None


   @exists
   async def os_del_route(self):
      self.log.info(f"delRoute() gw={self.gw}")
      await os_command_ignore(f"ip route del 0.0.0.0/0 via {self.gw}")
      self.log.info(f"ok, gw deleted.")


   @exists
   async def os_set_route(self, gw:str, ttl:int):
      self.log.info(f"setRoute() gw={gw} ttl={ttl}")
      await os_command_ignore(f"ip route add 0.0.0.0/0 via {gw} metric {ttl}")
      self.log.info(f"ok, gw={self.gw} set.")



   async def hasRoute(self):
      async with self.lock:
         return self.gw != None




   async def startDhclinet(self):
      self.log.info("Let's start the dhclient process...")

      if os.path.exists(self.dhclient_lease_file):
         os.remove(self.dhclient_lease_file)

      timeStart:float = time.time()
      await os_command_ignore(f"dhclient -1 -sf /dev/null -lf {self.dhclient_lease_file} -pf {self.dhclient_pid_file} {self.physName}")
      self.log.info(f"ok, dhclient stated in {round(time.time() - timeStart, 2)} seconds.")


   async def stopDhclient(self):
      DHCP_LOG = "[DHCP]"
      if os.path.exists(self.dhclient_pid_file):
         self.log.debug(f"{DHCP_LOG} Pid file exists.")
         with open(self.dhclient_pid_file, 'r') as file:
            try:
               process = psutil.Process(int(file.read().strip()))
               self.log.info(f"{DHCP_LOG} ok, dhclient is alive.")
               process.terminate()
            except Exception as e:
               self.log.error(f"{DHCP_LOG} Seems no such process.")



   # async def resetModem(self):
   #    self.log.info(await os_command_ignore("mmcli -m any -r"))
   # async def unlockModem(self):
   #    self.log.info(await os_command_ignore("/usr/share/ModemManager/fcc-unlock.available.d/1199 cdc-wdm0 cdc-wdm0"))
   # async def stopModem(self):
   #    self.log.info(await os_command_ignore("mmcli -m any -d"))
   # async def startModem(self):
   #    self.log.info(await os_command_ignore("mmcli -m any -e"))



   async def check_thread(self):

      try:
         await self.removeOldConfig()
         await self.flush()

         if self.hardwareType == InterfaceWAN.Hardware.WIRED or self.hardwareType == InterfaceWAN.Hardware.WIRELESS:
            self.log.info("For 'wired' or 'wireless' we UP interface manually.")
            await self.up()

            if self.configurationType == InterfaceWAN.Configuration.STATIC:
               await self.os_set_ip_address(self.configuration.ip)

            if self.configurationType == InterfaceWAN.Configuration.DHCP:
               await self.stopDhclient()
               await self.startDhclinet()
      except Exception as e:
         self.log.error(log_utils.print_exception(e))
         terminate.terminate()


      try:
         if self.hardwareType == InterfaceWAN.Hardware.MODEM:
            self.log.info("For 'modem' we initialize it first.")
            self.stateModem = InterfaceWAN_Modem.StateModem.UNKNOWN
      except Exception as e:
         self.stateModem = InterfaceWAN_Modem.StateModem.FAILED
         self.log.error(log_utils.print_exception(e))



      while True:
         try:
            async with self.lock:
               self.prev_state = self.state
               self.state = await self.check_state()



            if self.hardwareType == InterfaceWAN.Hardware.WIRELESS:
               isWPA_alive = False
               for process in psutil.process_iter(['pid', 'name']):
                  if 'wpa_supplicant' == process.name():
                     isWPA_alive = True
               if isWPA_alive == True:
                  self.log.info("WPA is alive.")
               else:
                  self.log.error("WPA is dead.")
                  await os_command_ignore(f'wpa_supplicant -B -i {self.physName} -c <(wpa_passphrase "{self.ssid}" "{self.password}")')


            if self.hardwareType == InterfaceWAN.Hardware.MODEM:

               self.log.info(f"Modem state={self.stateModem}")

               if self.stateModem == InterfaceWAN_Modem.StateModem.UNKNOWN:
                  await self.flush()
                  self.log.info(await os_command_ignore("service ModemManager restart"))
                  self.log.info(await os_command_ignore("mmcli -m any -r"))
                  self.stateModem = InterfaceWAN_Modem.StateModem.REBOOTED

               elif self.stateModem == InterfaceWAN_Modem.StateModem.REBOOTED:
                  sTmp = await os_command_ignore("/usr/share/ModemManager/fcc-unlock.available.d/1199 cdc-wdm0 cdc-wdm0")

                  self.log.info(sTmp)
                  #if "Successfully" in sTmp:
                  self.stateModem = InterfaceWAN_Modem.StateModem.ENABLING

               elif self.stateModem == InterfaceWAN_Modem.StateModem.ENABLING:
                  sTmp = await os_command_ignore("mmcli -m any -e")

                  self.log.info(sTmp)
                  #if "successfully" in sTmp:
                  self.stateModem = InterfaceWAN_Modem.StateModem.READY_FOR_CONNECT

               elif self.stateModem == InterfaceWAN_Modem.StateModem.READY_FOR_CONNECT:
                  self.log.info(f"Let's try to connect to {self.apn}")
                  sTmp = await os_command_ignore(f'mmcli -m any -v --simple-connect="apn={self.apn}"')
                  self.log.info(sTmp)
                  if "successfully" in sTmp:
                     self.stateModem = InterfaceWAN_Modem.StateModem.CONNECTED
                  else:
                     self.log.error("Not connected yet.")
                     self.stateModem = InterfaceWAN_Modem.StateModem.REBOOTED


               elif self.stateModem == InterfaceWAN_Modem.StateModem.PPP:
                  await os_command_ignore("pppd call MTS")

               elif self.stateModem == InterfaceWAN_Modem.StateModem.CONNECTED:
                     try:
                        sInfo = await os_command_halt("mmcli -m any")
                        self.log.debug("Modem info:\n" + sInfo)

                        sBearer = sInfo.split("/")[-1]

                        self.log.info(f"Bearer={sBearer}")

                        sConnectionInfo = await os_command_halt(f"mmcli -m any -b {sBearer}")
                        self.log.debug(sConnectionInfo)

                        if "ppp" in sConnectionInfo:
                           self.log.debug("ok, let's connect with ppp then...")
                           self.physName = "ppp0"
                           self.stateModem = InterfaceWAN_Modem.StateModem.PPP
                           self.gw = "10.64.64.64"
                           if self.ping:
                              self.ping = Ping(self.physName, self.hubIP)
                        else:
                           self.log.debug("Good, a static ip address assigned?")
                           for sLine in sConnectionInfo.split('\n'):
                              if "address" in sLine:
                                 ip = sLine.split(":")[1].strip()
                              if "prefix" in sLine:
                                 prefix = sLine.split(":")[1].strip()
                              if "gateway" in sLine:
                                 gateway = sLine.split(":")[1].strip()
                              if "dns" in sLine:
                                 await self.addDNS(set(sLine.split(":")[1].strip().split(",")))

                           self.log.info(f"Modem connected ip={ip} prefix={prefix} gate={gateway}")

                           await self.up()
                           self.ip = f"{ip}/{prefix}"
                           await self.os_set_ip_address(self.ip)

                           self.gw = gateway

                           self.stateModem = InterfaceWAN_Modem.StateModem.READY
                     except Exception as e:
                        self.stateModem = InterfaceWAN_Modem.StateModem.UNKNOWN
                        self.log.error(log_utils.print_exception(e))


            if self.state == Interface.State.UP:
               if self.prev_state == Interface.State.DOWN:
                  self.log.info("DOWN -> UP")
                  if self.ip != None:
                     await self.os_set_ip_address(self.ip)
               else:
                  self.log.info("UP")

               sRoute = await self.os_get_route()
               if self.gw is not None and sRoute != self.gw:
                  await self.os_set_route(gw=self.gw, ttl=100 + self.getNumber() * 10)


               if self.configurationType == InterfaceWAN.Configuration.DHCP:
                  self.log.debug(f"{DHCP_LOG} Let's check the dhclient process health...")

                  isDhclientAlive: bool = False
                  if os.path.exists(self.dhclient_pid_file):
                     self.log.debug(f"{DHCP_LOG} Pid file exists.")
                     with open(self.dhclient_pid_file, 'r') as file:
                        try:
                           process = psutil.Process(int(file.read().strip()))
                           self.log.info(f"{DHCP_LOG} ok, dhclient is alive.")
                           isDhclientAlive = True
                        except Exception as e:
                           self.log.error(f"{DHCP_LOG} Seems no such process.")

                  if isDhclientAlive != True:
                     self.log.info(f"{DHCP_LOG} Dhclient is DEAD. Let's start it now!")
                     await self.startDhclinet()

                  if os.path.exists(self.dhclient_lease_file):
                     lease_file_change_time = os.stat(self.dhclient_lease_file)[ST_MTIME]
                     self.log.info(
                        f"{DHCP_LOG} Lease time change time='{datetime.fromtimestamp(round(lease_file_change_time, 0))}'")

                     if self.dhclient_lease_time is None or self.dhclient_lease_time != lease_file_change_time:
                        self.log.info(
                           f"{DHCP_LOG} Lease file modification time is changed. Let's re-read the lease file.")

                        with open(self.dhclient_lease_file, 'r') as file_lease:
                           arrSections = file_lease.read().split("lease {")
                           self.log.info(f"{DHCP_LOG} Lease file has {len(arrSections)} sections.")

                           sSection = arrSections[-1].replace("}", "")
                           self.log.debug(f"{DHCP_LOG}\n{sSection}")

                           routers = None
                           fixed_address = None
                           sMask = None

                           for line in sSection.split("\n"):
                              if "option routers" in line:
                                 routers = line.split(" ")[-1].strip(";")
                              elif "fixed-address" in line:
                                 fixed_address = line.split(" ")[-1].strip(";")
                              elif "subnet-mask" in line:
                                 sMask = line.split(" ")[-1].strip(";")
                              elif "domain-name-servers" in line:
                                 await self.addDNS(set(line.split(" ")[-1].strip(";").split(",")))

                           self.log.info(f"{DHCP_LOG} ip={fixed_address} mask={sMask} gate={routers}")

                        if routers != None:
                           if await self.getRoute() != routers:
                              if await self.hasRoute():
                                 await self.os_del_route
                              self.ip = f"{fixed_address}/{self.subnet_mask_to_cidr(sMask)}"
                              await self.os_set_ip_address(self.ip)

                           async with self.lock:
                              self.gw = routers
                              self.dhclient_lease_time = lease_file_change_time


            else:
               if self.prev_state == Interface.State.UP:
                  self.log.info("UP -> DOWN")
                  await self.flush()
                  await self.getStatistics().clear()
               else:
                  self.log.info("DOWN")



               if self.configurationType == InterfaceWAN.Configuration.DHCP:
                  await self.stopDhclient()


         except Exception as e:
            self.log.error(log_utils.print_exception(e))


         await asyncio.sleep(config.TIMER_INTERFACE_CHECK)



   async def check_thread_ping(self):
      while True:
         try:
            if self.state == Interface.State.UP:
               if self.ping is not None:
                  pingHubResponse = await self.ping.send()
                  if pingHubResponse == None:
                     await self.statistics.fail()
                  else:
                     await self.statistics.success(pingHubResponse)
                     await api.sendInterfacePing(self.name, pingHubResponse)
            else:
               await self.statistics.clear()
         except Exception as e:
            self.log.error(log_utils.print_exception(e))
         await asyncio.sleep(config.TIMER_INTERFACE_PING)



   def getStatistics(self) -> Interface.Statistics:
      return self.statistics



   async def setHubIP(self, ip:str):
      async with self.lock:
         self.hubIP = ip
         self.ping = Ping(self.physName, self.hubIP)



   def convertType(self, type:Interface.Type):
      if type == Interface.Type.WIRED:
         return "Ethernet"
      elif type == Interface.Type.WIRELESS:
         return "Wireless"
      else:
         return "none"




   def cidr_to_ip_mask(self, cidr:str):
      ip_address, subnet_mask = cidr.split('/')
      subnet_mask = int(subnet_mask)
      ip_address = ipaddress.IPv4Address(ip_address)
      subnet_mask = (0xFFFFFFFF << (32 - subnet_mask)) & 0xFFFFFFFF
      subnet_mask_str = ipaddress.IPv4Address(subnet_mask)

      return str(ip_address), str(subnet_mask_str)




   # def writeScript(self, script:str):
   #    self.log.debug(f"writeScript()\n{script}")
   #
   #    with open(f"{SCRIPT_PATH}/ifcfg-{self.physName}", "w") as file:
   #       file.write(script)



   async def removeOldConfig(self):
      network_script_file = f"/etc/sysconfig/network-scripts/ifcfg-{self.physName}"
      if os.path.exists(network_script_file):
         await os_command_ignore(f"ifdown {self.physName}")
         self.log.info(f"Let's remove the network-script {network_script_file}")
         os.remove(network_script_file)



   @exists
   async def os_set_default_route(self):
      self.log.info(f"We are going to use {self.logTag} as the default route.")
      await os_command_ignore(f"ip route delete default via {self.gw} metric 99")
      await os_command_ignore(f"ip route add 0.0.0.0/0 via {self.gw} metric 99")
      self.log.info(f"ok, {self.logTag} set as the default route.")


   async def removeDefaultRoute(self):
      self.log.info(f"We are going to stop using {self.logTag} as the default route.")
      await os_command_ignore(f"ip route del 0.0.0.0/0")
      self.log.info(f"ok, {self.logTag} removed from the default route.")



   async def replaceDefaultRoute(self):
      self.log.info(f"We are going to replace the default route with {self.logTag}.")
      await os_command_ignore(f"ip route replace default via {self.gw} metric 99")
      self.log.info(f"ok, {self.logTag} set as the default route.")




   async def getRoute(self):
      async with self.lock:
         return self.gw


   async def addDNS(self, setDns:Set[str]):
      setDns = {s.strip() for s in setDns}

      #self.log.info(f"Let's add these dns servers to config: {setDns}")
      with open("/etc/resolv.conf", 'r') as file:
         contents = file.read()

      self.log.debug(contents)

      logTable = []
      for ip in setDns:
         logRow = []
         logTable.append(logRow)

         logRow.append(ip)

         if ip in contents:
            logRow.append("exist")
         else:
            logRow.append(f"Let's add {ip} to resolf.conf")
            with open("/etc/resolv.conf", 'a') as file:
                file.write(f"\nnameserver {ip}\n")

      self.log.info("DNS:\n" + tabulate(logTable, headers=["ip", "State"], tablefmt="grid"))


class InterfaceWAN_Wired(InterfaceWAN):
   def __init__(self, sName:str, sPhysName:str, number:int,
                configuration: Union[InterfaceWAN.ConfigurationStatic,
                                     InterfaceWAN.ConfigurationDHCP]):
      super().__init__(sName, sPhysName, number)
      self.hardwareType = InterfaceWAN.Hardware.WIRED

      if isinstance(configuration, InterfaceWAN.ConfigurationStatic):
         self.configurationType = InterfaceWAN.Configuration.STATIC
         self.ip = configuration.ip
         self.gw = configuration.gate
      if isinstance(configuration, InterfaceWAN.ConfigurationDHCP):
         self.configurationType = InterfaceWAN.Configuration.DHCP
      self.configuration = configuration

      if len(self.configuration.dns) > 0:
         loop.create_task(self.addDNS(self.configuration.dns))

      self.ip = None
      self.startMonitor()


class InterfaceWAN_Wireless(InterfaceWAN):
   def __init__(self, sName: str, sPhysName: str, number: int,
                ssid: str, password: str,
                configuration:Union[InterfaceWAN.ConfigurationStatic,
                                    InterfaceWAN.ConfigurationDHCP]):
      super().__init__(sName, sPhysName, number)
      self.hardwareType = InterfaceWAN.Hardware.WIRELESS
      self.configuration = InterfaceWAN.Configuration.DHCP
      self.ssid = ssid
      self.password = password

      if isinstance(configuration, InterfaceWAN.ConfigurationStatic):
         self.configurationType = InterfaceWAN.Configuration.STATIC
      if isinstance(configuration, InterfaceWAN.ConfigurationDHCP):
         self.configurationType = InterfaceWAN.Configuration.DHCP
      self.configuration = configuration

      if len(self.configuration.dns) > 0:
         loop.create_task(self.addDNS(self.configuration.dns))

      self.ip = None
      self.startMonitor()


class InterfaceWAN_Modem(InterfaceWAN):

   class StateModem(str, Enum):
      UNKNOWN           = "unknown"
      REBOOTED          = "rebooted"
      FCC_UNLOCK        = "fcc_unlock"
      ENABLING          = "enabling"
      READY_FOR_CONNECT = "ready_for_connect"
      CONNECTED         = "connected"
      READY             = "ready"
      FAILED            = "failed"
      PPP               = "ppp"


   def __init__(self, sName: str, sPhysName: str, number: int,
                apn:str, user:str, password:str):
      super().__init__(sName, sPhysName, number)
      self.hardwareType = InterfaceWAN.Hardware.MODEM
      self.apn = apn
      self.user = user
      self.password = password
      self.ip = None
      self.startMonitor()

      self.stateModem = InterfaceWAN_Modem.StateModem.UNKNOWN

