import asyncio
import logging
from typing import Dict, List

from tabulate import tabulate

import config
from network_interface_lan import InterfaceLAN
from network_interface_wan import InterfaceWAN
from os_command_utils import os_command_ignore

loop = asyncio.get_event_loop()









class Network:
   def __init__(self):
      self.dictInterfacesWAN:Dict[str, InterfaceWAN] = {}
      self.listInterfaceWan:List[InterfaceWAN] = []
      self.dictInterfacesLAN:Dict[str, InterfaceLAN] = {}



class WAN(Network):
   def __init__(self):
      super().__init__()
      self.lockWan = asyncio.Lock()
      self.defaultRouteInterface:InterfaceWAN = None

      self.log = logging.getLogger("WAN")
      self.log.setLevel(config.getLogLevel("neiwork-wan"))


   def add(self, interface:InterfaceWAN):
      self.log.info(f"add() {interface.logTag} type={type(interface)}")
      self.dictInterfacesWAN[interface.name] = interface
      self.listInterfaceWan.append(interface)


   def getInterfaceList(self):
      return tuple(self.listInterfaceWan)


   def getByName(self, sName:str):
      return self.dictInterfacesWAN.get(sName)





   async def setDefaultRoute(self, interface:InterfaceWAN):
      async with self.lockWan:
         if interface is not None:
            if self.defaultRouteInterface is None:
               await interface.os_set_default_route()
            else:
               await interface.replaceDefaultRoute()

         self.defaultRouteInterface = interface





   async def hasDefaultRoute(self) -> bool:
      return await self.getDefaultRoute() != None



   async def getDefaultRoute(self) -> InterfaceWAN:
      async with self.lockWan:
         return self.defaultRouteInterface


   async def resetRoutes(self):
      await os_command_ignore(f"ip route del default 2>/dev/null")



   async def print(self) -> str:
      arrRows = []
      for interfaceWan in self.listInterfaceWan:
         arrRow = []
         arrRows.append(arrRow)

         stat = interfaceWan.getStatistics()
         arrRow.append(interfaceWan.number)
         arrRow.append(interfaceWan.name)
         arrRow.append(interfaceWan.physName)
         arrRow.append(interfaceWan.type.name)
         arrRow.append((await interfaceWan.check_state()).name)
         defaultRoute = await self.getDefaultRoute()
         arrRow.append("*" if defaultRoute is not None and defaultRoute.name == interfaceWan.name else "")
         arrRow.append(await interfaceWan.get_ip_address())
         arrRow.append(interfaceWan.gw)
         ping_fails = await stat.getPingFails()
         arrRow.append(ping_fails if ping_fails is not None else "---")
         ping_delay = await stat.getPingDelay()
         arrRow.append(ping_delay if ping_delay is not None else "---")
         arrRow.append(f"{await stat.checkHealth()} ({await stat.getSucessCount()}/{await stat.getErrorCount()})")

      return tabulate(arrRows, headers=["Number",
                                        "Name",
                                        "PhysName",
                                        "Type",
                                        "State",
                                        "Default",
                                        "IP",
                                        "Gate",
                                        "Ping fails",
                                        "Ping delay",
                                        "Stat check"], tablefmt="grid")
   #async def close(self):
   #   for interfaceWAN in list(self.dictInterfacesWAN.values()):
   #      await interfaceWAN.down()
   #      self.dictInterfacesWAN.pop(interfaceWAN.name)


class LAN(Network):
   def __init__(self):
      super().__init__()

   def add(self, sName:str, sPhysName:str, number:int):
      self.dictInterfacesLAN[sName] = InterfaceLAN(sName, sPhysName, number)

   def getInterfaceList(self):
      return self.dictInterfacesLAN.values()


   async def close(self):
      pass

#loop = asyncio.new_event_loop()
#asyncio.set_event_loop(loop)
#loop = asyncio.get_event_loop()
#test = Interface("WAN0", "enp1s0")
#loop.run_forever()
