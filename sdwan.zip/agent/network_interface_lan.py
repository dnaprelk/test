import asyncio
import os
import lxc
from enum import Enum

from network_interface import Interface
from os_command_utils import os_command_ignore


loop = asyncio.get_event_loop()


class InterfaceLAN(Interface):
   class Type(Enum):
      HOST = 0
      VNF = 1

   def __init__(self, sName:str, sPhysName:str, number:int):
      super().__init__(sName, sPhysName, number)

      self.log.info(f"add LAN {self.logTag}")

      self.type = InterfaceLAN.Type.HOST

      self.state = Interface.State.DOWN
      self.ping  = None
      self.stat  = None
      self.gw    = None

      self.task_check_deamon = loop.create_task(self.check_thread())


   def getType(self):
      return self.type

   async def check_thread(self):
      while True:
         try:
            prev_state: Interface.State
            state:      Interface.State

            async with self.lock:
               prev_state = self.state
               if os.path.exists('/sys/class/net/' + self.physName):
                  self.type = InterfaceLAN.Type.HOST
               else:
                  self.type = InterfaceLAN.Type.VNF


            if self.type == InterfaceLAN.Type.HOST:
               self.log.info("%s (%s) is HOST" % (self.name, self.physName))
               state = await self.check_state()
            else:
               self.log.info("%s (%s) is VIRTUAL" % (self.name, self.physName))
               state = Interface.State.UNKNOWN
               for container in lxc.list_containers(as_object=True):
                  if container.state == 'RUNNING':
                     ifaces = container.get_config_item('lxc.net')
                     n = 0
                     for iface in ifaces:
                        if iface == 'phys':
                           if container.get_config_item('lxc.net.' + str(n) + '.link') == self.physName:
                              sResponse = await os_command_ignore('lxc-attach --name %s cat /sys/class/net/%s/operstate' % (container.name, self.physName))
                              async with self.lock:
                                 self.type = InterfaceLAN.Type.VNF
                                 self.state = (sResponse == "up") and Interface.State.UP or Interface.State.DOWN
                        n = n + 1

            async with self.lock:
               self.prev_state = prev_state
               self.state = state

            self.log.debug(f"{self.logTag} type={self.type.name} state -> {self.state.name}")


         except Exception:
            pass
         await asyncio.sleep(1)

