import config
import logging
import traceback
import sys

import config

def reset():
   pass

def registerIncident(sErrorMessage):
   sys.stderr.write(f"\nsErrorMessage")
   log = logging.getLogger("CRASH")
   log.critical(sErrorMessage)

   if config.getAdminPanel().isEnabled:
      with open(f"{config.getLXC().dir}/{config.getAdminPanel().lxc_container}//rootfs/var/www/localhost/htdocs/dead.txt", 'w') as file:
         file.write(sErrorMessage)


def printException(e):
   sErrorMessage = str(e) + "\n" + "\n".join(traceback.format_tb(e.__traceback__))
   return sErrorMessage