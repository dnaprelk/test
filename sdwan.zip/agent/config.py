import asyncio
import subprocess
import os
from typing import Tuple, List, Dict, Union, Set

import yaml
import logging
import log_utils


from dataclasses import dataclass



import api


CONFIG_PATH="../etc/node.yaml"
CONFIG_HISTORY = 10


TIMER_MAIN_CYCLE = 0.5
TIMER_INTERFACE_PING = 1.0
TIMER_INTERFACE_CHECK = 0.5
TIMER_WG_PING = 0.5


log = logging.getLogger("CONFIG")
log.setLevel(logging.NOTSET)


lock = asyncio.Lock()

def check_nested_dict_path(nested_dict, path) -> bool:
   try:
      return all(path_part in nested_dict for path_part in path.split('.'))
   except AttributeError:
      return False



log.info("I am reading the config file at path: " + CONFIG_PATH)
with open(CONFIG_PATH, "r") as file:
   configFile = yaml.safe_load(file)

configFile["node"]["machine_id"] = subprocess.check_output(["cat", "/etc/machine-id"]).decode("utf8").strip()
configFile["node"]["SN"] = subprocess.check_output(["dmidecode", "-s", "system-serial-number"]).decode("utf8").strip()

#Let's set default things
if check_nested_dict_path(configFile, "vnf") is False:
   configFile["vnf"] = {}
if check_nested_dict_path(configFile, "vnf.repo") is False:
   configFile["vnf"]["repo"] = {}
if check_nested_dict_path(configFile, "vnf.repo.url") is False:
   configFile["vnf"]["repo"]["url"] = "https://mtsdemo.henelora.net/vnf_repo"
if check_nested_dict_path(configFile, "vnf.repo.local_dir") is False:
   configFile["vnf"]["repo"]["local_dir"] = "/vnf_repo"


log.info("Done. The config:\n" + log_utils.print_tree(configFile))




#def readFile():
#   return configFile





def __convertLog(sLevel):
   if sLevel == None:
      return logging.NOTSET
   # Yaml converts OFF to False
   # By spec
   elif sLevel == False or sLevel.lower() == "off":
      return logging.CRITICAL + 1
   elif sLevel.lower() == "error":
      return logging.ERROR
   elif sLevel.lower() == "warn":
      return logging.WARN
   elif sLevel.lower() == "info":
      return logging.INFO
   elif sLevel.lower() == "debug":
      return logging.DEBUG

   return logging.NOTSET


def getLogLevel(sLogger):
   try:
      return __convertLog(configFile["logs"][sLogger.lower()])
   except Exception:
      #if there is no log section - TRACE level
      pass
   return logging.NOTSET


def getNetworkLogLevel(interfaceName):
   try:
      return __convertLog(configFile["logs"]["network"][interfaceName.lower()])
   except Exception:
      pass
   return logging.NOTSET





@dataclass(frozen=True)
class __LXC:
   dir:str
__lxc = __LXC(configFile["lxc"]["dir"])
def getLXC() -> __LXC:
   return __lxc

@dataclass(frozen=True)
class __VNF:
   @dataclass(frozen=True)
   class Repo:
      url:str
      local_dir:str

   repo:Repo

__vnf_repo = __VNF.Repo(configFile["vnf"]["repo"]["url"], configFile["vnf"]["repo"]["local_dir"])
__vnf = __VNF(__vnf_repo)
def getVNF() -> __VNF:
   return __vnf


@dataclass(frozen=True)
class __Node:
   platform: str
   machine_id: str
__node = __Node(configFile["node"]["platform"],
                configFile["node"]["machine_id"])
def getNode() -> __Node:
   return __node


@dataclass(frozen=True)
class __Interfaces:
   @dataclass(frozen=True)
   class Interface:
      @dataclass(frozen=True)
      class ConfigurationStatic:
         ip:str
         gate:str
         dns:Set[str]

      @dataclass(frozen=True)
      class ConfigurationDHCP:
         server:str
         dns:Set[str]

      @dataclass(frozen=True)
      class HardwareWired:
         configuration:Union['__Interfaces.Interface.ConfigurationStatic',
                             '__Interfaces.Interface.ConfigurationDHCP']

      @dataclass(frozen=True)
      class HardwareWireless:
         ssid:str
         password:str
         configuration:Union['__Interfaces.Interface.ConfigurationStatic',
                             '__Interfaces.Interface.ConfigurationDHCP']

      @dataclass(frozen=True)
      class HardwareModem:
         apn:str
         user:str
         password:str


      name:str
      phys:str
      number:int
      hardware: Union[HardwareWireless, HardwareModem]
      dns: str

   listWAN: Tuple[Interface]
   listLAN: Tuple[Interface]


def parseDNS(config: Dict) -> Set[str]:
   if "dns" not in config:
      return set()
   else:
      return set(config["dns"].replace(" ", "").split(","))


def getConfig(dictFile):
   if "static" in dictFile:
      wanFileStatic = dictFile["static"]
      return __Interfaces.Interface.ConfigurationStatic(ip=wanFileStatic["ip"],
                                                        gate=wanFileStatic["gate"],
                                                        dns=parseDNS(wanFileStatic))
   if "dhcp" in dictFile:
      wanFileDHCP = dictFile["dhcp"]
      return __Interfaces.Interface.ConfigurationDHCP(server=wanFileDHCP["server"],
                                                      dns=parseDNS(wanFileDHCP))



listWAN = []
for wanNumber in configFile["interfaces"]["WAN"]:
   wanFile = configFile["interfaces"]["WAN"][wanNumber]

   if "dns" not in wanFile:
      wanFile["dns"] = None

   hardware:Union[__Interfaces.Interface.HardwareWired,
                  __Interfaces.Interface.HardwareWireless,
                  __Interfaces.Interface.HardwareModem] = None


   if "wired" in wanFile:
      wanFileWired = wanFile["wired"]
      hardware = __Interfaces.Interface.HardwareWired(configuration=getConfig(wanFileWired))

   if "wireless" in wanFile:
      wanFileWireless = wanFile["wireless"]
      hardware = __Interfaces.Interface.HardwareWireless(ssid=wanFileWireless["SSID"],
                                                         password=wanFileWireless["password"],
                                                         configuration=getConfig(wanFileWireless))
   if "modem" in wanFile:
      wanFileModem = wanFile["modem"]
      hardware = __Interfaces.Interface.HardwareModem(apn=wanFileModem["apn"],
                                                      user=wanFileModem["user"],
                                                      password=wanFileModem["password"])



   wan = __Interfaces.Interface(name=wanFile["name"],
                                phys=wanFile["phys"],
                                number=int(wanNumber),
                                hardware=hardware,
                                dns=wanFile["dns"])
   listWAN.append(wan)




listLAN = []
for lanNumber in configFile["interfaces"]["LAN"]:
   lanFile = configFile["interfaces"]["LAN"][lanNumber]
   lan = __Interfaces.Interface(name=lanFile["name"],
                                phys=lanFile["phys"],
                                number=int(lanNumber),
                                hardware=None,
                                dns=None)
   listLAN.append(lan)

__interfaces = __Interfaces(tuple(listWAN), tuple(listLAN))

def getInterfaces() -> __Interfaces:
   return __interfaces


loop = asyncio.get_event_loop()
loop.run_until_complete(api.sendPlannedInterfaces(configFile["interfaces"]["WAN"].values()))
loop.run_until_complete(api.sendMaster(configFile["master"]["host"]))



@dataclass(frozen=True)
class Master:
   url: str
master = Master(configFile["master"]["host"])
def getMaster() -> Master:
   return master

@dataclass(frozen=True)
class Utils:
   ping: str
utils = Utils(configFile["utils"]["ping"])
def getUtils() -> Utils:
   return utils


@dataclass(frozen=True)
class AdminPanel:
   isEnabled:bool
   lxc_container:str
adminPanel = AdminPanel(bool(configFile["admin_panel"]["enabled"]) if "enabled" in configFile["admin_panel"] else False,
                        configFile["admin_panel"]["lxc_container"])
def getAdminPanel() -> AdminPanel:
   return adminPanel



def __removeNullKeys(dict:Dict) -> Dict:
   tmpDict = {}
   for key, value in dict.items():
      if key == "data":
         continue

      if value is not None:
         if isinstance(value, Dict):
            tmp = __removeNullKeys(value)
            if tmp is not None and len(tmp) > 0:
               tmpDict[key] = tmp
         elif isinstance(value, List):
            listTmp = []
            for elem in value:
               listTmp.append(__removeNullKeys(elem))
            tmpDict[key] = listTmp
         else:
            tmpDict[key] = value

   return tmpDict



def saveFile():
   log.debug("saveFile() The config:\n" + log_utils.print_tree(configFile))

   if os.path.exists(f"{CONFIG_PATH}_{CONFIG_HISTORY}"):
      os.remove(f"{CONFIG_PATH}_{CONFIG_HISTORY}")

   for f in range(CONFIG_HISTORY - 1, 1, -1):
      if os.path.exists(f"{CONFIG_PATH}_{f}"):
         os.rename(f"{CONFIG_PATH}_{f}", f"{CONFIG_PATH}_{f+1}")

   if os.path.exists(f"{CONFIG_PATH}"):
      os.rename(f"{CONFIG_PATH}", f"{CONFIG_PATH}_1")

   with open(CONFIG_PATH, 'w') as yaml_file:
      yaml.dump(__removeNullKeys(configFile), yaml_file, default_style='', default_flow_style=False, indent=3, sort_keys=False)

   log.info("ok, saved to file.")



def __getFileInterface(interface_name:str, phys_name:str) -> Dict:
   log.debug(f"getInterface() name='{interface_name}'")
   dictInterfaceWAN = next(filter(lambda dictWAN: dictWAN["name"] == interface_name, configFile["interfaces"]["WAN"]), None)

   if dictInterfaceWAN is None:
      dictInterfaceWAN = {}
      dictInterfaceWAN["name"] = interface_name
      dictInterfaceWAN["phys"] = phys_name
      configFile["interfaces"]["WAN"].append(dictInterfaceWAN)
      log.debug(f"Not found, let's create a new one.\n{log_utils.print_tree(dictInterfaceWAN)}")
   else:
      log.debug(f"ok, already exist.\n{log_utils.print_tree(dictInterfaceWAN)}")

   return dictInterfaceWAN


async def setStatic(interface_name:str, phys_name:str, ip:str, gate:str, dns:str=None):
   log.info(f"setStatic() name='{interface_name}' phys='{phys_name}' ip='{ip}' gate='{gate}' dns='{dns}'")

   async with lock:
      dictInterfaceWAN = __getFileInterface(interface_name, phys_name)
      dictInterfaceWAN["static"] = {}
      dictInterfaceWAN["static"]["ip"] = ip
      dictInterfaceWAN["static"]["gate"] = gate
      dictInterfaceWAN["dns"] = dns
      saveFile()



async def setDHCP(interface_name:str, phys_name:str, dns:str=None):
   log.info(f"setDHCP() name='{interface_name}' phys='{phys_name}' dns='{dns}'")

   async with lock:
      dictInterfaceWAN = __getFileInterface(interface_name, phys_name)
      dictInterfaceWAN["dhcp"] = {}
      dictInterfaceWAN["dhcp"]["server"] = "255.255.255.255"
      dictInterfaceWAN["dns"] = dns
      saveFile()




async def setMasterURL(host:str):
   log.info(f"setMasterURL() url='{host}'")

   async with lock:
      configFile["master"]["host"] = host
      saveFile()


