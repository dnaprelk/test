import json
import traceback


def print_tree(data):
   return json.dumps(data, indent=3)




class Tree:
   class Node:
      def __init__(self, level:int, name:str):
         self.name = name
         self.level = level
         self.listNodes = []

      def addNode(self, name:str):
         node = Tree.Node(self.level + 1, name)
         self.listNodes.append(node)
         return node

      def print(self, padding:str):
         sResult = padding[:-1] + "|-" + self.name + "\n"

         for node in self.listNodes[:-1]:
            sResult += node.print(padding + "  |")

         if len(self.listNodes) > 0:
            sResult += self.listNodes[-1].print(padding + "   ")
         return sResult

   def __init__(self, root:str):
      self.nodeRoot = Tree.Node(0, root)

   def getRoot(self):
      return self.nodeRoot

   def print(self):
      return self.nodeRoot.print("")


def print_exception(e):
   return f"{e} {type(e)}\n" + "\n".join(traceback.format_tb(e.__traceback__))


def print_object_tree(obj):
   tree = Tree("")
   node = tree.getRoot()
   _print_object_tree(obj, node)
   return tree.print()

def _print_object_tree(obj, node: Tree.Node = None):

   if isinstance(obj, dict):
      for key, value in obj.items():
         nodeChild = node.addNode(f"{key}")
         _print_object_tree(value, nodeChild)
   elif isinstance(obj, (list, tuple)):
      for index, item in enumerate(obj):
         nodeChild = node.addNode(f"[{index}]")
         _print_object_tree(item, nodeChild)
   elif hasattr(obj, '__dict__'):
      for key, value in obj.__dict__.items():
         nodeChild = node.addNode(f"{key} <{type(value).__module__}.{type(value).__name__}>")
         _print_object_tree(value, nodeChild)
   else:
      node.addNode(f"{obj}")
