import asyncio
import subprocess
import logging
import crash_utils

import config

#logging.basicConfig(
#   level=logging.DEBUG,
#   format='%(asctime)s - [%(name)s] - \033[31m[%(levelname)s] - \033[0m%(message)s'
#)

loop = asyncio.get_event_loop()

log = logging.getLogger("OS")
log.setLevel(config.getLogLevel("os"))


class ExceptionOS(Exception):
   pass


class Result:
   def __init__(self, out, error):
      self.out = out
      self.error = error


async def os_command_call(sCommand):
   process = await asyncio.create_subprocess_shell(
      sCommand,
      stdout=subprocess.PIPE,
      stderr=subprocess.PIPE
   )
   stdout, stderr = await process.communicate()
   return Result(stdout.decode("utf8").strip(), stderr.decode("utf8").strip())


async def os_command_halt(sCommand) -> str:

   log.info(sCommand)
   result = await os_command_call(sCommand)
   log.debug("\n" + sCommand + "\nOUT: " + result.out + ((len(result.error) > 0) and ("\nERROR: " + result.error) or ""))


   if len(result.error) > 0:
      sErrorMessage = f"COMMAND: {sCommand}\n{result.out}\nERROR: {result.error}\n\n"
      log.fatal(sErrorMessage)
      crash_utils.registerIncident(sErrorMessage)

      loop.stop()
      #sys.exit(1)

   return result.out



async def os_command_ignore(sCommand) -> str:

   log.info(sCommand)
   result = await os_command_call(sCommand)

   if len(result.error) > 0:
      log.error("\n" + sCommand + "\nOUT: " + result.out + ((len(result.error) > 0) and ("\nERROR: " + result.error) or ""))
   else:
      log.debug("\n" + sCommand + "\nOUT: " + result.out + ((len(result.error) > 0) and ("\nERROR: " + result.error) or ""))

   return result.out



async def os_command_exception(sCommand) -> str:

   log.info(sCommand)
   result = await os_command_call(sCommand)

   if len(result.error) > 0:
      log.error("\n" + sCommand + "\nOUT: " + result.out + ((len(result.error) > 0) and ("\nERROR: " + result.error) or ""))
      raise ExceptionOS(result.out)
   else:
      log.debug("\n" + sCommand + "\nOUT: " + result.out + ((len(result.error) > 0) and ("\nERROR: " + result.error) or ""))

   return result.out
