import asyncio
import logging
import os
import time
from dataclasses import dataclass
from enum import Enum

from os_command_utils import os_command_halt, os_command_ignore


import config


net_device_folder = "/sys/class/net"


loop = asyncio.get_event_loop()


def exists(func):
   def wrapper(self, *args, **kwargs):
      if self.isValid():
         result = func(self, *args, **kwargs)
         return result
      else:
         self.log.error(f"{self.name} is not operable. type={self.type.name}")
         future_result = loop.create_future()
         future_result.set_result(None)
         return future_result

   return wrapper


class Interface:
   class State(Enum):
      DOWN = 0
      UP = 1
      UNKNOWN = 0

   class Speed(Enum):
      FAIL = 0
      NORMAL = 1
      DEGRADED = 2

   class Type(Enum):
      NOT_FOUND = 0
      LOOPBACK = 1
      BRIDGE = 2
      WIRED = 3
      WIRELESS = 4
      MODEM = 5


   class Statistics:

      @dataclass(frozen=True)
      class PingSuccess:
         time:float
         delay:float

      @dataclass(frozen=True)
      class PingError:
         time:float

      def __init__(self):
         self.lock = asyncio.Lock()
         self.ping_fails = None
         self.ping_delay = None
         self.history = []

      async def fail(self):
         async with self.lock:
            if self.ping_fails is None:
               self.ping_fails = 1
            else:
               self.ping_fails += 1
               self.ping_delay = None
            self.history.append(Interface.Statistics.PingError(time.time()))
            if len(self.history) > 90:
               self.history.pop(0)

      async def success(self, delay):
         self.ping_fails = 0
         self.ping_delay = delay
         self.history.append(Interface.Statistics.PingSuccess(time.time(), delay))
         if len(self.history) > 90:
            self.history.pop(0)

      async def getSucessCount(self) -> int:
         async with self.lock:
            return len(list(filter(lambda result: isinstance(result, Interface.Statistics.PingSuccess), self.history)))

      async def getErrorCount(self) -> int:
         async with self.lock:
            return len(list(filter(lambda result: isinstance(result, Interface.Statistics.PingError), self.history)))


      async def checkHealth(self) -> bool:
         async with self.lock:
            if len(self.history) > 80 and len(list(filter(lambda result: isinstance(result, Interface.Statistics.PingError), self.history))) < 5:
               return True
            else:
               return False

      async def clear(self):
         async with self.lock:
            self.ping_fails = None
            self.ping_delay = None
            self.history.clear()

      async def getPingDelay(self):
         async with self.lock:
            return self.ping_delay

      async def getPingFails(self):
         async with self.lock:
            return self.ping_fails



   def __init__(self, sName:str, sPhysName:str, number:int):
      self.name = sName
      self.physName = sPhysName
      self.number = number
      self.logTag = f"{{{self.name}:{self.physName}}}"


      self.state      = Interface.State.DOWN
      self.prev_state = Interface.State.DOWN


      self.lock = asyncio.Lock()
      self.log = logging.getLogger(sPhysName)
      self.log.setLevel(config.getNetworkLogLevel(sName))
      self.task_check_deamon:asyncio.Task = None


      if os.path.exists(f"{net_device_folder}/{self.physName}"):
         if self.physName == "lo":
            self.log.info("It's a loopback")
            self.type = Interface.Type.LOOPBACK
         elif os.path.exists(f"{net_device_folder}/{self.physName}/bridge"):
            self.log.info("It's a bridge")
            self.type = Interface.Type.BRIDGE
         elif os.path.exists(f"{net_device_folder}/{self.physName}/wireless"):
            self.log.info("It's a wireless one")
            self.type = Interface.Type.WIRELESS
         elif os.path.exists(f"{net_device_folder}/{self.physName}/qmi") or os.path.exists(f"{net_device_folder}/{self.physName}/cdc_ncm"):
            self.log.info("It's a modem")
            self.type = Interface.Type.MODEM
         elif os.path.exists(f"{net_device_folder}/{self.physName}/device"):
            self.log.info("Seems the wired one")
            self.type = Interface.Type.WIRED
      else:
         self.type  = Interface.Type.NOT_FOUND
         #self.state = Interface.Speed.NOT_FOUND


   def isValid(self) -> bool:
      return self.type is not Interface.Type.NOT_FOUND


   def getName(self) -> str:
      return self.name
   def getPhysName(self) -> str:
      return self.physName
   def getNumber(self) -> int:
      return self.number


   async def getState(self) -> State:
      async with self.lock:
         return self.state



   def getType(self) -> Type:
      return self.type




   async def check_state(self):
      try:
         if self.type == Interface.Type.MODEM:
            f = open('/sys/class/net/' + self.physName + '/carrier', 'r')
            state = f.read().replace('\n', '')
            f.close()
            if state == "1":
               return Interface.State.UP
         else:
            f = open('/sys/class/net/' + self.physName + '/operstate', 'r')
            state = f.read().replace('\n', '')
            f.close()
            if state == "up":
               return Interface.State.UP
      except Exception:
         self.log.error("No such device")
      return Interface.State.DOWN


   async def flush(self):
      self.log.info(f"Let's clear the {self.logTag}")
      await os_command_ignore(f"ip addr flush {self.physName}")
      self.log.info(f"ok, {self.logTag} has been flushed.")



   async def hasIP(self) -> bool:
      return await self.get_ip_address() != None


   async def get_ip_address(self) -> str:
      self.log.info(f"getIP() on {self.logTag}")
      try:
         sResult:str = await os_command_ignore(f'ip addr show {self.physName}')

         for line in sResult.split('\n'):
            if 'inet' in line:
               ip_address = line.strip().split()[1]
               self.log.info(f"ip={ip_address}")
               return ip_address
      except Exception as e:
         pass
      self.log.info(f"ip=None")

      return None


   async def os_set_ip_address(self, cidr):
      self.log.info(f"setIP() on {self.logTag} {cidr}")
      await os_command_ignore(f"ip addr add {cidr} dev {self.physName}")
      self.log.info(f"ok, ip has been set.")


   async def up(self):
      self.log.info(f"up() on {self.logTag}")
      await os_command_halt(f"ip link set {self.physName} up")


   async def get_mac_address(self):
      self.log.info(f"getMac() on {self.logTag}")
      sResult:str = await os_command_halt(f'ip addr show {self.physName}')
      for line in sResult.split('\n'):
         if 'link/ether' in line:
            mac_address:str = line.split()[1]
            self.log.info(f"{self.logTag} has mac='{mac_address}'")
            return mac_address

      self.log.info(f"{self.logTag} has no mac address.")

      return None


   def subnet_mask_to_cidr(self, subnet_mask:str):
      octets = subnet_mask.split('.')
      cidr_notation = 0
      for octet in octets:
         binary_representation = bin(int(octet))[2:]
         cidr_notation += binary_representation.count('1')

      return cidr_notation
